using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace AccommodationTestManager.Views;
public partial class RecordsWindow : Window
{
    private readonly string _staff;
    private bool _busy;
    public RecordsWindow(string staff)
    {
        _staff=staff;InitializeComponent();Loaded+=(_,_)=>{Height=Math.Min(600,SystemParameters.WorkArea.Height-48);Width=Math.Min(880,SystemParameters.WorkArea.Width-48);Reload();};
    }
    private void Reload()
    {
        try{SessionGrid.ItemsSource=App.Host.Storage.ListSessions();}
        catch(Exception ex){DetailText.Text="Records could not load safely. No data was reset. "+ex.Message;}
        Selection_Changed(this,new SelectionChangedEventArgs(SelectorSelectionChangedEvent,Array.Empty<object>(),Array.Empty<object>()));
    }
    private static readonly RoutedEvent SelectorSelectionChangedEvent=System.Windows.Controls.Primitives.Selector.SelectionChangedEvent;
    private SessionEntry? Selected=>SessionGrid.SelectedItem as SessionEntry;
    private void Selection_Changed(object sender,SelectionChangedEventArgs e)
    {
        var entry=Selected;
        RecoverButton.IsEnabled=!_busy&&entry is not null&&entry.Session.Status is not ("Completed" or "Cancelled" or "NeedsReview")&&App.Host.Sessions.Current is null;
        RestoreBackupButton.IsEnabled=!_busy&&entry?.Session.Status=="NeedsReview";
        ReExportButton.IsEnabled=!_busy&&entry?.Session.Status=="Completed"&&(entry.Session.Mode=="Word"||entry.Session.Mode=="Custom"&&entry.Session.CustomKind=="Desktop");
        if(entry is not null)DetailText.Text=$"Session: {entry.Session.Id}\nLaptop: {entry.Session.LaptopName}\nLast health: {entry.Session.LastSaveHealth}\nNo automatic deletion. Shared-account storage is NOT protected for real student data.";
    }
    private async void Recover_Click(object sender,RoutedEventArgs e)
    {
        if(Selected is not SessionEntry entry||_busy)return;_busy=true;
        try{await App.Host.Sessions.AdoptAsync(entry,_staff);_busy=false;DialogResult=true;}
        catch(Exception ex){DetailText.Text=ex.Message;}
        finally{_busy=false;}
    }
    private async void ReExport_Click(object sender,RoutedEventArgs e)
    {
        if(Selected is not SessionEntry entry||_busy)return;
        var dialog=new SaveFileDialog{Title="Export another verified copy",FileName=$"CompletedExam-{entry.Session.Id[..8]}{Path.GetExtension(entry.Session.FinalRelativePath)}",Filter=$"Completed document|*{Path.GetExtension(entry.Session.FinalRelativePath)}",OverwritePrompt=true};
        if(dialog.ShowDialog(this)!=true)return;
        _busy=true;Selection_Changed(this,new SelectionChangedEventArgs(SelectorSelectionChangedEvent,Array.Empty<object>(),Array.Empty<object>()));
        try
        {
            string final=App.Host.Storage.FileInSession(entry.Folder,entry.Session.FinalRelativePath);
            if(LocalStorageService.HashFile(final)!=entry.Session.FinalSha256)throw new IOException("Final hash changed; staff review required.");
            if(File.Exists(dialog.FileName))throw new IOException("Choose a new filename. Existing files are not overwritten.");
            if(Path.GetFullPath(dialog.FileName).StartsWith(Path.GetFullPath(App.Host.Storage.Root)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Export outside app storage.");
            string hash=await Task.Run(()=>LocalStorageService.CopyVerified(final,dialog.FileName));
            var record=LocalStorageService.ReadJson<TestSession>(Path.Combine(entry.Folder,"session.json"));
            record.Events.Add(new(Guid.NewGuid().ToString("N"),DateTimeOffset.UtcNow,"Additional export verified",_staff,dialog.FileName+" | "+hash));
            LocalStorageService.WriteJson(Path.Combine(entry.Folder,"session.json"),record);
            DetailText.Text="Additional export verified. Original receipt retained. Safely eject the drive in Windows.";
        }
        catch(Exception ex){DetailText.Text=ex.Message;}
        finally{_busy=false;}
    }
    private void OpenFolder_Click(object sender,RoutedEventArgs e)
    {try{if(Selected is SessionEntry entry)Process.Start(new ProcessStartInfo(entry.Folder){UseShellExecute=true});}catch(Exception ex){DetailText.Text=ex.Message;}}
    private void RestoreBackup_Click(object sender,RoutedEventArgs e)
    {
        if(_busy||Selected is not SessionEntry entry)return;
        if(MessageBox.Show(this,"Restore the last metadata backup? It may be older than the documents/export. Existing metadata and backup will both be preserved. Review the recovered session before resuming.","Restore metadata",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        try{App.Host.Storage.RestoreMetadataBackup(entry,_staff);Reload();}catch(Exception ex){DetailText.Text=ex.Message;}
    }
    private void OpenStorage_Click(object sender,RoutedEventArgs e)
    {try{Process.Start(new ProcessStartInfo(App.Host.Storage.Root){UseShellExecute=true});}catch(Exception ex){DetailText.Text=ex.Message;}}
    private void Refresh_Click(object sender,RoutedEventArgs e){if(!_busy)Reload();}
    protected override void OnClosing(CancelEventArgs e){if(_busy)e.Cancel=true;base.OnClosing(e);}
}
