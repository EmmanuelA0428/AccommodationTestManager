using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using Microsoft.Win32;
using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Threading.Tasks;
using System.Windows;

namespace AccommodationTestManager.Views;

public partial class FeatureTestWindow : Window
{
    private readonly TextToSpeechService _textToSpeech;
    private readonly WordAutomationService _word;
    private readonly AutoSaveService _autoSave;
    private readonly RecoverySnapshotService _recovery;
    private readonly SpeechToTextService _speechToText = new();
    private string? _recoveryDirectory;

    private bool _readingSelection;
    private bool _wordOperationBusy;
    private bool _closed;

    public FeatureTestWindow()
    {
        InitializeComponent();

        // Both manual and automatic saving use this same Word service.
        _word = new WordAutomationService();
        _recovery = new RecoverySnapshotService(_word);
        Loaded += (_, _) =>
        {
            Rect work = SystemParameters.WorkArea;
            Height = Math.Min(760, work.Height - 32);
            Left = work.Left + (work.Width - Width) / 2;
            Top = work.Top + (work.Height - Height) / 2;
        };

        _autoSave = new AutoSaveService(
            _word,
            intervalSeconds: 60);

        _autoSave.StatusChanged += OnAutoSaveStatusChanged;

        // Development harness permits Word and Edge.
        _textToSpeech = new TextToSpeechService(
            new[] { "WINWORD", "msedge" });

        _textToSpeech.StatusChanged += OnSpeechStatusChanged;

        StatusTextBlock.Text = _textToSpeech.IsAvailable
            ? "Ready. Test speech or open a disposable Word document."
            : _textToSpeech.InitializationError
                ?? "Text-to-speech could not initialize.";
    }

    // ------------------------------------------------------------
    // Text-to-speech
    // ------------------------------------------------------------

    private void TestSpeaker_Click(
        object sender,
        RoutedEventArgs e)
    {
        _textToSpeech.SpeakTestPhrase();
    }

    private async void ReadSelection_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_readingSelection)
            return;

        _readingSelection = true;
        ReadSelectionButton.IsEnabled = false;

        try
        {
            StatusTextBlock.Text = "Getting selected text…";

            await _textToSpeech.SpeakSelectedTextAsync();
        }
        catch (Exception ex)
        {
            SetStatus($"Read selection failed: {ex.Message}");
        }
        finally
        {
            _readingSelection = false;

            if (!_closed)
                ReadSelectionButton.IsEnabled = true;
        }
    }

    private void Pause_Click(
        object sender,
        RoutedEventArgs e)
    {
        _textToSpeech.Pause();
    }

    private void Resume_Click(
        object sender,
        RoutedEventArgs e)
    {
        _textToSpeech.Resume();
    }

    private void Stop_Click(
        object sender,
        RoutedEventArgs e)
    {
        _textToSpeech.Stop();
    }

    private void OnSpeechStatusChanged(
        object? sender,
        string message)
    {
        SetStatus(message);
    }

    // ------------------------------------------------------------
    // Speech-to-text: temporary Voice Access launcher
    // ------------------------------------------------------------

    private void OpenVoiceAccess_Click(object sender, RoutedEventArgs e)
    {
        try { SetStatus(_speechToText.EnsureRunning()); }
        catch (Exception ex) { SetStatus($"Voice Access could not launch: {ex.Message}"); }
    }

    // ------------------------------------------------------------
    // Manual Word operations
    // ------------------------------------------------------------

    private async void OpenWord_Click(
        object sender,
        RoutedEventArgs e)
    {
        if (_wordOperationBusy)
            return;

        var dialog = new OpenFileDialog
        {
            Title = "Choose a disposable Word document",
            Filter = "Word documents|*.docx;*.doc"
        };

        if (dialog.ShowDialog(this) != true)
            return;

        await RunWordTestAsync(async () =>
        {
            WordDocumentStatus status =
                await _word.OpenAsync(dialog.FileName);

            _recoveryDirectory = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "AccommodationTestManager-Dev", "RecoveryTests", Guid.NewGuid().ToString("N"));
            RecoveryStatusTextBlock.Text = "No snapshot yet. Recovery folder: " + _recoveryDirectory;
            ShowWordStatus(status);
        });
    }

    private async void CheckWord_Click(
        object sender,
        RoutedEventArgs e)
    {
        await RunWordTestAsync(async () =>
        {
            WordDocumentStatus status =
                await _word.GetStatusAsync();

            ShowWordStatus(status);
        });
    }

    private async void SaveWord_Click(
        object sender,
        RoutedEventArgs e)
    {
        await RunWordTestAsync(async () =>
        {
            WordDocumentStatus status =
                await _word.SaveAsync();

            ShowWordStatus(status);
        });
    }

    private async void CloseWord_Click(
        object sender,
        RoutedEventArgs e)
    {
        await RunWordTestAsync(async () =>
        {
            await _word.CloseAsync();

            // Stop periodic checks only after closing succeeds.
            _autoSave.Stop();

            SetStatus("Word document closed safely.");
        });
    }

    private async Task RunWordTestAsync(Func<Task> operation)
    {
        if (_closed || _wordOperationBusy)
            return;

        _wordOperationBusy = true;
        SetWordControlsEnabled(false);
        SetStatus("Working with Word…");

        try
        {
            await operation();
        }
        catch (Exception ex)
        {
            SetStatus($"Word operation failed: {ex.Message}");
        }
        finally
        {
            _wordOperationBusy = false;

            if (!_closed)
                SetWordControlsEnabled(true);
        }
    }

    private void ShowWordStatus(WordDocumentStatus status)
    {
        SetStatus(
            $"Document: {status.FilePath}\n" +
            $"Read-only: {status.IsReadOnly}\n" +
            $"Unsaved changes: {status.HasUnsavedChanges}");
    }

    private void SetWordControlsEnabled(bool enabled)
    {
        WordManualControls.IsEnabled = enabled;
        StartAutoSaveButton.IsEnabled = enabled;
        CreateRecoveryButton.IsEnabled = enabled;
    }

    // ------------------------------------------------------------
    // Automatic saving
    // ------------------------------------------------------------

    private async void StartAutoSave_Click(
        object sender,
        RoutedEventArgs e)
    {
        await RunWordTestAsync(async () =>
        {
            WordDocumentStatus status =
                await _word.GetStatusAsync();

            if (status.IsReadOnly)
            {
                AutoSaveStatusTextBlock.Text =
                    "Cannot enable automatic saving: " +
                    "document is read-only.";

                SetStatus("Automatic saving was not enabled.");
                return;
            }

            _autoSave.Start();

            SetStatus(
                "Automatic saving enabled. " +
                "Return to Word and continue typing.");
        });
    }

    private void StopAutoSave_Click(
        object sender,
        RoutedEventArgs e)
    {
        _autoSave.Stop();
    }

    private void OnAutoSaveStatusChanged(
        object? sender,
        string message)
    {
        if (!_closed)
            AutoSaveStatusTextBlock.Text = message;
    }

    private async void CreateRecovery_Click(object sender, RoutedEventArgs e)
    {
        await RunWordTestAsync(async () =>
        {
            if (_recoveryDirectory is null)
                throw new InvalidOperationException("Open a disposable Word document first.");
            bool restart = _autoSave.IsRunning;
            if (restart) _autoSave.Stop();
            try
            {
                RecoverySnapshot snapshot = await _recovery.CreateAsync(_recoveryDirectory);
                RecoveryStatusTextBlock.Text = $"Snapshot verified: {snapshot.FilePath}\nSHA-256: {snapshot.Sha256}" +
                    (snapshot.CleanupWarning is null ? "" : $"\n{snapshot.CleanupWarning}");
                SetStatus("Recovery copy created and hash-verified. Reopen it manually to check its contents.");
            }
            finally { if (restart && !_closed) _autoSave.Start(); }
        });
    }
    private void OpenRecoveryFolder_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (_recoveryDirectory is null || !Directory.Exists(_recoveryDirectory))
            { SetStatus("Create a recovery copy first."); return; }
            Process.Start(new ProcessStartInfo(_recoveryDirectory) { UseShellExecute = true });
        }
        catch (Exception ex) { SetStatus($"Recovery folder could not open: {ex.Message}"); }
    }

    // ------------------------------------------------------------
    // Window lifecycle
    // ------------------------------------------------------------

    private void SetStatus(string message)
    {
        if (!_closed)
            StatusTextBlock.Text = message;
    }

    protected override void OnClosing(CancelEventArgs e)
    {
        // Let a requested manual operation finish before closing
        // this development harness.
        if (_wordOperationBusy || _readingSelection || _autoSave.IsBusy)
        {
            e.Cancel = true;

            SetStatus(
                "Wait for the current operation to finish " +
                "before closing the testing window.");
        }

        base.OnClosing(e);
    }

    protected override void OnClosed(EventArgs e)
    {
        _closed = true;

        _autoSave.StatusChanged -= OnAutoSaveStatusChanged;
        _autoSave.Dispose();

        _textToSpeech.StatusChanged -= OnSpeechStatusChanged;
        _textToSpeech.Dispose();

        // Detach from Word without intentionally closing it
        // or discarding unsaved work.
        _word.Dispose();

        base.OnClosed(e);

        // Closing this harness leaves the staff screen open.
    }
}