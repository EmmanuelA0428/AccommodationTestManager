using System.Windows.Controls;
namespace AccommodationTestManager.Views.Setup;
public partial class SupportsStepView : UserControl
{
    public SupportsStepView() { InitializeComponent(); }
}
