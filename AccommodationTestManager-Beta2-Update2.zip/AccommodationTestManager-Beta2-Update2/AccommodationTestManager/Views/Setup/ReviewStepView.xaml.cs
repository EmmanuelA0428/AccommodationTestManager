using System.Windows.Controls;
namespace AccommodationTestManager.Views.Setup;
public partial class ReviewStepView : UserControl
{
    public ReviewStepView() { InitializeComponent(); }
}
