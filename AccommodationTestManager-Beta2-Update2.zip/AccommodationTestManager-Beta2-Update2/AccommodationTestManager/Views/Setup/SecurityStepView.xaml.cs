using AccommodationTestManager.Models;
using System.Windows.Controls;
namespace AccommodationTestManager.Views.Setup;
public partial class SecurityStepView : UserControl
{
 public SecurityStepView(){InitializeComponent();}
 public void Refresh()
 {
  if(DataContext is not TestSetupDraft d)return;
  if(!App.Host.Settings.Current.RequireMachineRestrictions){PlanText.Text="UNENFORCED synthetic mode selected in Settings. No machine controls will be applied.";return;}
  bool online=d.Preset is "Canvas" or "Posit"||d.Preset=="Custom"&&d.CustomKind=="Website";
  bool network=d.Preset=="Custom"&&d.SelectedApplication?.NetworkRequired==true;
  PlanText.Text=online?"• Network remains available\n• Edge block-by-default navigation + selected URL allowlist\n• Supported Edge AI/sidebar policies requested\n• USB storage policy block\n• Staff live policy/login/USB checks before handoff":"• "+(network?"Network retained for approved custom app":"Isolate enabled network adapters (including Wi-Fi/Ethernet)")+"\n• USB storage policy block\n• Word verified autosave or custom app manual save\n• Staff live network/USB checks before handoff";
  PlanText.Text+="\n\nUnavailable: OS application lockdown, protected exam-data storage, and comprehensive in-site AI prevention.";
 }
}
