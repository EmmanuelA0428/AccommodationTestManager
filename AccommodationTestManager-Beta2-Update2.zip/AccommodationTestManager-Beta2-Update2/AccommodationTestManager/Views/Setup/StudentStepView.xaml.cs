using System.Windows.Controls;
namespace AccommodationTestManager.Views.Setup;
public partial class StudentStepView : UserControl
{
    public StudentStepView() { InitializeComponent(); }
}
