using AccommodationTestManager.Models;
using Microsoft.Win32;
using System.Windows;
using System.Windows.Controls;

namespace AccommodationTestManager.Views.Setup;
public partial class TestStepView:UserControl
{
    public TestStepView(){InitializeComponent();CustomType.ItemsSource=new[]{"Website","Desktop"};Loaded+=(_,_)=>Refresh();}
    private void Preset_Checked(object sender,RoutedEventArgs e){if(DataContext is not TestSetupDraft draft)return;draft.Preset=(string)((RadioButton)sender).Tag;Refresh();}
    private void CustomKind_Changed(object sender,SelectionChangedEventArgs e){if(IsInitialized)Refresh();}
    public void Refresh()
    {
        if(DataContext is not TestSetupDraft draft)return;
        var selected=draft.Preset switch{"Word"=>WordChoice,"Canvas"=>CanvasChoice,"Posit"=>PositChoice,_=>CustomChoice};selected.IsChecked=true;
        bool custom=draft.Preset=="Custom",desktop=custom&&draft.CustomKind=="Desktop";
        CustomTypePanel.Visibility=custom?Visibility.Visible:Visibility.Collapsed;DesktopPanel.Visibility=desktop?Visibility.Visible:Visibility.Collapsed;
        DocumentPanel.Visibility=draft.Preset=="Word"||desktop?Visibility.Visible:Visibility.Collapsed;
        CustomPanel.Visibility=custom&&!desktop?Visibility.Visible:Visibility.Collapsed;
        OnlineNotice.Visibility=draft.Preset is "Canvas" or "Posit"?Visibility.Visible:Visibility.Collapsed;
        if(draft.Preset is "Canvas" or "Posit")OnlineNotice.Text=$"{draft.Preset}: "+(draft.Preset=="Canvas"?App.Host.Settings.Current.CanvasUrl:App.Host.Settings.Current.PositUrl)+"\nStarting page and rules are edited in Settings.";
    }
    private void ChooseDocument_Click(object sender,RoutedEventArgs e)
    {
        if(DataContext is not TestSetupDraft draft)return;
        var picker=new OpenFileDialog{Filter=draft.Preset=="Word"?"Word documents|*.docx;*.doc":"Documents|*.*",Title="Select exam document; original remains unchanged"};
        if(picker.ShowDialog(Window.GetWindow(this))==true)draft.DocumentPath=picker.FileName;
    }
}
