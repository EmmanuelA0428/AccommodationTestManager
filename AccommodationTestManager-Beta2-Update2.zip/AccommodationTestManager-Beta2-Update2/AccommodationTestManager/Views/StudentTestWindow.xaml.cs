using AccommodationTestManager.Services;
using System.ComponentModel;
using System.Windows;
using System.Windows.Threading;

namespace AccommodationTestManager.Views;
public partial class StudentTestWindow : Window
{
    private readonly bool _preview;
    private readonly TextToSpeechService _speech;
    private readonly SpeechToTextService _dictation=new();
    private readonly DispatcherTimer _timer=new(){Interval=TimeSpan.FromSeconds(1)};
    private bool _busy;
    private bool _closed;
    private bool _expired;
    private bool _help;
    public bool AllowStaffClose { get; set; }
    public StudentTestWindow(bool preview=true)
    {
        _preview=preview;InitializeComponent();
        _speech=new TextToSpeechService(["WINWORD","msedge",System.IO.Path.GetFileNameWithoutExtension(App.Host.Sessions.Current?.ApplicationPath??"unused")]);_speech.StatusChanged+=SpeechStatus;
        App.Host.Sessions.Changed+=SessionChanged;_timer.Tick+=TimerTick;_timer.Start();Refresh();
    }
    private void Window_Loaded(object sender,RoutedEventArgs e)
    {var work=SystemParameters.WorkArea;Left=work.Right-Width-16;Top=work.Bottom-ActualHeight-16;}
    private void Refresh()
    {
        var s=App.Host.Sessions.Current;bool active=_preview||s?.Status=="Active";
        VoiceButton.IsEnabled=active&&(_preview||s!.SpeechToText);
        ReadButton.IsEnabled=!_busy&&active&&(_preview||s!.TextToSpeech);PauseButton.IsEnabled=ReadButton.IsEnabled;StopButton.IsEnabled=ReadButton.IsEnabled;
        FinishButton.IsEnabled=!_busy&&!_preview&&active;HelpButton.IsEnabled=!_busy&&!_preview&&active;
        TimerText.Visibility=!_preview&&s?.DurationMinutes is not null?Visibility.Visible:Visibility.Collapsed;
        if(!_preview&&s?.Status=="AwaitingStaff")StatusText.Text=s.Mode=="Word"?"Awaiting staff · Word closed":"Awaiting staff · staff must close app/browser";
        else if(_preview)StatusText.Text="Preview · no session";
        else if(_help)StatusText.Text="Staff help requested locally";
        else if(s is not null)StatusText.Text=s.LastSaveHealth;
        if(IsLoaded)Dispatcher.BeginInvoke(new Action(()=>{if(!_closed){var work=SystemParameters.WorkArea;Top=work.Bottom-ActualHeight-16;}}));
    }
    private void TimerTick(object? sender,EventArgs e)
    {
        var s=App.Host.Sessions.Current;if(_preview||s?.DeadlineUtc is null)return;
        TimeSpan remaining=s.Status=="Active"?s.DeadlineUtc.Value-DateTimeOffset.UtcNow:TimeSpan.FromSeconds(s.RemainingSeconds??0);
        if(remaining<TimeSpan.Zero)remaining=TimeSpan.Zero;TimerText.Text=$"{(int)remaining.TotalMinutes:00}:{remaining.Seconds:00}";
        if(remaining>TimeSpan.Zero)_expired=false;
        if(remaining==TimeSpan.Zero&&s.Status=="Active"&&!_expired){_expired=true;System.Media.SystemSounds.Exclamation.Play();StatusText.Text="Time ended · contact staff";}
    }
    private async void Read_Click(object sender,RoutedEventArgs e)
    {
        if(_busy)return;_busy=true;Refresh();
        try{await _speech.SpeakSelectedTextAsync();PauseIcon.Text="\uE769";}
        catch(Exception ex){StatusText.Text=ex.Message;}
        finally{_busy=false;if(!_closed)Refresh();}
    }
    private void Pause_Click(object sender,RoutedEventArgs e){_speech.TogglePause();PauseIcon.Text=_speech.IsPaused?"\uE768":"\uE769";}
    private void Stop_Click(object sender,RoutedEventArgs e){_speech.Stop();PauseIcon.Text="\uE769";}
    private void VoiceAccess_Click(object sender,RoutedEventArgs e)
    {try{StatusText.Text=_dictation.EnsureRunning();}catch(Exception ex){MessageBox.Show(this,ex.Message,"Voice Access unavailable");}}
    private async void Help_Click(object sender,RoutedEventArgs e)
    {
        if(_busy||_preview)return;_busy=true;Refresh();
        try{await App.Host.Sessions.RecordHelpAsync();_help=true;System.Media.SystemSounds.Exclamation.Play();MessageBox.Show(this,"Staff help requested locally. Please notify nearby staff; no online notification was sent.","Staff assistance");}
        catch(Exception ex){MessageBox.Show(this,ex.Message,"Help request not recorded");}
        finally{_busy=false;Refresh();}
    }
    private async void Finish_Click(object sender,RoutedEventArgs e)
    {
        if(_busy||_preview)return;
        string text=App.Host.Sessions.Current?.Mode=="Word"?"Finish? Your local document will be saved and checkpointed, then Word closed only if no unsaved changes remain. Staff can resume or export.":App.Host.Sessions.IsOnline?"Finish? Save/submit in the website first. Staff verifies the result; the browser is NOT locked/closed automatically.":"Finish? Save the custom app document first. Staff must verify the saved file; no automatic checkpoint is provided for this application.";
        if(MessageBox.Show(this,text,"Finish test",MessageBoxButton.YesNo,MessageBoxImage.Question)!=MessageBoxResult.Yes)return;
        _busy=true;Refresh();
        try{_speech.Stop();await App.Host.Sessions.FinishAsync();}
        catch(Exception ex){MessageBox.Show(this,"Finish did not complete. Work was not intentionally discarded.\n\n"+ex.Message,"Staff review required");}
        finally{_busy=false;Refresh();}
    }
    private void SessionChanged(object? sender,string message){if(!_closed)Refresh();}
    private void SpeechStatus(object? sender,string text){if(!_closed)StatusText.Text=text;}
    protected override void OnClosing(CancelEventArgs e)
    {
        if(_busy)e.Cancel=true;
        else if(!_preview&&!AllowStaffClose&&App.Host.Sessions.Current is not null)
        {e.Cancel=true;MessageBox.Show(this,"Use Finish, then ask staff. Staff can close the app while preserving recovery.");}
        base.OnClosing(e);
    }
    protected override void OnClosed(EventArgs e)
    {_closed=true;_timer.Stop();_timer.Tick-=TimerTick;App.Host.Sessions.Changed-=SessionChanged;_speech.StatusChanged-=SpeechStatus;_speech.Dispose();base.OnClosed(e);}
}
