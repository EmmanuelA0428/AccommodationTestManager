namespace AccommodationTestManager.Models;

public sealed record RecoverySnapshot(
    string FilePath,
    string Sha256,
    DateTimeOffset CreatedAt,
    string? CleanupWarning);
