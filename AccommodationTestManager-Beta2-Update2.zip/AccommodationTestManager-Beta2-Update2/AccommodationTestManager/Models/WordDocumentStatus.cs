﻿namespace AccommodationTestManager.Models;

public sealed record WordDocumentStatus(
    string FilePath,
    bool IsReadOnly,
    bool HasUnsavedChanges);