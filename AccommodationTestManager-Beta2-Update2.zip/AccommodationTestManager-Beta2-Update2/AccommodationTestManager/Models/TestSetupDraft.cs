using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace AccommodationTestManager.Models;

// In-memory staff setup. SessionService persists a separate session at Start.
public sealed class TestSetupDraft : INotifyPropertyChanged
{
    private string _customKind = "Website";
    private string _allowlistId = "custom";
    private ApprovedApplication? _selectedApplication;
    public string CustomKind { get => _customKind; set => Set(ref _customKind, value); }
    public string AllowlistId { get => _allowlistId; set => Set(ref _allowlistId, value); }
    public ApprovedApplication? SelectedApplication { get => _selectedApplication; set => Set(ref _selectedApplication, value); }
    public List<ApprovedApplication> ApplicationChoices { get; set; } = [];
    public string[] AllowlistChoices { get; set; } = [];
    private string _staffName = "";
    private bool _useTimeLimit;
    private string _studentName = "";
    private string _testName = "";
    private string _preset = "Word";
    private string _documentPath = "";
    private string _durationText = "90";
    private string _customUrl = "";
    private bool _textToSpeech;
    private bool _speechToText;
    private bool _blockNetwork = true;
    private bool _blockUsbStorage = true;
    private bool _restrictApps = true;

    public event PropertyChangedEventHandler? PropertyChanged;
    public string StaffName { get => _staffName; set => Set(ref _staffName, value); }
    public bool UseTimeLimit { get => _useTimeLimit; set => Set(ref _useTimeLimit, value); }
    public string[] StaffChoices { get; set; } = [];
    public string StudentName { get => _studentName; set => Set(ref _studentName, value); }
    public string TestName { get => _testName; set => Set(ref _testName, value); }
    public string Preset { get => _preset; set => Set(ref _preset, value); }
    public string DocumentPath { get => _documentPath; set => Set(ref _documentPath, value); }
    public string DurationText { get => _durationText; set => Set(ref _durationText, value); }
    public string CustomUrl { get => _customUrl; set => Set(ref _customUrl, value); }
    public bool TextToSpeech { get => _textToSpeech; set => Set(ref _textToSpeech, value); }
    public bool SpeechToText { get => _speechToText; set => Set(ref _speechToText, value); }
    public bool BlockNetwork { get => _blockNetwork; set => Set(ref _blockNetwork, value); }
    public bool BlockUsbStorage { get => _blockUsbStorage; set => Set(ref _blockUsbStorage, value); }
    public bool RestrictApps { get => _restrictApps; set => Set(ref _restrictApps, value); }

    private void Set<T>(ref T field, T value, [CallerMemberName] string? name = null)
    {
        if (EqualityComparer<T>.Default.Equals(field, value)) return;
        field = value;
        PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}
