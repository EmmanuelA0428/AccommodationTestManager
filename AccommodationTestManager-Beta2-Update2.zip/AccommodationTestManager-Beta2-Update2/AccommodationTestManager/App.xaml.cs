using AccommodationTestManager.Services;
using AccommodationTestManager.Views;
using System.Threading;
using System.Windows;

namespace AccommodationTestManager;
public partial class App : Application
{
    private Mutex? _instance;
    public LocalStorageService Storage { get; private set; } = null!;
    public SettingsService Settings { get; private set; } = null!;
    public AllowlistService Allowlists { get; private set; } = null!;
    public RestrictionService Restrictions { get; private set; } = null!;
    public ThemeService Theme { get; private set; } = null!;
    public SessionService Sessions { get; private set; } = null!;
    public static App Host => (App)Current;
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _instance = new Mutex(true, @"Local\AccommodationTestManager-Beta1", out bool first);
        if (!first) { MessageBox.Show("Accommodation Test Manager is already running in this Windows session."); Shutdown(); return; }
        try
        {
            Storage = new(); Settings = new(Storage); Settings.Load(); Allowlists=new(Storage);Allowlists.Initialize(); Restrictions=new(); Theme = new(Settings); Theme.Apply();
            if (!Settings.IsRegistered && !StaffDialogs.Register(Settings)) { Shutdown(); return; }
            Sessions = new(Storage, Settings, Allowlists, Restrictions);
            var window = new Views.MainWindow(); MainWindow = window; window.Show(); ShutdownMode = ShutdownMode.OnLastWindowClose;
        }
        catch (Exception ex)
        {
            MessageBox.Show("Startup stopped to preserve existing data. No session was reset.\n\n" + ex.Message, "Staff review required", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
        }
    }
    protected override void OnExit(ExitEventArgs e)
    {
        Sessions?.Dispose(); Theme?.Dispose(); _instance?.Dispose(); base.OnExit(e);
    }
}
