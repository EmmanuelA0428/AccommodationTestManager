namespace AccommodationTestManager.Services;

// A draft may be reviewed while recovery is outstanding, but Start never bypasses it.
public sealed record SetupReadiness(bool Blocked,string Reason,int UnfinishedCount,bool MachinePending)
{
    public static SetupReadiness Evaluate(int unfinished,bool pending,string? error=null)
    {
        if(error is not null)return new(true,"Storage/machine state needs staff review. No files were reset. "+error,unfinished,pending);
        if(unfinished>0)return new(true,$"{unfinished} unfinished session(s) need staff recovery. You may review setup, but cannot start another test until those sessions are resolved.",unfinished,pending);
        if(pending)return new(true,"Recorded machine controls still need restoring. Open Settings → Recovery → Emergency restore. A new test is blocked until restoration is verified.",0,true);
        return new(false,"Ready for setup. Required live control checks still apply before handoff.",0,false);
    }
    public bool CanContinue(int step,bool busy,bool hasCurrent)=>!busy&&!hasCurrent&&(step<3||!Blocked);
}
