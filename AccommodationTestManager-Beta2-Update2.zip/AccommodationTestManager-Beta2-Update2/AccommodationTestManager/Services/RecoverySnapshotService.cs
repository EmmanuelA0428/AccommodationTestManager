using AccommodationTestManager.Models;
using System.IO;
using System.Security.Cryptography;

namespace AccommodationTestManager.Services;

// Development snapshot helper. Production needs protected storage and session authorization.
public sealed class RecoverySnapshotService(WordAutomationService word)
{
    private readonly SemaphoreSlim _gate = new(1, 1);

    public async Task<RecoverySnapshot> CreateAsync(string recoveryDirectory, int maximumSnapshots = 5)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(recoveryDirectory);
        if (maximumSnapshots < 1) throw new ArgumentOutOfRangeException(nameof(maximumSnapshots));
        await _gate.WaitAsync();
        try
        {
            string destination = Path.GetFullPath(recoveryDirectory);
            for (int attempt = 0; ; attempt++)
            {
                try
                {
                    var snapshot = await word.CaptureSnapshotAsync(saved => CopyAndVerify(saved.FilePath, destination));
                    return Prune(snapshot, destination, maximumSnapshots);
                }
                catch (IOException) when (attempt < 4)
                {
                    // Word may have a temporary incompatible handle during a save.
                    await Task.Delay(350);
                }
            }
        }
        finally { _gate.Release(); }
    }

    internal static RecoverySnapshot CopyAndVerify(string sourcePath, string directory, Action? beforeCopy = null)
    {
        Directory.CreateDirectory(directory);
        DateTimeOffset created = DateTimeOffset.UtcNow;
        string extension = Path.GetExtension(sourcePath);
        string fileName = $"Recovery-{created:yyyyMMdd-HHmmss-fffffff}-{Guid.NewGuid():N}{extension}";
        string finalPath = Path.Combine(directory, fileName);
        string partialPath = finalPath + ".partial";
        string sourceHash;
        bool published = false;
        try
        {
            // Word legitimately retains writable/replacement handles. Compatible reads are
            // safe only with all three hashes + metadata + post-capture Word state checks.
            var before = new FileInfo(sourcePath); before.Refresh();
            long length = before.Length; DateTime stamp = before.LastWriteTimeUtc;
            using (var source = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
            {
                if (source.Length == 0) throw new IOException("The saved source document is empty.");
                sourceHash = Convert.ToHexString(SHA256.HashData(source));
                beforeCopy?.Invoke();
                source.Position = 0;
                using (var copy = new FileStream(partialPath, FileMode.CreateNew, FileAccess.Write, FileShare.None))
                {
                    source.CopyTo(copy);
                    copy.Flush(flushToDisk: true);
                }
                using (var copy = new FileStream(partialPath, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    string copyHash = Convert.ToHexString(SHA256.HashData(copy));
                    if (!string.Equals(sourceHash, copyHash, StringComparison.Ordinal))
                        throw new IOException("Recovery copy hash did not match the saved source.");
                }
                // Reopen the path: Word may replace the original file during a save.
                using (var current = new FileStream(sourcePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite | FileShare.Delete))
                {
                    string afterHash = Convert.ToHexString(SHA256.HashData(current));
                    var after = new FileInfo(sourcePath); after.Refresh();
                    if (afterHash != sourceHash || after.Length != length || after.LastWriteTimeUtc != stamp)
                        throw new IOException("The working document changed during recovery capture. No copy was accepted.");
                }
                ValidateDocx(partialPath, Path.GetExtension(sourcePath));
                // Publish only verified bytes. Never overwrite an existing snapshot.
                File.Move(partialPath, finalPath);
                published = true;
            }
        }
        finally
        {
            if (!published)
            {
                try { File.Delete(partialPath); } catch { /* Report original failure; don't claim success. */ }
            }
        }

        return new RecoverySnapshot(finalPath, sourceHash, created, null);
    }

    private static void ValidateDocx(string path, string extension)
    {
        if (!extension.Equals(".docx", StringComparison.OrdinalIgnoreCase)) return;
        using var archive = System.IO.Compression.ZipFile.OpenRead(path);
        if (archive.GetEntry("[Content_Types].xml") is null || archive.GetEntry("word/document.xml") is null)
            throw new IOException("Recovery file is not a complete Word document package.");
        var settings = new System.Xml.XmlReaderSettings { DtdProcessing = System.Xml.DtdProcessing.Prohibit, XmlResolver = null };
        foreach (string name in new[] { "[Content_Types].xml", "word/document.xml" })
        {
            using var stream = archive.GetEntry(name)!.Open();
            using var xml = System.Xml.XmlReader.Create(stream, settings);
            while (xml.Read()) { }
        }
    }

    private static RecoverySnapshot Prune(RecoverySnapshot snapshot, string directory, int maximumSnapshots)
    {
        // Only rolling Recovery-* copies of this document type are pruned.
        // StudentFinish/final checkpoints are not touched.
        string? cleanupWarning = null;
        try
        {
            var oldCopies = Directory.GetFiles(directory, "Recovery-*" + Path.GetExtension(snapshot.FilePath))
                .OrderByDescending(path => Path.GetFileName(path), StringComparer.Ordinal)
                .Skip(maximumSnapshots);
            foreach (string oldPath in oldCopies) File.Delete(oldPath);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            cleanupWarning = "The new snapshot is verified, but some older copies could not be removed: " + ex.Message;
        }
        return snapshot with { CleanupWarning = cleanupWarning };
    }
}
