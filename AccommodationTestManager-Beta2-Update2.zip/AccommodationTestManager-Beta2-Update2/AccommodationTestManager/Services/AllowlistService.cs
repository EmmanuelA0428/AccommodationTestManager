using AccommodationTestManager.Models;
using System.IO;
using System.Text.RegularExpressions;

namespace AccommodationTestManager.Services;
public sealed class AllowlistService(LocalStorageService storage)
{
    public string Folder => Path.Combine(storage.Root,"Configuration","Allowlists");
    public void Initialize()
    {
        Directory.CreateDirectory(Folder);
        foreach(string file in Directory.GetFiles(Path.Combine(AppContext.BaseDirectory,"Configuration","Allowlists"),"*.json"))
        {string target=Path.Combine(Folder,Path.GetFileName(file));if(!File.Exists(target))File.Copy(file,target);}
    }
    public List<AllowlistConfiguration> LoadAll()=>Directory.GetFiles(Folder,"*.json").Select(LocalStorageService.ReadJson<AllowlistConfiguration>).OrderBy(x=>x.Id).ToList();
    public AllowlistConfiguration Load(string id)
    {
        ValidateId(id);var value=LocalStorageService.ReadJson<AllowlistConfiguration>(Path.Combine(Folder,id+".json"));Validate(value);return value;
    }
    public void Save(AllowlistConfiguration value)
    {Validate(value);LocalStorageService.WriteJson(Path.Combine(Folder,value.Id+".json"),value);}
    public static void ValidateId(string id)
    {if(!Regex.IsMatch(id,@"^[a-z0-9][a-z0-9-]{0,39}$"))throw new InvalidOperationException("List ID must use lowercase letters, digits and hyphens, at most 40 characters.");}
    public static List<string> Normalize(IEnumerable<string> lines)
    {
        var result=new List<string>();
        foreach(string raw in lines)
        {
            string value=raw.Trim().Trim('"','\'',',').Trim();if(value.Length==0)continue;
            if(!value.Contains("://"))value="https://"+value;
            value=value.Replace("https://*.","https://",StringComparison.OrdinalIgnoreCase);
            if(value.EndsWith("/*",StringComparison.Ordinal))value=value[..^1];
            if(value=="*"||value.Contains('*')||value.Contains('[')||value.Contains('<'))throw new InvalidOperationException("Use HTTPS host or path-prefix filters; global/embedded wildcards and formatted text are not accepted.");
            if(!Uri.TryCreate(value,UriKind.Absolute,out var uri)||uri.Scheme!="https"||uri.Host.Length==0||uri.UserInfo.Length>0||uri.Query.Length>0||uri.Fragment.Length>0)
                throw new InvalidOperationException("Enter HTTPS hosts/path prefixes without credentials, queries or fragments: "+value);
            result.Add(value.TrimEnd('/'));
        }
        return result.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }
    public static void Validate(AllowlistConfiguration value)
    {
        ValidateId(value.Id);if(value.Version<1)throw new InvalidOperationException("Allowlist version must be positive.");
        if(value.UrlPatterns is null||value.UrlPatterns.Count>999)throw new InvalidOperationException("At most 999 entries: one Edge exception is reserved for staff policy inspection.");
        value.UrlPatterns=Normalize(value.UrlPatterns);
    }
    public static bool AllowsStart(AllowlistConfiguration list,string url)
    {
        if(!Uri.TryCreate(url,UriKind.Absolute,out var target)||target.Scheme!="https")return false;
        return list.UrlPatterns.Any(pattern=>
        {
            var rule=new Uri(pattern);string host=rule.Host;bool exact=host.StartsWith('.');host=host.TrimStart('.');
            return (target.Host.Equals(host,StringComparison.OrdinalIgnoreCase)||!exact&&target.Host.EndsWith("."+host,StringComparison.OrdinalIgnoreCase))&&target.AbsolutePath.StartsWith(rule.AbsolutePath,StringComparison.Ordinal)&&target.Port==rule.Port;
        });
    }
}
