using AccommodationTestManager.Models;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Threading;

namespace AccommodationTestManager.Services;

public sealed class WordAutomationService : IDisposable
{
    private readonly Thread _thread;

    private readonly TaskCompletionSource<Dispatcher> _ready =
        new(TaskCreationOptions.RunContinuationsAsynchronously);

    private readonly SemaphoreSlim _operationGate = new(1, 1);

    // These COM objects are accessed only on the Word thread.
    private dynamic? _application;
    private dynamic? _document;
    private string? _expectedPath;

    private bool _disposed;

    public WordAutomationService()
    {
        _thread = new Thread(() =>
        {
            Dispatcher dispatcher = Dispatcher.CurrentDispatcher;

            _ready.SetResult(dispatcher);

            // Keeps this STA thread alive and processes its messages.
            Dispatcher.Run();
        })
        {
            IsBackground = true,
            Name = "Word automation"
        };

        _thread.SetApartmentState(ApartmentState.STA);
        _thread.Start();
    }

    // ------------------------------------------------------------
    // Open
    // ------------------------------------------------------------

    public Task<WordDocumentStatus> OpenAsync(string filePath)
    {
        string fullPath = Path.GetFullPath(filePath);

        if (!File.Exists(fullPath))
            throw new FileNotFoundException(
                "The selected document does not exist.", fullPath);

        string extension = Path.GetExtension(fullPath);

        if (!extension.Equals(".docx", StringComparison.OrdinalIgnoreCase) &&
            !extension.Equals(".doc", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "Choose a .docx or .doc document.");
        }

        return RunAsync(() =>
        {
            if (_document is not null)
            {
                throw new InvalidOperationException(
                    "Close the current test document before opening another.");
            }

            EnsureWordApplication();

            object? documentsObject = null;

            try
            {
                documentsObject = _application!.Documents;
                dynamic documents = documentsObject;

                _document = documents.Open(
                    FileName: fullPath,
                    ConfirmConversions: false,
                    ReadOnly: false,
                    AddToRecentFiles: false);

                _expectedPath = fullPath;

                _application.Visible = true;
                _document.Activate();

                return ReadStatus();
            }
            finally
            {
                ReleaseComObject(documentsObject);
            }
        });
    }

    private void EnsureWordApplication()
    {
        if (_application is not null)
            return;

        Type wordType = Type.GetTypeFromProgID("Word.Application")
            ?? throw new InvalidOperationException(
                "Desktop Microsoft Word is not installed or registered.");

        _application = Activator.CreateInstance(wordType)
            ?? throw new InvalidOperationException(
                "Microsoft Word could not be started.");

        // Prevent macros from running in documents opened by automation.
        // 3 = msoAutomationSecurityForceDisable.
        _application.AutomationSecurity = 3;

        // Keep Word dialogs visible. Do not silently accept warnings.
        _application.Visible = true;
    }

    // ------------------------------------------------------------
    // Inspect
    // ------------------------------------------------------------

    public Task<WordDocumentStatus> GetStatusAsync()
    {
        return RunAsync(ReadStatus);
    }

    private WordDocumentStatus ReadStatus()
    {
        EnsureDocument();

        string actualPath = (string)_document!.FullName;
        bool readOnly = (bool)_document.ReadOnly;
        bool saved = (bool)_document.Saved;

        // Detect Save As or a document path changing unexpectedly.
        if (!string.Equals(
                Path.GetFullPath(actualPath),
                _expectedPath,
                StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException(
                "The document location changed. Staff review is required.");
        }

        return new WordDocumentStatus(
            actualPath,
            readOnly,
            HasUnsavedChanges: !saved);
    }

    // ------------------------------------------------------------
    // Save
    // ------------------------------------------------------------

    public Task<WordDocumentStatus> SaveAsync() => RunAsync(SaveCore);

    private WordDocumentStatus SaveCore()
    {
        WordDocumentStatus before = ReadStatus();
        if (before.IsReadOnly) throw new InvalidOperationException("Word opened this document read-only. Its protection will not be bypassed.");
        if ((int)_application!.BackgroundSavingStatus != 0)
            throw new IOException("Word is still saving. Wait briefly, then retry; the working document is preserved.");
        object? optionsObject = null;
        bool previousBackgroundSave = true;
        bool restoreOption = false;
        try
        {
            optionsObject = _application.Options;
            dynamic options = optionsObject;
            previousBackgroundSave = (bool)options.BackgroundSave;
            options.BackgroundSave = false;
            restoreOption = true;
            if (before.HasUnsavedChanges) _document!.Save();
            WordDocumentStatus after = ReadStatus();
            if (after.HasUnsavedChanges || (int)_application.BackgroundSavingStatus != 0)
                throw new IOException("Word has not finished saving. The app will not claim a verified save.");
            if (!File.Exists(after.FilePath) || new FileInfo(after.FilePath).Length == 0)
                throw new IOException("Saved document could not be verified on disk.");
            return after;
        }
        finally
        {
            try { if (restoreOption && optionsObject is not null) ((dynamic)optionsObject).BackgroundSave = previousBackgroundSave; }
            finally { ReleaseComObject(optionsObject); }
        }
    }

    // Save, file capture and post-capture Word state checks share the same STA gate.
    // Word has no Excel-style SaveCopyAs API; never SaveAs away from the working path.
    public Task<RecoverySnapshot> CaptureSnapshotAsync(Func<WordDocumentStatus, RecoverySnapshot> capture)
        => RunAsync(() =>
        {
            var saved = SaveCore();
            RecoverySnapshot snapshot = capture(saved);
            try
            {
                var after = ReadStatus();
                if (after.HasUnsavedChanges || (int)_application!.BackgroundSavingStatus != 0)
                    throw new IOException("Document changed while making its recovery copy. Retrying without discarding work.");
                return snapshot;
            }
            catch { try { File.Delete(snapshot.FilePath); } catch { } throw; }
        });

    // ------------------------------------------------------------
    // Safe close
    // ------------------------------------------------------------

    public Task CloseAsync()
    {
        return RunAsync(() =>
        {
            WordDocumentStatus status = ReadStatus();

            if (status.HasUnsavedChanges)
            {
                throw new InvalidOperationException(
                    "The document has unsaved changes. " +
                    "Save it before closing.");
            }

            // The document is already saved.
            // 0 = wdDoNotSaveChanges; no silent save or discard decision.
            _document!.Close(0);

            ReleaseComObject((object)_document);
            _document = null;
            _expectedPath = null;

            // Do not close other documents the user might have opened
            // in this Word instance.
            object? documentsObject = null;

            try
            {
                documentsObject = _application!.Documents;
                dynamic documents = documentsObject;

                if ((int)documents.Count == 0)
                {
                    _application.Quit(0);

                    ReleaseComObject((object)_application);
                    _application = null;
                }
            }
            finally
            {
                ReleaseComObject(documentsObject);
            }

            return true;
        });
    }

    private void EnsureDocument()
    {
        if (_document is null)
        {
            throw new InvalidOperationException(
                "No document is connected. Open a document first.");
        }
    }

    // ------------------------------------------------------------
    // Threading and temporary Word-busy errors
    // ------------------------------------------------------------

    private async Task<T> RunAsync<T>(Func<T> operation)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);

        await _operationGate.WaitAsync();

        try
        {
            ObjectDisposedException.ThrowIf(_disposed, this);

            Dispatcher dispatcher = await _ready.Task;

            // Word may temporarily reject calls while busy.
            // Retry briefly; never retry every kind of error.
            for (int attempt = 0; ; attempt++)
            {
                try
                {
                    return await dispatcher.InvokeAsync(operation).Task;
                }
                catch (COMException ex)
                    when (IsTemporaryBusyError(ex) && attempt < 5)
                {
                    await Task.Delay(300);
                }
            }
        }
        finally
        {
            _operationGate.Release();
        }
    }

    private static bool IsTemporaryBusyError(COMException exception)
    {
        return exception.HResult == unchecked((int)0x80010001)
            || exception.HResult == unchecked((int)0x8001010A);
    }

    // ------------------------------------------------------------
    // Cleanup
    // ------------------------------------------------------------

    private static void ReleaseComObject(object? value)
    {
        if (value is not null && Marshal.IsComObject(value))
            Marshal.ReleaseComObject(value);
    }

    public void Dispose()
    {
        if (_disposed)
            return;

        _disposed = true;

        Dispatcher dispatcher = _ready.Task.GetAwaiter().GetResult();

        // This is queued behind any Word operation already executing.
        dispatcher.BeginInvoke(new Action(() =>
        {
            try
            {
                // Detach only. Do not close Word or discard student work
                // merely because the application window is closing.
                ReleaseComObject((object?)_document);
                _document = null;

                ReleaseComObject((object?)_application);
                _application = null;

                _expectedPath = null;
            }
            finally
            {
                dispatcher.BeginInvokeShutdown(
                    DispatcherPriority.Background);
            }
        }));
    }
}