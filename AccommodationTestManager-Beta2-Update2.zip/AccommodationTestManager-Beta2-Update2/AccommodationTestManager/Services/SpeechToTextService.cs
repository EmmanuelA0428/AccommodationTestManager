using System.Diagnostics;
using System.IO;

namespace AccommodationTestManager.Services;

// Voice Access retains its native toolbar and listening controls.
// Process presence is never presented as microphone/listening status.
public sealed class SpeechToTextService
{
    public string EnsureRunning()
    {
        using Process current = Process.GetCurrentProcess();
        Process[] processes = Process.GetProcessesByName("VoiceAccess");
        try
        {
            foreach (Process process in processes)
            {
                try
                {
                    if (!process.HasExited && process.SessionId == current.SessionId)
                        return "Voice Access is already running in this Windows session. Use its native controls to enable listening.";
                }
                catch (InvalidOperationException) { /* Process exited during inspection. */ }
                catch (System.ComponentModel.Win32Exception) { /* Can't inspect this process. */ }
            }
        }
        finally { foreach (Process process in processes) process.Dispose(); }

        string executable = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            "System32", "VoiceAccess.exe");
        if (!File.Exists(executable))
            throw new FileNotFoundException("Voice Access was not found. Check Windows accessibility settings and install its language model before testing.");
        using Process? launched = Process.Start(new ProcessStartInfo(executable) { UseShellExecute = true });
        return "Voice Access launch requested. Use its native controls to enable listening. Launching does not confirm microphone or language-model readiness.";
    }
}
