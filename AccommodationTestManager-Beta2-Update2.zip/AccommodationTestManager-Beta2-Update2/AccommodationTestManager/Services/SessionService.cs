using AccommodationTestManager.Models;
using System.Diagnostics;
using System.IO;
using System.Windows.Threading;

namespace AccommodationTestManager.Services;

// Local-beta lifecycle coordinator. One gate serializes saves, finish, resume and export.
// Machine controls are delegated to the separately authorized protected helper; no user impersonation.
public sealed class SessionService : IDisposable
{
    private readonly LocalStorageService _storage;
    private readonly SettingsService _settings;
    private readonly AllowlistService? _allowlists;
    private readonly RestrictionService? _restrictions;
    public Func<Task<bool>>? ConfirmRemoveStorage { get; set; }
    public bool IsOnline => Current is not null && (Current.Mode is "Canvas" or "Posit" || Current.Mode=="Custom" && Current.CustomKind=="Website");
    private WordAutomationService _word = new();
    private RecoverySnapshotService _recovery;
    private readonly SemaphoreSlim _gate = new(1, 1);
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromSeconds(5) };
    private bool _connected;
    private bool _disposed;
    private int _busy;
    public bool IsBusy => _busy > 0;
    public TestSession? Current { get; private set; }
    public string? Folder { get; private set; }
    public event EventHandler<string>? Changed;
    public SessionService(LocalStorageService storage, SettingsService settings, AllowlistService? allowlists=null, RestrictionService? restrictions=null)
    {
        _storage = storage; _settings = settings; _allowlists=allowlists;_restrictions=restrictions; _recovery = new(_word);
        _timer.Tick += PeriodicTick; _timer.Start();
    }
    private async Task Run(Func<Task> operation)
    {
        ObjectDisposedException.ThrowIf(_disposed, this);
        Interlocked.Increment(ref _busy);
        try { await _gate.WaitAsync(); try { await operation(); } finally { _gate.Release(); } }
        finally { Interlocked.Decrement(ref _busy); }
    }
    private void Notify(string message) => Changed?.Invoke(this, message);
    private void Commit(Action<TestSession> change, string action, string staff = "", string detail = "")
    {
        if (Current is null || Folder is null) throw new InvalidOperationException("No session selected.");
        var next = LocalStorageService.Clone(Current);
        change(next);
        next.Events.Add(new(Guid.NewGuid().ToString("N"), DateTimeOffset.UtcNow, action, staff, detail, _settings.Current.StaffMembers.FirstOrDefault(x=>x.Name==staff)?.Id??""));
        LocalStorageService.WriteJson(Path.Combine(Folder, "session.json"), next);
        Current = next;
        Notify(action);
    }
    public async Task StartAsync(TestSetupDraft draft) => await Run(async () =>
    {
        if (Current is not null || _storage.ListSessions(true).Count != 0) throw new InvalidOperationException("Resolve the unfinished session before starting another.");
        if (string.IsNullOrWhiteSpace(draft.StudentName) || string.IsNullOrWhiteSpace(draft.TestName) || !_settings.Current.StaffNames.Contains(draft.StaffName))
            throw new InvalidOperationException("Student, test and a registered staff member are required.");
        if (draft.Preset is not ("Word" or "Canvas" or "Posit" or "Custom")) throw new InvalidOperationException("Choose Word, Canvas, Posit or Custom.");
        int? duration = null;
        if (draft.UseTimeLimit)
        {
            if (!int.TryParse(draft.DurationText, out int value) || value < 1 || value > 1440) throw new InvalidOperationException("Duration must be 1–1440 minutes.");
            duration = value;
        }
        bool online=draft.Preset is "Canvas" or "Posit" || draft.Preset=="Custom" && draft.CustomKind=="Website";
        string startUrl=draft.Preset=="Canvas"?_settings.Current.CanvasUrl:draft.Preset=="Posit"?_settings.Current.PositUrl:draft.CustomUrl;
        string listId=draft.Preset=="Canvas"?"canvas":draft.Preset=="Posit"?"posit":draft.AllowlistId;
        AllowlistConfiguration? selectedList=null;
        if(online)
        {
            selectedList=_allowlists?.Load(listId)??throw new InvalidOperationException("Configure an allowlist in Settings first.");
            if(selectedList.UrlPatterns.Count==0||!AllowlistService.AllowsStart(selectedList,startUrl))throw new InvalidOperationException("Starting URL is missing or outside its allowlist. Configure it in Settings.");
        }
        if(draft.Preset=="Custom"&&draft.CustomKind=="Desktop"&&(draft.SelectedApplication is null||!_settings.Current.ApprovedApplications.Any(a=>a.Id==draft.SelectedApplication.Id)||!File.Exists(draft.SelectedApplication.Executable)))
            throw new InvalidOperationException("Choose a staff-approved installed application in Settings.");
        if(_settings.Current.RequireMachineRestrictions&&(_restrictions is null||!_restrictions.IsInstalled))throw new InvalidOperationException("Install the protected Beta 2 helper before required-control tests. Or explicitly choose an unenforced synthetic test in Settings.");
        if(_settings.Current.EnableApplicationLockdown)throw new InvalidOperationException("Application lockdown is required but is not implemented. Startup blocked.");
        if(_restrictions?.PendingIds().Count>0)throw new InvalidOperationException("Unresolved machine state exists. Use Settings → Emergency restore before a new test.");
        if (draft.Preset == "Word")
        {
            string ext = Path.GetExtension(draft.DocumentPath).ToLowerInvariant();
            if (!File.Exists(draft.DocumentPath) || (ext != ".docx" && ext != ".doc")) throw new InvalidOperationException("Choose an existing .docx or .doc file.");
        }
        var record = new TestSession
        {
            Id = Guid.NewGuid().ToString("N"), DeviceId = _settings.Current.DeviceId, LaptopName = _settings.Current.LaptopName,
            StudentName = draft.StudentName.Trim(), TestName = draft.TestName.Trim(), Mode = draft.Preset,
            CustomKind=draft.CustomKind,ApplicationId=draft.SelectedApplication?.Id??"",ApplicationPath=draft.SelectedApplication?.Executable??"",
            AllowlistId=online?listId:"",AllowedUrls=selectedList?.UrlPatterns.ToArray()??[],
            StartedById=_settings.Current.StaffMembers.FirstOrDefault(x=>x.Name==draft.StaffName&&x.Active)?.Id??"",
            StartedBy = draft.StaffName, CreatedUtc = DateTimeOffset.UtcNow, DurationMinutes = duration,
            TextToSpeech = draft.TextToSpeech, SpeechToText = draft.SpeechToText,
            WebUrl = online ? startUrl.Trim() : "",
            SettingsSnapshot = LocalStorageService.Clone(_settings.Current)
        };
        // Do not copy authentication material into session records.
        record.SettingsSnapshot.StaffPinHash = ""; record.SettingsSnapshot.StaffPinSalt = "";
        Folder = _storage.NewSessionFolder(record.Id); Current = record;
        LocalStorageService.WriteJson(Path.Combine(Folder, "session.json"), record);
        Commit(_ => { }, "Session prepared", draft.StaffName);
        if (record.Mode == "Word" || record.Mode=="Custom"&&record.CustomKind=="Desktop"&&!string.IsNullOrWhiteSpace(draft.DocumentPath))
        {
            string extension = Path.GetExtension(draft.DocumentPath).ToLowerInvariant();
            string relative = Path.Combine("Working", "Exam" + extension);
            string destination = _storage.FileInSession(Folder, relative);
            string hash = await Task.Run(() => LocalStorageService.CopyVerified(draft.DocumentPath, destination));
            File.SetAttributes(destination, File.GetAttributes(destination) & ~FileAttributes.ReadOnly);
            Commit(s => { s.SourcePath = Path.GetFullPath(draft.DocumentPath); s.OriginalFileName = Path.GetFileName(draft.DocumentPath); s.SourceSha256 = hash; s.WorkingRelativePath = relative; }, "Import verified", draft.StaffName);
        }
        // Never move a folder after opening its working document in Word.
        Folder = _storage.MoveArea(Folder, "Active");
        Commit(s => s.Status = "Starting", "Starting applications", draft.StaffName);
        if(Current!.SettingsSnapshot.RequireMachineRestrictions)
        {
            if(ConfirmRemoveStorage is null||!await ConfirmRemoveStorage())throw new OperationCanceledException("Remove-storage confirmation cancelled; imported files preserved. Cancel preparation or retry recovery.");
            await _restrictions!.ApplyAsync(Current);
            Commit(s=>{s.RestrictionsApplied=true;s.SecurityStatus="Scoped machine controls applied; staff live verification pending. NO app lockdown / protected exam storage / in-site AI prevention.";},"Machine controls applied",draft.StaffName);
        }
        else Commit(s=>s.SecurityStatus="UNENFORCED — explicitly selected synthetic test", "Unenforced mode selected",draft.StaffName);
        await OpenCurrentAsync();
        DateTimeOffset now = DateTimeOffset.UtcNow;
        Commit(s => { s.Status = s.RestrictionsApplied ? "Preflight" : "Active"; s.StartedUtc = s.RestrictionsApplied ? null : now; s.DeadlineUtc = s.RestrictionsApplied || duration is null ? null : now.AddMinutes(duration.Value); s.LastSaveUtc = s.Mode == "Word" ? now : null; s.LastSaveHealth = s.Mode == "Word" ? "Initial save verified" : "Website saves/submission must be verified by staff"; }, "Test started", draft.StaffName);
    });
    private async Task OpenCurrentAsync()
    {
        var s = Current ?? throw new InvalidOperationException("No current session.");
        if (s.Mode == "Word")
        {
            if (string.IsNullOrWhiteSpace(s.WorkingRelativePath)) throw new IOException("Import is incomplete. Cancel preparation, preserve files, and retry with a new session.");
            if (!_connected)
            {
                await _word.OpenAsync(_storage.FileInSession(Folder!, s.WorkingRelativePath));
                _connected = true;
            }
            try
            {
                var saved = await _word.SaveAsync();
                if (saved.IsReadOnly) throw new IOException("Working document is read-only. No protections were bypassed.");
            }
            catch
            {
                // Detach a stale/read-only connection; leave Word and files intact for staff.
                _word.Dispose(); _word = new(); _recovery = new(_word); _connected = false;
                throw;
            }
        }
        else if(s.Mode=="Custom"&&s.CustomKind=="Desktop")
        {
            var launch=new ProcessStartInfo(s.ApplicationPath){UseShellExecute=false};
            if(!string.IsNullOrWhiteSpace(s.WorkingRelativePath))launch.ArgumentList.Add(_storage.FileInSession(Folder!,s.WorkingRelativePath));
            using Process? custom=Process.Start(launch);if(custom is null)throw new IOException("Custom app launch failed.");
        }
        else
        {
            string? edge = new[] {
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86), "Microsoft", "Edge", "Application", "msedge.exe"),
                Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "Microsoft", "Edge", "Application", "msedge.exe")
            }.FirstOrDefault(File.Exists);
            if (edge is null) throw new FileNotFoundException("Microsoft Edge was not found.");
            // Start URL only; not an allowlist or kiosk enforcement mechanism.
            var start = new ProcessStartInfo(edge) { UseShellExecute = false };
            start.ArgumentList.Add("--user-data-dir="+_storage.FileInSession(Folder!,s.BrowserProfileRelativePath));
            start.ArgumentList.Add("--no-first-run");start.ArgumentList.Add("--new-window"); start.ArgumentList.Add(s.WebUrl);
            using Process? launched = Process.Start(start);
            if (launched is null) throw new IOException("Edge launch did not return a process.");
        }
    }
    public Task AdoptAsync(SessionEntry entry, string staff) => Run(() =>
    {
        if (Current is not null) throw new InvalidOperationException("A session is already selected.");
        _storage.EnsureSessionFolder(entry.Folder);
        Folder = entry.Folder; Current = LocalStorageService.ReadJson<TestSession>(Path.Combine(Folder, "session.json"));
        Commit(_ => { }, "Recovery reviewed", staff);
        return Task.CompletedTask;
    });
    public Task ResumeAsync(string staff) => Run(async () =>
    {
        if (Current is null || Current.Status is not ("Active" or "AwaitingStaff" or "Starting" or "Preflight" or "RecoveryRequired")) throw new InvalidOperationException("This state cannot resume. Use the staff export/recovery flow.");
        if(Current.RestrictionsApplied&&Current.DeadlineUtc is not null&&Current.Status=="Active")
            Commit(s=>s.RemainingSeconds=Math.Max(0,(s.DeadlineUtc!.Value-DateTimeOffset.UtcNow).TotalSeconds),"Timer paused for preflight",staff);
        if(Current.SettingsSnapshot.RequireMachineRestrictions)
        {
            if(_restrictions is null)throw new InvalidOperationException("Restriction helper unavailable; resume blocked.");
            string state=_restrictions?.Status(Current.Id)??"Missing";
            if(state=="ExportAccess")throw new InvalidOperationException("Export access is open. Finish export/restore first; do not resume with USB enabled.");
            if(state is "Restored" or "Missing")
            {
                if(ConfirmRemoveStorage is null||!await ConfirmRemoveStorage())throw new OperationCanceledException("Storage-removal confirmation cancelled.");
                await _restrictions!.ApplyAsync(Current);
                Commit(s=>{s.RestrictionsApplied=true;s.RestrictionsRestored=false;s.Status="Preflight";},"Controls reapplied",staff);
            }
            else if(state!="Applied")throw new InvalidOperationException("Machine state requires Emergency Restore before resume.");
        }
        if (Current.Mode == "Word" && _connected)
        {
            try { await _word.GetStatusAsync(); }
            catch { _word.Dispose(); _word = new(); _recovery = new(_word); _connected = false; }
        }
        await OpenCurrentAsync();
        var now = DateTimeOffset.UtcNow;
        Commit(s => {
            if (s.StartedUtc is null) { s.StartedUtc = now; s.DeadlineUtc = s.DurationMinutes is null ? null : now.AddMinutes(s.DurationMinutes.Value); }
            else if (s.Status == "AwaitingStaff" && s.RemainingSeconds is not null) s.DeadlineUtc = now.AddSeconds(s.RemainingSeconds.Value);
            s.Status = s.RestrictionsApplied ? "Preflight" : "Active"; s.FinishedUtc = null; s.LastSaveHealth = s.Mode == "Word" ? "Word reconnected; save verified" : "Staff must verify website state";
        }, "Session resumed", staff);
    });
    public Task FinishAsync() => Run(async () =>
    {
        if (Current?.Status != "Active") throw new InvalidOperationException("Only an active session can finish.");
        if (Current.Mode == "Word")
        {
            if (!_connected) throw new InvalidOperationException("Reconnect Word through staff recovery first.");
            var snapshot = await _recovery.CreateAsync(_storage.FileInSession(Folder!, "Recovery"), Current.SettingsSnapshot.MaximumRecoveryCopies);
            string relative = Path.Combine("Checkpoints", "StudentFinish-" + Guid.NewGuid().ToString("N") + Path.GetExtension(Current.WorkingRelativePath));
            string hash = await Task.Run(() => LocalStorageService.CopyVerified(snapshot.FilePath, _storage.FileInSession(Folder!, relative)));
            // Refuses unsaved new edits after the save. Never discard those changes.
            await _word.CloseAsync(); _connected = false;
            // A student might save a NEW edit between snapshot and Close. Check closed bytes,
            // not only Word.Saved, so an older checkpoint is never accepted as the final work.
            if (LocalStorageService.HashFile(_storage.FileInSession(Folder!, Current.WorkingRelativePath)) != snapshot.Sha256)
                throw new IOException("The document changed during Finish. The latest working file is preserved. Staff must reconnect Word and retry Finish.");
            Commit(s => { s.FinishRelativePath = relative; s.FinishSha256 = hash; s.LastSaveUtc = DateTimeOffset.UtcNow; s.LastSaveHealth = "Student checkpoint verified; Word closed safely"; s.RecoveryReceipts.Add(new(Path.GetRelativePath(Folder!, snapshot.FilePath), snapshot.Sha256, snapshot.CreatedAt)); s.RecoveryReceipts = s.RecoveryReceipts.TakeLast(s.SettingsSnapshot.MaximumRecoveryCopies).ToList(); }, "Student checkpoint verified");
        }
        Commit(s => { s.Status = "AwaitingStaff"; s.FinishedUtc = DateTimeOffset.UtcNow; if (s.DeadlineUtc is not null) s.RemainingSeconds = Math.Max(0, (s.DeadlineUtc.Value - DateTimeOffset.UtcNow).TotalSeconds); }, "Student finished");
        // Online browser is NOT locked or closed; UI explicitly warns staff.
    });
    public Task MarkEmergencyRestoreAsync() => Run(()=>
    {
        if(Current is not null)Commit(s=>{if(s.DeadlineUtc is not null)s.RemainingSeconds=Math.Max(0,(s.DeadlineUtc.Value-DateTimeOffset.UtcNow).TotalSeconds);s.Status="RecoveryRequired";s.RestrictionsRestored=true;s.SecurityStatus="Machine state restored — test paused; reapply + preflight before continuing";},"Emergency restore acknowledged");
        return Task.CompletedTask;
    });
    public Task ConfirmPreflightAsync(string staff) => Run(() =>
    {
        if(Current?.Status!="Preflight")throw new InvalidOperationException("No pending preflight.");
        if(Current.SettingsSnapshot.RequireMachineRestrictions&&_restrictions?.Status(Current.Id)!="Applied")throw new InvalidOperationException("Machine state is not Applied; handoff blocked.");
        DateTimeOffset now=DateTimeOffset.UtcNow;
        Commit(s=>{s.Status="Active";s.StartedUtc??=now;if(s.DurationMinutes is not null)s.DeadlineUtc=now.AddSeconds(s.RemainingSeconds??s.DurationMinutes.Value*60);s.SecurityStatus="Scoped controls configured + staff live checks confirmed. NO app lockdown, protected data broker, or in-site AI control.";},"Staff preflight confirmed",staff);
        return Task.CompletedTask;
    });
    public Task OpenExportAccessAsync(string staff) => Run(async()=>
    {
        if(Current is null||Current.Status is not ("AwaitingStaff" or "ExportPending" or "Completing"))throw new InvalidOperationException("Finish before enabling staff export access.");
        if(Current.RestrictionsApplied&&_restrictions is not null && _restrictions.Status(Current.Id) is not ("Missing" or "Restored"))await _restrictions.ExportAccessAsync(Current.Id);
        Commit(_=>{},"Staff export access requested",staff);
    });
    public Task PrepareCustomFinalAsync(string source,string staff) => Run(async()=>
    {
        if(Current?.Mode!="Custom"||Current.CustomKind!="Desktop"||Current.Status!="AwaitingStaff")throw new InvalidOperationException("Finish the custom desktop test first.");
        string relative=Path.Combine("Final","CompletedExam-"+Guid.NewGuid().ToString("N")+Path.GetExtension(source));
        string hash=await Task.Run(()=>LocalStorageService.CopyVerified(source,_storage.FileInSession(Folder!,relative)));
        Commit(s=>{s.FinalRelativePath=relative;s.FinalSha256=hash;s.Status="ExportPending";s.FinalizedBy=staff;s.LastSaveHealth="Staff verified manual saving; final bytes copied and hashed";},"Custom final imported",staff);
    });
    public Task PrepareFinalAsync(string staff) => Run(() =>
    {
        if (Current?.Status == "ExportPending") return Task.CompletedTask;
        if (Current?.Status != "AwaitingStaff" || Current.Mode != "Word") throw new InvalidOperationException("Finish the Word test before exporting.");
        string checkpoint = _storage.FileInSession(Folder!, Current.FinishRelativePath);
        if (LocalStorageService.HashFile(checkpoint) != Current.FinishSha256) throw new IOException("Checkpoint hash changed. Staff review required; no export performed.");
        string relative = Path.Combine("Final", "CompletedExam-" + Guid.NewGuid().ToString("N") + Path.GetExtension(checkpoint));
        string hash = LocalStorageService.CopyVerified(checkpoint, _storage.FileInSession(Folder!, relative));
        Commit(s => { s.FinalRelativePath = relative; s.FinalSha256 = hash; s.Status = "ExportPending"; s.FinalizedBy = staff; }, "Final copy verified", staff);
        return Task.CompletedTask;
    });
    public Task ExportAsync(string destination, string staff) => Run(async () =>
    {
        if (Current?.Status != "ExportPending") throw new InvalidOperationException("Final copy is not ready.");
        string final = _storage.FileInSession(Folder!, Current.FinalRelativePath);
        if (LocalStorageService.HashFile(final) != Current.FinalSha256) throw new IOException("Final copy hash changed. No export performed.");
        string full = Path.GetFullPath(destination);
        string root = Path.GetFullPath(_storage.Root).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar;
        if (full.StartsWith(root, StringComparison.OrdinalIgnoreCase)) throw new IOException("Choose an export destination outside app storage.");
        if (File.Exists(full)) throw new IOException("Choose a new filename. Existing files are never overwritten by this beta.");
        if (!string.IsNullOrEmpty(Current.SourcePath) && string.Equals(full, Current.SourcePath, StringComparison.OrdinalIgnoreCase)) throw new IOException("Cannot overwrite the original exam.");
        string hash = await Task.Run(() => LocalStorageService.CopyVerified(final, full));
        Commit(s => { s.ExportPath = full; s.ExportSha256 = hash; s.FinalizedBy = staff; }, "Export verified", staff);
    });
    public Task CompleteAsync(string staff, bool onlineSubmissionConfirmed = false) => Run(async () =>
    {
        if (Current is null) throw new InvalidOperationException("No session.");
        if (Current.Mode == "Word"||Current.Mode=="Custom"&&Current.CustomKind=="Desktop")
        {
            if (Current.Status is not ("ExportPending" or "Completing") || string.IsNullOrWhiteSpace(Current.ExportPath)) throw new InvalidOperationException("Export the final document first.");
            if (LocalStorageService.HashFile(Current.ExportPath) != Current.ExportSha256 ||
                LocalStorageService.HashFile(_storage.FileInSession(Folder!, Current.FinalRelativePath)) != Current.FinalSha256)
                throw new IOException("Final/export verification failed. Keep the export drive connected and retry.");
        }
        else if (Current.Status is not ("AwaitingStaff" or "Completing") || !onlineSubmissionConfirmed)
            throw new InvalidOperationException("Staff must verify the website's save/submission before completing.");
        if (_connected) throw new InvalidOperationException("Close Word safely before moving a session.");
        Commit(s => { s.Status = "Completing"; s.SubmissionVerifiedByStaff = onlineSubmissionConfirmed; s.FinalizedBy = staff; }, "Completion prepared", staff);
        if(Current.RestrictionsApplied)
        {
            if(_restrictions is null)throw new IOException("Restriction helper unavailable; completion blocked.");
            await _restrictions.RestoreAsync(Current.Id);
            Commit(s=>{s.RestrictionsRestored=true;s.SecurityStatus="Recorded previous machine state restored";},"Machine state restored",staff);
        }
        Folder = _storage.MoveArea(Folder!, "Completed");
        Commit(s => { s.Status = "Completed"; s.CompletedUtc = DateTimeOffset.UtcNow; }, "Session completed", staff,
            "Control restoration recorded separately. Retention is manual.");
        Current = null; Folder = null; Notify("Session completed");
        return;
    });
    public Task CancelPreparationAsync(string staff) => Run(async () =>
    {
        if (Current?.Status is not ("Preparing" or "Starting" or "Preflight")) throw new InvalidOperationException("Only incomplete preparation can be cancelled. Preserve active tests for recovery/export.");
        if (_connected) { await _word.CloseAsync(); _connected = false; }
        if(_restrictions is not null && _restrictions.Status(Current!.Id) is not ("Missing" or "Restored"))await _restrictions.RestoreAsync(Current.Id);
        Commit(s => { s.Status = "Cancelled"; s.FinalizedBy = staff; s.CompletedUtc = DateTimeOffset.UtcNow; }, "Preparation cancelled", staff, "Local files preserved. No student test was finalized.");
        Folder = _storage.MoveArea(Folder!, "Completed");
        Current = null; Folder = null; Notify("Preparation cancelled");
    });
    public Task RecoverLatestWorkingCopyAsync(string staff) => Run(async () =>
    {
        if (Current is null || Current.Mode != "Word" || Current.Status is not ("Active" or "AwaitingStaff" or "Starting" or "Preflight" or "RecoveryRequired"))
            throw new InvalidOperationException("Select an unfinished Word session first.");
        if (_connected) { await _word.CloseAsync(); _connected = false; }
        SnapshotReceipt? receipt = null;
        foreach (var candidate in Current.RecoveryReceipts.OrderByDescending(x => x.CreatedUtc))
        {
            string path = _storage.FileInSession(Folder!, candidate.RelativePath);
            try { if (LocalStorageService.HashFile(path) == candidate.Sha256) { receipt = candidate; break; } }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { }
        }
        if (receipt is null) throw new IOException("No remaining recorded recovery copy passed its hash check. Preserve all files; ask staff/IT for manual review.");
        string relative = Path.Combine("Working", "Exam-Recovered-" + Guid.NewGuid().ToString("N") + Path.GetExtension(receipt.RelativePath));
        string hash = await Task.Run(() => LocalStorageService.CopyVerified(_storage.FileInSession(Folder!, receipt.RelativePath), _storage.FileInSession(Folder!, relative)));
        if (hash != receipt.Sha256) throw new IOException("Recovered working copy hash did not match its receipt.");
        // Switch metadata only after new copy verifies. Never overwrite/delete old working files.
        Commit(s => {
            s.WorkingRelativePath = relative; s.Status = "Starting"; s.LastSaveUtc = null; s.LastSnapshotUtc = null;
            if (s.RemainingSeconds is not null) s.DeadlineUtc = DateTimeOffset.UtcNow.AddSeconds(s.RemainingSeconds.Value);
            s.LastSaveHealth = "Recovery copy restored; verify its contents and Resume to reopen Word";
        }, "Working copy recovered", staff, receipt.RelativePath + " | " + receipt.CreatedUtc.ToString("O"));
    });
    public Task RecordHelpAsync() => Run(() => { Commit(_ => { }, "Student requested staff help"); return Task.CompletedTask; });
    public Task SaveNowAsync() => Run(async () => await SaveCoreAsync(forceSnapshot: false));
    private async Task SaveCoreAsync(bool forceSnapshot)
    {
        if (Current?.Status != "Active" || Current.Mode != "Word" || !_connected) return;
        await _word.SaveAsync();
        Commit(s => { s.LastSaveUtc = DateTimeOffset.UtcNow; s.LastSaveHealth = "Saved state confirmed"; }, "Saved state confirmed");
        bool due = forceSnapshot || Current.LastSnapshotUtc is null || (DateTimeOffset.UtcNow - Current.LastSnapshotUtc.Value).TotalSeconds >= Current.SettingsSnapshot.SnapshotIntervalSeconds;
        if (due)
        {
            var snapshot = await _recovery.CreateAsync(_storage.FileInSession(Folder!, "Recovery"), Current.SettingsSnapshot.MaximumRecoveryCopies);
            Commit(s => { s.LastSnapshotUtc = DateTimeOffset.UtcNow; s.LastSaveHealth = snapshot.CleanupWarning ?? "Save and recovery copy verified"; s.RecoveryReceipts.Add(new(Path.GetRelativePath(Folder!, snapshot.FilePath), snapshot.Sha256, snapshot.CreatedAt)); s.RecoveryReceipts = s.RecoveryReceipts.TakeLast(s.SettingsSnapshot.MaximumRecoveryCopies).ToList(); }, "Recovery copy verified", detail: Path.GetFileName(snapshot.FilePath));
        }
    }
    private async void PeriodicTick(object? sender, EventArgs e)
    {
        if(!_disposed&&!IsBusy&&Current?.Status=="Active"&&Current.RestrictionsApplied&&_restrictions is not null)
        {
            try{if(_restrictions.Status(Current.Id)!="Applied"){await MarkEmergencyRestoreAsync();return;}}
            catch{Notify("Machine state unreadable; staff must pause/review.");return;}
        }
        if (_disposed || IsBusy || Current?.Status != "Active" || Current.Mode != "Word" || !_connected) return;
        if (Current.LastSaveUtc is not null && (DateTimeOffset.UtcNow - Current.LastSaveUtc.Value).TotalSeconds < Current.SettingsSnapshot.SaveIntervalSeconds) return;
        try
        {
            await Run(async () =>
            {
                try { await SaveCoreAsync(false); }
                catch (Exception ex)
                {
                    try { Commit(s => s.LastSaveHealth = "Save/recovery needs staff review: " + ex.Message, "Save/recovery failed"); }
                    catch { Notify("Save and metadata update failed. Preserve Word and contact staff."); }
                }
            });
        }
        catch { Notify("Periodic check stopped. Staff review required."); }
    }
    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true; _timer.Stop(); _timer.Tick -= PeriodicTick;
        // Leave unfinished records and Word intact for next-start recovery.
        _word.Dispose();
    }
}
