using AccommodationTestManager.Models;
using System.Diagnostics;
using System.IO;
using System.Security.Principal;
using System.Text.Json;

namespace AccommodationTestManager.Services;
public sealed class RestrictionService
{
    public string StateRoot=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"AccommodationTestingBeta2","RestrictionState");
    private string Helper=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"AccommodationTestManagerBeta2","Scripts","Beta2Restrictions.ps1");
    public bool IsInstalled=>File.Exists(Helper)&&Directory.Exists(StateRoot);
    public string CapabilitySummary()
    {
        using var os=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        return $"Windows edition: {os?.GetValue("EditionID")} · build {os?.GetValue("CurrentBuild")}\nProtected helper installed: {IsInstalled}\nImplemented: adapter isolation, USB storage policy, Edge policy configuration/restore.\nNOT implemented: application lockdown, protected student-data broker, all-AI prevention. Live device/browser checks remain mandatory.";
    }
    public List<string> PendingIds()
    {
        if(!Directory.Exists(StateRoot))return [];
        return Directory.GetFiles(StateRoot,"*.json").Where(p=>!p.EndsWith(".report.json",StringComparison.OrdinalIgnoreCase)).Where(p=>Status(Path.GetFileNameWithoutExtension(p))!="Restored").Select(Path.GetFileNameWithoutExtension).OfType<string>().ToList();
    }
    public string Status(string id)
    {
        if(!Guid.TryParseExact(id,"N",out _))throw new InvalidOperationException("Invalid session ID.");
        string file=Path.Combine(StateRoot,id+".json");if(!File.Exists(file))return "Missing";
        using var document=JsonDocument.Parse(File.ReadAllText(file));return document.RootElement.GetProperty("Status").GetString()??"Unknown";
    }
    public async Task ApplyAsync(TestSession session)
    {
        if(!IsInstalled)throw new InvalidOperationException("Install Beta 2 in protected Program Files before machine restriction tests. No restrictions were attempted.");
        if(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new InvalidOperationException("Run the WPF app as the standard testing account; authorize the helper with a separate administrator account.");
        if(session.SettingsSnapshot.EnableApplicationLockdown)throw new InvalidOperationException("Application lockdown is not implemented; required control cannot be verified. Startup blocked.");
        bool online=session.Mode is "Canvas" or "Posit"||session.Mode=="Custom"&&session.CustomKind=="Website";
        bool networkRequired=session.Mode=="Custom"&&session.CustomKind=="Desktop"&&session.SettingsSnapshot.ApprovedApplications.FirstOrDefault(x=>x.Id==session.ApplicationId)?.NetworkRequired==true;
        string request=Path.Combine(Path.GetTempPath(),"ATM-Beta2-"+Guid.NewGuid().ToString("N")+".json");
        try
        {
            LocalStorageService.WriteJson(request,new{Mode=online?"Online":session.Mode=="Word"?"Word":"Desktop",IsolateNetwork=!online&&!networkRequired,Allowlist=session.AllowedUrls,DisableBrowserAI=session.SettingsSnapshot.DisableBrowserAI,BlockedAIUrls=session.SettingsSnapshot.DisableBrowserAI?session.SettingsSnapshot.BlockedAIUrls:[],ApplicationLockdown=session.SettingsSnapshot.EnableApplicationLockdown});
            await RunHelper("Apply",session.Id,request);
            if(Status(session.Id)!="Applied")throw new IOException("Machine restriction apply was not confirmed.");
        }
        finally{File.Delete(request);}
    }
    public async Task ExportAccessAsync(string id){if(Status(id)=="ExportAccess")return;await RunHelper("ExportAccess",id);if(Status(id)!="ExportAccess")throw new IOException("USB export access was not restored.");}
    public async Task RestoreAsync(string id){if(Status(id)=="Restored")return;await RunHelper("Restore",id);if(Status(id)!="Restored")throw new IOException("Previous machine state was not restored.");}
    private async Task RunHelper(string action,string id,string? request=null)
    {
        if(!IsInstalled)throw new IOException("Protected helper is missing.");
        var info=new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell","v1.0","powershell.exe")){UseShellExecute=true,Verb="runas",WindowStyle=ProcessWindowStyle.Hidden};
        foreach(string arg in new[]{"-NoProfile","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",Helper,"-Action",action,"-SessionId",id})info.ArgumentList.Add(arg);
        if(request is not null){info.ArgumentList.Add("-RequestPath");info.ArgumentList.Add(request);}
        using Process process=Process.Start(info)??throw new IOException("Admin helper did not start.");await process.WaitForExitAsync();
        if(process.ExitCode!=0)
        {
            string detail="";
            try
            {
                string snapshot=Path.Combine(StateRoot,id+".json");
                if(File.Exists(snapshot)){using var data=JsonDocument.Parse(File.ReadAllText(snapshot));if(data.RootElement.TryGetProperty("Detail",out var value))detail=value.GetString()??"";}
            }
            catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or JsonException){detail="Snapshot could not be read; preserve it for IT review.";}
            throw new IOException("Machine action failed or was cancelled. Preserve the snapshot; use Emergency Restore if needed."+(detail.Length>0?"\n\nRecorded detail: "+detail:""));
        }
    }
}
