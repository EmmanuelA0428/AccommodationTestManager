using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Security.AccessControl;
using System.Security.Principal;

namespace AccommodationTestManager.Services;

public static class AdminPinResetService
{
    public static async Task<string> AuthorizeAsync()
    {
        if(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))
            throw new InvalidOperationException("Open the app normally under the standard testing account. PIN reset requires fresh, separate administrator authorization.");
        string root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"AccommodationTestManagerBeta2");
        string helper=Path.Combine(root,"Scripts","Beta2PinReset.ps1");
        if(!File.Exists(helper))throw new IOException("Install Update 1's protected helper before using administrator PIN reset.");
        for(DirectoryInfo? d=new DirectoryInfo(Path.GetDirectoryName(helper)!);d is not null;d=d.Parent)
            if((d.Attributes & FileAttributes.ReparsePoint)!=0)throw new IOException("Protected helper path contains a reparse point.");
        if((File.GetAttributes(helper)&FileAttributes.ReparsePoint)!=0)throw new IOException("Protected helper must not be a link.");
        string name="ATM-PinReset-"+Guid.NewGuid().ToString("N");
        string challenge=Convert.ToHexString(System.Security.Cryptography.RandomNumberGenerator.GetBytes(32));
        var security=new PipeSecurity();security.SetAccessRuleProtection(true,false);
        security.AddAccessRule(new PipeAccessRule(WindowsIdentity.GetCurrent().User!,PipeAccessRights.FullControl,AccessControlType.Allow));
        security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null),PipeAccessRights.FullControl,AccessControlType.Allow));
        security.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.LocalSystemSid,null),PipeAccessRights.FullControl,AccessControlType.Allow));
        using var pipe=NamedPipeServerStreamAcl.Create(name,PipeDirection.InOut,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous | PipeOptions.FirstPipeInstance,4096,4096,security);
        var info=new ProcessStartInfo(Path.Combine(Environment.SystemDirectory,"WindowsPowerShell","v1.0","powershell.exe")){UseShellExecute=true,Verb="runas",WindowStyle=ProcessWindowStyle.Hidden};
        foreach(string arg in new[]{"-NoProfile","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",helper,"-PipeName",name,"-Challenge",challenge})info.ArgumentList.Add(arg);
        using var process=Process.Start(info)??throw new IOException("Administrator authorization did not start.");
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(90));
        await pipe.WaitForConnectionAsync(timeout.Token);
        using var reader=new StreamReader(pipe,System.Text.Encoding.UTF8,false,1024,leaveOpen:true);
        var text=new System.Text.StringBuilder();char[] ch=new char[1];
        while(text.Length<66&&await reader.ReadAsync(ch.AsMemory(),timeout.Token)!=0){if(ch[0]=='\n')break;text.Append(ch[0]);}
        string reply=text.ToString().TrimEnd('\r');
        if(reply!=challenge)throw new UnauthorizedAccessException("Administrator authorization challenge did not match.");
        string? identity=null;bool administrator=false;
        pipe.RunAsClient(()=>{using var user=WindowsIdentity.GetCurrent(TokenAccessLevels.Query);administrator=new WindowsPrincipal(user).IsInRole(WindowsBuiltInRole.Administrator);identity=user.Name;});
        if(!administrator||string.IsNullOrWhiteSpace(identity))throw new UnauthorizedAccessException("The connected Windows token is not an elevated administrator.");
        using(var writer=new StreamWriter(pipe,new System.Text.UTF8Encoding(false),1024,leaveOpen:true){AutoFlush=true})await writer.WriteLineAsync("verified");
        await process.WaitForExitAsync(timeout.Token);
        if(process.ExitCode!=0)throw new IOException("Administrator approval did not complete.");
        return identity;
    }
}
