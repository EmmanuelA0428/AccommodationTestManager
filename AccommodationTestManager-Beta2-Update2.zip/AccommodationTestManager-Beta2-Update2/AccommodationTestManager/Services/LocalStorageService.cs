using AccommodationTestManager.Models;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;

namespace AccommodationTestManager.Services;

public sealed class LocalStorageService
{
    public static readonly JsonSerializerOptions JsonOptions = new() { WriteIndented = true, PropertyNameCaseInsensitive = true };
    // Beta-only storage. Production ProgramData ACL/broker installation is not implemented.
    public string Root { get; } = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AccommodationTestManager-Beta1");
    public string SettingsPath => Path.Combine(Root, "Configuration", "app-settings.json");
    public LocalStorageService(string? testRoot = null)
    {
        // Explicit test override is used by the automated storage/lifecycle tests only.
        if (testRoot is not null) Root = Path.GetFullPath(testRoot);
        foreach (string area in new[] { "Preparing", "Active", "Completed" }) Directory.CreateDirectory(Path.Combine(Root, "Sessions", area));
        Directory.CreateDirectory(Path.GetDirectoryName(SettingsPath)!);
    }
    public static T Clone<T>(T value) => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(value, JsonOptions), JsonOptions)!;
    public static void WriteJson<T>(string path, T value)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            byte[] bytes = JsonSerializer.SerializeToUtf8Bytes(value, JsonOptions);
            using (var stream = new FileStream(temp, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            { stream.Write(bytes); stream.Flush(true); }
            if (File.Exists(path)) File.Replace(temp, path, path + ".bak", ignoreMetadataErrors: false);
            else File.Move(temp, path);
        }
        finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    public static T ReadJson<T>(string path) => JsonSerializer.Deserialize<T>(File.ReadAllText(path), JsonOptions)
        ?? throw new IOException("Empty or invalid JSON: " + Path.GetFileName(path));
    public string NewSessionFolder(string id)
    {
        if (!Guid.TryParseExact(id, "N", out _)) throw new IOException("Invalid session identifier.");
        string folder = Path.Combine(Root, "Sessions", "Preparing", id);
        Directory.CreateDirectory(folder);
        return folder;
    }
    public string MoveArea(string folder, string area)
    {
        if (area is not ("Active" or "Completed")) throw new IOException("Invalid lifecycle area.");
        EnsureSessionFolder(folder);
        string destination = Path.Combine(Root, "Sessions", area, Path.GetFileName(folder));
        if (!string.Equals(folder, destination, StringComparison.OrdinalIgnoreCase)) Directory.Move(folder, destination);
        return destination;
    }
    public void EnsureSessionFolder(string folder)
    {
        string full = Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar);
        string parent = Path.GetDirectoryName(full)!;
        string area = Path.GetFileName(parent);
        if (!Guid.TryParseExact(Path.GetFileName(full), "N", out _) || area is not ("Preparing" or "Active" or "Completed") ||
            !string.Equals(Path.GetDirectoryName(parent), Path.Combine(Root, "Sessions"), StringComparison.OrdinalIgnoreCase))
            throw new IOException("Session path is outside the approved local storage.");
        RejectReparse(full);
    }
    public string FileInSession(string folder, string relative)
    {
        EnsureSessionFolder(folder);
        if (string.IsNullOrWhiteSpace(relative) || Path.IsPathRooted(relative)) throw new IOException("Invalid session-relative path.");
        string full = Path.GetFullPath(Path.Combine(folder, relative));
        if (!full.StartsWith(Path.GetFullPath(folder).TrimEnd(Path.DirectorySeparatorChar) + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
            throw new IOException("Session path traversal rejected.");
        RejectReparse(full);
        return full;
    }
    private static void RejectReparse(string path)
    {
        for (string? current = path; current is not null; current = Path.GetDirectoryName(current))
            if ((File.Exists(current) || Directory.Exists(current)) && (File.GetAttributes(current) & FileAttributes.ReparsePoint) != 0)
                throw new IOException("Reparse-point storage paths are not supported by this beta.");
    }
    public static string HashFile(string path)
    {
        using var file = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.Read);
        if (file.Length == 0) throw new IOException("Document is empty.");
        return Convert.ToHexString(SHA256.HashData(file));
    }
    public static string CopyVerified(string source, string destination)
    {
        if (string.Equals(Path.GetFullPath(source), Path.GetFullPath(destination), StringComparison.OrdinalIgnoreCase)) throw new IOException("Source and destination must differ.");
        Directory.CreateDirectory(Path.GetDirectoryName(destination)!);
        string partial = destination + "." + Guid.NewGuid().ToString("N") + ".partial";
        try
        {
            using var input = new FileStream(source, FileMode.Open, FileAccess.Read, FileShare.Read);
            if (input.Length == 0) throw new IOException("Source document is empty.");
            string originalHash = Convert.ToHexString(SHA256.HashData(input)); input.Position = 0;
            using (var output = new FileStream(partial, FileMode.CreateNew, FileAccess.Write, FileShare.None))
            { input.CopyTo(output); output.Flush(true); }
            if (HashFile(partial) != originalHash) throw new IOException("Copied file failed SHA-256 verification.");
            File.Move(partial, destination, overwrite: false);
            // Read back the published file; important for removable destinations.
            if (HashFile(destination) != originalHash) throw new IOException("Published file verification failed.");
            return originalHash;
        }
        finally { if (File.Exists(partial)) File.Delete(partial); }
    }
    public void RestoreMetadataBackup(SessionEntry entry, string staff)
    {
        EnsureSessionFolder(entry.Folder);
        string currentPath = Path.Combine(entry.Folder, "session.json");
        string backupPath = currentPath + ".bak";
        if (!File.Exists(backupPath)) throw new IOException("No metadata backup exists. Preserve all files and ask IT to review this session manually.");
        var record = ReadJson<TestSession>(backupPath);
        if (record.Id != Path.GetFileName(entry.Folder)) throw new IOException("Backup ID does not match the session folder.");
        string id = Guid.NewGuid().ToString("N");
        File.Copy(backupPath, Path.Combine(entry.Folder, "session-backup-preserved-" + id + ".json"));
        if (File.Exists(currentPath)) File.Copy(currentPath, Path.Combine(entry.Folder, "session-damaged-preserved-" + id + ".json"));
        record.Events.Add(new(Guid.NewGuid().ToString("N"), DateTimeOffset.UtcNow, "Metadata backup restored by staff", staff,
            "Backup may be older than current files. Check working files, checkpoints and export receipts before proceeding."));
        WriteJson(currentPath, record);
    }
    public List<SessionEntry> ListSessions(bool unfinishedOnly = false)
    {
        var result = new List<SessionEntry>();
        foreach (string area in new[] { "Preparing", "Active", "Completed" })
            foreach (string folder in Directory.GetDirectories(Path.Combine(Root, "Sessions", area)))
            {
                EnsureSessionFolder(folder);
                string file = Path.Combine(folder, "session.json");
                TestSession record;
                try
                {
                    if (!File.Exists(file)) throw new IOException("Session metadata missing.");
                    record = ReadJson<TestSession>(file);
                    if (record.Id != Path.GetFileName(folder)) throw new IOException("Session ID mismatch.");
                }
                catch (Exception ex) when (ex is IOException or JsonException or UnauthorizedAccessException)
                {
                    // Fail closed for new tests, but allow staff to see the damaged session.
                    record = new TestSession { Id = Path.GetFileName(folder), Status = "NeedsReview", TestName = "Metadata needs review", LastSaveHealth = ex.Message, CreatedUtc = Directory.GetCreationTimeUtc(folder) };
                }
                if (!unfinishedOnly || record.Status is not ("Completed" or "Cancelled")) result.Add(new(folder, record));
            }
        return result.OrderByDescending(x => x.Session.CreatedUtc).ToList();
    }
}
