using Microsoft.Win32;
using System.ComponentModel;
using System.Windows;
using System.Windows.Media;

namespace AccommodationTestManager.Services;
public sealed class ThemeService(SettingsService settings) : IDisposable
{
    private bool _hooked;
    public void Apply()
    {
        if (!_hooked) { SystemEvents.UserPreferenceChanged += PreferencesChanged; SystemParameters.StaticPropertyChanged += SystemChanged; _hooked = true; }
        bool dark = settings.Current.Theme == "Dark" || settings.Current.Theme == "System" && WindowsDark();
        // WPF ThemeMode is still marked experimental in .NET 10; scoped opt-in only.
#pragma warning disable WPF0001
        Application.Current.ThemeMode = settings.Current.Theme switch { "Dark" => ThemeMode.Dark, "Light" => ThemeMode.Light, _ => ThemeMode.System };

#pragma warning restore WPF0001
        var colors = dark
            ? new Dictionary<string, string> { ["AppCanvasBrush"]="#151A23",["AppSurfaceBrush"]="#202733",["AppTextBrush"]="#F4F6FA",["AppMutedBrush"]="#BDC7D8",["AppAccentBrush"]="#8BB7FF",["AppDividerBrush"]="#4D5B70",["AppInputBorderBrush"]="#8E9BB0",["AppSelectedBrush"]="#263B5D",["AppWarningBrush"]="#FFCF95",["AppWarningSurfaceBrush"]="#3F3022",["AppErrorBrush"]="#FFA8A8" }
            : new Dictionary<string, string> { ["AppCanvasBrush"]="#F4F6F8",["AppSurfaceBrush"]="#FFFFFF",["AppTextBrush"]="#172033",["AppMutedBrush"]="#475467",["AppAccentBrush"]="#175CD3",["AppDividerBrush"]="#D0D5DD",["AppInputBorderBrush"]="#8A94A6",["AppSelectedBrush"]="#EFF4FF",["AppWarningBrush"]="#93370D",["AppWarningSurfaceBrush"]="#FFFAEB",["AppErrorBrush"]="#B42318" };
        colors["AppPrimaryBackgroundBrush"]="#175CD3";colors["AppPrimaryForegroundBrush"]="#FFFFFF";
        foreach (var pair in colors) Application.Current.Resources[pair.Key] = new SolidColorBrush((Color)ColorConverter.ConvertFromString(pair.Value));
        if (SystemParameters.HighContrast)
        {
            foreach (string key in new[] { "AppCanvasBrush", "AppSurfaceBrush", "AppWarningSurfaceBrush", "AppPrimaryBackgroundBrush" }) Application.Current.Resources[key] = SystemColors.WindowBrush;
            foreach (string key in new[] { "AppTextBrush", "AppMutedBrush", "AppWarningBrush", "AppErrorBrush", "AppPrimaryForegroundBrush" }) Application.Current.Resources[key] = SystemColors.WindowTextBrush;
            Application.Current.Resources["AppSelectedBrush"] = SystemColors.WindowBrush;
            foreach (string key in new[] { "AppAccentBrush", "AppDividerBrush", "AppInputBorderBrush" }) Application.Current.Resources[key] = SystemColors.WindowTextBrush;
        }
    }
    private static bool WindowsDark()
    {
        using var key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize");
        return key?.GetValue("AppsUseLightTheme") is int value && value == 0;
    }
    private void PreferencesChanged(object sender, UserPreferenceChangedEventArgs e) => Application.Current.Dispatcher.BeginInvoke(new Action(Apply));
    private void SystemChanged(object? sender, PropertyChangedEventArgs e)
    { if (e.PropertyName == nameof(SystemParameters.HighContrast)) Application.Current.Dispatcher.BeginInvoke(new Action(Apply)); }
    public void Dispose()
    {
        if (!_hooked) return;
        SystemEvents.UserPreferenceChanged -= PreferencesChanged; SystemParameters.StaticPropertyChanged -= SystemChanged;
    }
}
