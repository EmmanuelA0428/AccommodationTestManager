using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace AccommodationTestManager.Services;

public sealed class AutoSaveService : IDisposable
{
    private readonly WordAutomationService _word;
    private readonly Dispatcher _dispatcher;
    private readonly DispatcherTimer _timer;

    private bool _busy;
    private bool _disposed;
    private int _runVersion;

    public event EventHandler<string>? StatusChanged;

    public bool IsRunning => _timer.IsEnabled;

    public bool IsBusy => _busy;

    // This is when the app last confirmed the saved state.
    // It is not necessarily when Word last wrote changes.
    public DateTimeOffset? LastConfirmedSavedAt { get; private set; }

    public AutoSaveService(
        WordAutomationService word,
        int intervalSeconds = 60)
    {
        if (intervalSeconds < 1)
            throw new ArgumentOutOfRangeException(nameof(intervalSeconds));

        _word = word;

        _dispatcher = Application.Current?.Dispatcher
            ?? throw new InvalidOperationException(
                "Create AutoSaveService after WPF starts.");

        _dispatcher.VerifyAccess();

        _timer = new DispatcherTimer
        {
            Interval = TimeSpan.FromSeconds(intervalSeconds)
        };

        _timer.Tick += OnTimerTick;
    }

    public void Start()
    {
        CheckAccess();

        if (IsRunning)
            return;

        _runVersion++;
        LastConfirmedSavedAt = null;
        _timer.Start();

        Report(
            $"Automatic save checks enabled: " +
            $"every {_timer.Interval.TotalSeconds:0} seconds.");
    }

    public void Stop()
    {
        CheckAccess();

        _timer.Stop();
        _runVersion++;

        // A Word save already in progress is allowed to finish.
        Report("Automatic save checks stopped.");
    }

    private async void OnTimerTick(
        object? sender,
        EventArgs e)
    {
        // Prevent overlapping periodic checks.
        if (_disposed || !IsRunning || _busy)
            return;

        _busy = true;
        int version = _runVersion;

        try
        {
            Report("Checking Word save state…");

            // SaveAsync already:
            // - rejects read-only documents
            // - saves only when changes exist
            // - checks Word's saved state
            // - checks the file exists and is nonempty
            await _word.SaveAsync();

            if (!IsCurrentRun(version))
                return;

            LastConfirmedSavedAt = DateTimeOffset.Now;

            Report(
                $"Saved state confirmed at " +
                $"{LastConfirmedSavedAt.Value:HH:mm:ss}.");
        }
        catch (Exception ex)
        {
            if (IsCurrentRun(version))
            {
                Report(
                    $"Automatic save check failed: {ex.Message} " +
                    "Your document has not been closed. " +
                    "The next scheduled check will retry.");
            }
        }
        finally
        {
            _busy = false;
        }
    }

    private bool IsCurrentRun(int version)
    {
        return !_disposed
            && IsRunning
            && version == _runVersion;
    }

    private void Report(string message)
    {
        StatusChanged?.Invoke(this, message);
    }

    private void CheckAccess()
    {
        _dispatcher.VerifyAccess();
        ObjectDisposedException.ThrowIf(_disposed, this);
    }

    public void Dispose()
    {
        _dispatcher.VerifyAccess();

        if (_disposed)
            return;

        _disposed = true;
        _runVersion++;

        _timer.Stop();
        _timer.Tick -= OnTimerTick;

        // This service does not own WordAutomationService,
        // so it must not dispose or close Word.
    }
}