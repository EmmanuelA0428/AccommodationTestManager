using AccommodationTestManager.Models;
using System.IO;
using System.Security.Cryptography;
using System.Text;

namespace AccommodationTestManager.Services;

public sealed class SettingsService(LocalStorageService storage)
{
    public AppSettings Current { get; private set; } = new();
    private int _failures;
    private DateTimeOffset _blockedUntil;
    public void Load()
    {
        var previous = Current;
        try
        {
        if (!File.Exists(storage.SettingsPath))
        {
            string bundled = Path.Combine(AppContext.BaseDirectory, "Configuration", "default-settings.json");
            Current = LocalStorageService.ReadJson<AppSettings>(bundled);
            Current.DeviceId = Guid.NewGuid().ToString("N");
            Save();
        }
        else Current = LocalStorageService.ReadJson<AppSettings>(storage.SettingsPath);
        if(Current.StaffMembers.Count==0&&Current.StaffNames.Length>0)
        {
            Current.StaffMembers=Current.StaffNames.Select(name=>new StaffMember{Name=name}).ToList();
            Current.SchemaVersion=2;
            if(string.IsNullOrWhiteSpace(Current.CanvasUrl))Current.CanvasUrl="https://canvas.hws.edu/";
            if(string.IsNullOrWhiteSpace(Current.PositUrl))Current.PositUrl="https://posit.cloud/";
            Save();
        }
        Validate();
        }
        catch { Current = previous; throw; }
    }
    public void Save() { if(Current.StaffMembers.Count>0)Current.StaffNames=Current.StaffMembers.Where(s=>s.Active).Select(s=>s.Name).ToArray(); Validate(); LocalStorageService.WriteJson(storage.SettingsPath, Current); }
    public void Reload() { Load(); Current.ConfigVersion++; Save(); }
    public void Update(AppSettings value)
    {
        var previous=Current;Current=value;
        try { Save(); } catch { Current=previous;throw; }
    }
    private void Validate()
    {
        if (!Guid.TryParseExact(Current.DeviceId, "N", out _)) throw new IOException("Invalid DeviceId in settings; don't reset an existing laptop's identity.");
        if (Current.SaveIntervalSeconds < 10 || Current.SnapshotIntervalSeconds < Current.SaveIntervalSeconds || Current.MaximumRecoveryCopies < 1 || Current.MaximumRecoveryCopies > 100)
            throw new IOException("Save interval must be at least 10 seconds; snapshot interval must be at least the save interval; recovery copies must be 1–100.");
        if (Current.DefaultTimeLimitMinutes is <= 0 or > 1440) throw new IOException("Default time limit must be null or 1–1440 minutes.");
        if (Current.Theme is not ("Light" or "Dark" or "System")) throw new IOException("Theme must be Light, Dark, or System.");
        if(Current.StaffMembers is null||Current.ApprovedApplications is null)throw new IOException("Staff/application collections cannot be null.");
        if(Current.StaffMembers.Any(s=>string.IsNullOrWhiteSpace(s.Name)||!Guid.TryParseExact(s.Id,"N",out _))||Current.StaffMembers.GroupBy(s=>s.Id).Any(g=>g.Count()>1)||Current.StaffMembers.Where(s=>s.Active).GroupBy(s=>s.Name,StringComparer.OrdinalIgnoreCase).Any(g=>g.Count()>1))throw new IOException("Staff need unique IDs and distinct nonempty active names.");
        if (Current.StaffNames is null || Current.CanvasAllowlist is null || Current.PositAllowlist is null) throw new IOException("Staff/allowlist settings must be arrays, not null.");
    }
    public bool IsRegistered => !string.IsNullOrWhiteSpace(Current.LaptopName) && Current.StaffNames.Length > 0 && !string.IsNullOrWhiteSpace(Current.StaffPinHash);
    public void Register(string laptopName, string assetTag, string[] staff, string pin)
    {
        if (string.IsNullOrWhiteSpace(laptopName) || staff.Length == 0 || pin.Length < 6 || !pin.All(char.IsDigit))
            throw new InvalidOperationException("Enter a laptop name, at least one staff name, and a PIN of at least six digits.");
        Current.LaptopName = laptopName.Trim(); Current.AssetTag = assetTag.Trim(); Current.StaffNames = staff; Current.StaffMembers = staff.Select(name=>new StaffMember{Name=name}).ToList();
        byte[] salt = RandomNumberGenerator.GetBytes(16);
        Current.StaffPinSalt = Convert.ToBase64String(salt);
        Current.StaffPinHash = Convert.ToBase64String(Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(pin), salt, 100000, HashAlgorithmName.SHA256, 32));
        Save();
    }
    public void ChangePin(string newPin)
    {
        if(newPin.Length<6||!newPin.All(char.IsDigit))throw new InvalidOperationException("PIN must have at least six digits.");
        byte[] salt=RandomNumberGenerator.GetBytes(16);
        Current.StaffPinSalt=Convert.ToBase64String(salt);
        Current.StaffPinHash=Convert.ToBase64String(Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(newPin),salt,100000,HashAlgorithmName.SHA256,32));Save();
    }
    public void ResetPinAfterAdministratorApproval(string newPin,string administrator)
    {
        if(string.IsNullOrWhiteSpace(administrator))throw new InvalidOperationException("Verified administrator identity required.");
        var previous=LocalStorageService.Clone(Current);
        try { Current.LastAdminPinResetUtc=DateTimeOffset.UtcNow;Current.LastAdminPinResetBy=administrator;ChangePin(newPin);_failures=0;_blockedUntil=DateTimeOffset.MinValue; }
        catch {Current=previous;throw;}
    }
    public bool VerifyPin(string pin)
    {
        if (DateTimeOffset.UtcNow < _blockedUntil) throw new InvalidOperationException("Too many attempts. Wait 60 seconds before retrying.");
        byte[] expected = Convert.FromBase64String(Current.StaffPinHash);
        byte[] actual = Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(pin), Convert.FromBase64String(Current.StaffPinSalt), 100000, HashAlgorithmName.SHA256, 32);
        bool match = CryptographicOperations.FixedTimeEquals(expected, actual);
        if (match) _failures = 0;
        else if (++_failures >= 5) { _blockedUntil = DateTimeOffset.UtcNow.AddSeconds(60); _failures = 0; }
        return match;
    }
}
