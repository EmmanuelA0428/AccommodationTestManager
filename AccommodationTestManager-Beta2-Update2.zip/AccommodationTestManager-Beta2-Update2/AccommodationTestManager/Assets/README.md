Reserved for approved app icons/images. Current controls use native text labels and do not depend on external image assets.
