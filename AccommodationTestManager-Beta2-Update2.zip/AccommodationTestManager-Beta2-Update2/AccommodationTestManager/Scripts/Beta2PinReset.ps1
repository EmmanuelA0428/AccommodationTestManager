# Protected authorization helper. Receives no PIN or credentials.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][ValidatePattern('^ATM-PinReset-[a-f0-9]{32}$')][string]$PipeName,
      [Parameter(Mandatory=$true)][ValidatePattern('^[A-F0-9]{64}$')][string]$Challenge)
$ErrorActionPreference='Stop'
$env:PSModulePath=Join-Path $PSHOME 'Modules'
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
if(-not (New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Fresh elevated administrator approval required.'}
$pipe=New-Object IO.Pipes.NamedPipeClientStream('.', $PipeName, [IO.Pipes.PipeDirection]::InOut, [IO.Pipes.PipeOptions]::None, [Security.Principal.TokenImpersonationLevel]::Identification)
try {
 $pipe.Connect(15000)
 $writer=New-Object IO.StreamWriter($pipe,(New-Object Text.UTF8Encoding($false)),1024,$true);$writer.AutoFlush=$true
 $reader=New-Object IO.StreamReader($pipe,[Text.Encoding]::UTF8,$false,1024,$true)
 $writer.WriteLine($Challenge)
 if($reader.ReadLine()-ne 'verified'){throw 'Authorization was not acknowledged.'}
 $writer.Dispose();$reader.Dispose()
} finally { $pipe.Dispose();$identity.Dispose() }
