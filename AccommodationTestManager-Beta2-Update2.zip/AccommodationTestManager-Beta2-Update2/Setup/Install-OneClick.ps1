# Embedded setup operation; invoked only by the elevated setup EXE.
# Installs files/ACLs only. Never applies network/USB/Edge test restrictions.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$PayloadFolder,[Parameter(Mandatory=$true)][string]$DocsFolder)
$ErrorActionPreference='Stop'
# Use only built-in Windows PowerShell modules in this installer process.
# A parent PowerShell 7 process can otherwise pass conflicting module paths.
$env:PSModulePath=Join-Path $PSHOME 'Modules'
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1') -ErrorAction Stop
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator approval required.'}
if(-not [Environment]::Is64BitProcess){throw 'Setup must invoke 64-bit Windows PowerShell.'}
$build=[int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber
if($build-lt 22000){throw 'This beta requires Windows 11 x64.'}
$install=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2'
$stateParent='C:\ProgramData\AccommodationTestingBeta2'
$state=Join-Path $stateParent 'RestrictionState'
function Assert-NoReparse([string]$Path){
 $current=[IO.Path]::GetFullPath($Path)
 while($current){if(Test-Path -LiteralPath $current){if((Get-Item -LiteralPath $current -Force).Attributes-band [IO.FileAttributes]::ReparsePoint){throw ('Reparse-point path rejected: '+$current)}};$parent=[IO.Path]::GetDirectoryName($current);if($parent-eq $current){break};$current=$parent}
}
function Protect-Folder([string]$Path){
 Assert-NoReparse $Path;New-Item -ItemType Directory -Path $Path -Force|Out-Null
 $acl=New-Object Security.AccessControl.DirectorySecurity;$acl.SetAccessRuleProtection($true,$false)
 $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')))
 foreach($entry in @(@('S-1-5-18','FullControl'),@('S-1-5-32-544','FullControl'),@('S-1-5-32-545','ReadAndExecute'))){
  $sid=New-Object Security.Principal.SecurityIdentifier($entry[0]);$rule=New-Object Security.AccessControl.FileSystemAccessRule($sid,$entry[1],'ContainerInherit,ObjectInherit','None','Allow');$acl.AddAccessRule($rule)
 };Set-Acl -LiteralPath $Path -AclObject $acl
}
function Check-UnresolvedState {
 Assert-NoReparse $state
 if(Test-Path -LiteralPath $state){foreach($file in Get-ChildItem -LiteralPath $state -Filter '*.json' -File){
  Assert-NoReparse $file.FullName;$record=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
  if($record.Status-ne 'Restored'){throw 'Unresolved machine restriction snapshot exists. Restore it with the current app/helper before updating. No snapshot or exam file was deleted.'}
 }}
}
if(@(Get-Process AccommodationTestManager -ErrorAction SilentlyContinue).Count-gt 0){throw 'Close Accommodation Test Manager normally before installation/update. Do not discard unfinished work.'}
Check-UnresolvedState
Assert-NoReparse $install;Assert-NoReparse $stateParent;Assert-NoReparse $PayloadFolder;Assert-NoReparse $DocsFolder
foreach($needed in @('AccommodationTestManager.exe','AccommodationTestManager.dll','coreclr.dll','hostfxr.dll','Scripts\Beta2Restrictions.ps1','Scripts\Beta2PinReset.ps1')){
 if(-not(Test-Path -LiteralPath (Join-Path $PayloadFolder $needed))){throw ('Bundled setup payload incomplete: '+$needed)}
}
$id=[guid]::NewGuid().ToString('N');$staging=Join-Path $env:ProgramFiles ('AccommodationTestManagerBeta2-setup-'+$id);$backup=Join-Path $env:ProgramFiles ('AccommodationTestManagerBeta2-backup-'+$id)
$swapped=$false;$hadPrevious=Test-Path -LiteralPath $install
try {
 Protect-Folder $staging
 Copy-Item -Path (Join-Path $PayloadFolder '*') -Destination $staging -Recurse -Force
 New-Item -ItemType Directory -Path (Join-Path $staging 'Docs') -Force|Out-Null
 Copy-Item -Path (Join-Path $DocsFolder '*') -Destination (Join-Path $staging 'Docs') -Recurse -Force
 $files=@(Get-ChildItem -LiteralPath $staging -Recurse -File|ForEach-Object{$_.FullName.Substring($staging.Length+1)})
 foreach($file in Get-ChildItem -LiteralPath $PayloadFolder -Recurse -File){
  $relative=$file.FullName.Substring([IO.Path]::GetFullPath($PayloadFolder).TrimEnd('\').Length+1)
  if((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash-ne (Get-FileHash -LiteralPath (Join-Path $staging $relative) -Algorithm SHA256).Hash){throw ('Payload copy verification failed: '+$relative)}
 }
 $manifest=@{Product='AccommodationTestManagerBeta2';SetupVersion='1.0.0-beta.2.3-setup.1';Files=$files}
 $manifest|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $staging 'setup-installed-files.json') -Encoding UTF8
 # Ensure copied files inherit the protected, administrator-owned staging ACL.
 & icacls.exe $staging /reset /T /C|Out-Null;if($LASTEXITCODE-ne 0){throw 'File permission reset failed.'}
 Protect-Folder $staging
 Protect-Folder $stateParent;Protect-Folder $state
 Check-UnresolvedState
 if($hadPrevious){Move-Item -LiteralPath $install -Destination $backup}
 try{Move-Item -LiteralPath $staging -Destination $install;$swapped=$true}
 catch{if($hadPrevious -and (Test-Path -LiteralPath $backup) -and -not(Test-Path -LiteralPath $install)){Move-Item -LiteralPath $backup -Destination $install};throw}
 if(Test-Path -LiteralPath $backup){try{Remove-Item -LiteralPath $backup -Recurse -Force}catch{Write-Warning ('Previous install backup retained: '+$backup)}}
 Write-Output 'App, bundled runtime, helper and protected helper-state folders installed. Existing local settings/sessions/snapshots preserved.'
 Write-Output 'No test restrictions applied. Run the app normally under the standard testing account.'
} finally {
 if(-not $swapped -and (Test-Path -LiteralPath $staging)){Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue}
}
