# Read-only/mocked setup guard tests. Does not execute either script entrypoint,
# apply ACLs, invoke Windows cmdlets, install, uninstall or change machine settings.
$ErrorActionPreference='Stop'
$source=Join-Path $PSScriptRoot 'Install-OneClick.ps1'
$tokens=$null;$errors=$null;$ast=[System.Management.Automation.Language.Parser]::ParseFile($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw $errors[0]}
$wanted=@('Assert-NoReparse','Check-UnresolvedState')
$definitions=$ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -in $wanted},$true)
foreach($d in $definitions){. ([scriptblock]::Create($d.Extent.Text))}
$checks=0
function Check($condition,[string]$label){if(-not $condition){throw ('FAILED: '+$label)};$script:checks++;Write-Output ('PASS: '+$label)}
function Expect-Failure([scriptblock]$action,[string]$label){$failed=$false;try{& $action}catch{$failed=$true};Check $failed $label}
$root=Join-Path ([IO.Path]::GetTempPath()) ('ATM-Setup-Guards-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
$script:state=Join-Path $root 'RestrictionState'
try {
 Check-UnresolvedState;Check $true 'missing state folder allowed for first install'
 New-Item -ItemType Directory -Path $state|Out-Null
 Check-UnresolvedState;Check $true 'empty state folder allowed'
 $file=Join-Path $state 'synthetic.json'
 '{"Status":"Restored"}'|Set-Content -LiteralPath $file
 $before=[IO.File]::ReadAllBytes($file)
 Check-UnresolvedState;Check $true 'Restored snapshot permits setup'
 Check ([Convert]::ToBase64String($before)-eq [Convert]::ToBase64String([IO.File]::ReadAllBytes($file))) 'guard preserves snapshot bytes'
 foreach($status in @('Applying','Applied','ExportAccess','RestoreFailed')){
  ('{"Status":"'+$status+'"}')|Set-Content -LiteralPath $file
  Expect-Failure {Check-UnresolvedState} ('unresolved '+$status+' blocks setup')
 }
 '{ broken JSON'|Set-Content -LiteralPath $file
 Expect-Failure {Check-UnresolvedState} 'damaged state blocks setup'
 '{}'|Set-Content -LiteralPath $file
 Expect-Failure {Check-UnresolvedState} 'missing status blocks setup'
 '{"Status":"Restored"}'|Set-Content -LiteralPath $file
 '{"Status":"Applied"}'|Set-Content -LiteralPath ($file+'.bak')
 Check-UnresolvedState;Check $true 'backup files are not mistaken for canonical snapshots'
 Check (Test-Path -LiteralPath ($file+'.bak')) 'snapshot backup not deleted'
 $link=Join-Path $root 'LinkedState';New-Item -ItemType SymbolicLink -Path $link -Target $state|Out-Null
 $script:state=$link
 Expect-Failure {Check-UnresolvedState} 'reparse/symlink state directory rejected'
 Write-Output ('ALL '+$checks+' SETUP GUARD CHECKS PASSED - filesystem checks only; no native Windows installation validation.')
} finally {Remove-Item -LiteralPath $root -Recurse -Force}
