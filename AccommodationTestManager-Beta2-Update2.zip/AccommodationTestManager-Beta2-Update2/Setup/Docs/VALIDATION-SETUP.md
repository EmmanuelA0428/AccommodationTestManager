# Combined setup validation

- NSIS compiler built from the official NSIS 3.11 source distribution; official Windows stubs/plugins used. LZMA solid compressed setup compiled successfully.
- Self-contained win-x64 app published with .NET SDK 10.0.401 and the existing Beta 2 Hotfix 1 source. Core/Windows desktop runtime bundled; no separate machine-wide .NET installation needed.
- Public payload audited: default staff list/name/PIN hash/salt empty; no runtime sessions, browser profiles, saved laptop configuration or user credentials included. Helper matches Hotfix 1 source.
- Installer and uninstaller PowerShell operations parsed. 13 read-only filesystem guard checks passed: missing/empty/Restored state allowed; Applying/Applied/ExportAccess/RestoreFailed/malformed/missing-status state blocked; snapshot bytes/backups preserved; symlink state rejected.
- PE manifest checked: GUI bootstrap with requireAdministrator; code-signing certificate absent. No auto-launch of elevated WPF app configured.
- Core hotfix's prior 64 coordinator and 23 mocked network tests remain applicable, not substitutes for installer acceptance testing.

NOT TESTED HERE: actual Windows setup wizard/UAC, ACL propagation, administrator credential switch, file-swap rollback, desktop shortcuts, Apps & Features uninstall registration/removal, .NET self-contained startup, Word COM or real network/USB/Edge policy effectiveness. Dedicated synthetic laptop testing and IT review required. Setup is unsigned, not Store-distributed or a production-secure kiosk.
