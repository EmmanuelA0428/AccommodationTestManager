# Beta 2 Update 2 validation scope

Local cross-compilation: .NET 10 WPF build succeeds with zero warnings/errors.
Local tests: 89 checks passed on Linux using mock Word/manual timer/restriction helper; the additional Windows sharing-conflict demonstration is reserved for Windows CI. 23 mocked network-helper checks and 13 installer guard checks passed. PowerShell files parsed.

GitHub Windows validation must pass before the setup asset is published:
- Native Windows execution of coordinator/filesystem/update-policy regressions (including Word-style retained writable handle simulation).
- Mocked network helper and read-only setup guard tests.
- Compile self-contained win-x64 app and NSIS one-click setup.
- Silent install, verify app/runtime/restriction helper/PIN helper/manifest/desktop shortcut.
- Identification-only PIN helper handshake accepts administrator token + challenge and rejects mismatch; no PIN/settings changed by this check.
- Silent uninstall, confirming app removal. Saved configuration/session/snapshot data is not removed.

These checks do NOT run Microsoft Word COM, launch/inspect WPF pixels, approve real UAC, or exercise actual school network/USB/Edge policies. Follow TEST-CHECKLIST.md on a Windows 11 dummy-exam laptop, especially the actual standard account + separate-admin forgotten-PIN workflow. No real student testing in this beta.
