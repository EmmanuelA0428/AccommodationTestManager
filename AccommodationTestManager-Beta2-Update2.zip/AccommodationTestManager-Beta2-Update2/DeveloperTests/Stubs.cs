namespace System.Windows.Threading
{
 // Manual timer stub: not a WPF runtime test. No timer ticks are generated automatically.
 public class DispatcherTimer
 {
  public TimeSpan Interval {get;set;}
  public event EventHandler? Tick;
  public void Start() { }
  public void Stop() { }
  public void Trigger() => Tick?.Invoke(this,EventArgs.Empty);
 }
}
namespace AccommodationTestManager.Services
{
 // Word is substituted ONLY in this test harness. Real beta uses the uploaded COM service.
 public sealed class WordAutomationService : IDisposable
 {
  public static bool FailSave,FailClose,SaveNewEditDuringClose;
  private string? _path;
  public Task<AccommodationTestManager.Models.WordDocumentStatus> OpenAsync(string file)
  {if(!File.Exists(file))throw new IOException("Missing working copy.");_path=file;return GetStatusAsync();}
  public Task<AccommodationTestManager.Models.WordDocumentStatus> GetStatusAsync()
  {if(_path is null)throw new InvalidOperationException("Not connected.");return Task.FromResult(new AccommodationTestManager.Models.WordDocumentStatus(_path,false,false));}
  public async Task<AccommodationTestManager.Models.WordDocumentStatus> SaveAsync()
  {await Task.Delay(5);if(FailSave)throw new IOException("Simulated Word save failure.");return await GetStatusAsync();}
  public async Task<AccommodationTestManager.Models.RecoverySnapshot> CaptureSnapshotAsync(Func<AccommodationTestManager.Models.WordDocumentStatus,AccommodationTestManager.Models.RecoverySnapshot> capture)
  { var saved=await SaveAsync();return capture(saved); }
  public Task CloseAsync()
  {if(FailClose)throw new InvalidOperationException("Simulated new unsaved edit; refuse close.");if(SaveNewEditDuringClose&&_path is not null){File.AppendAllText(_path," NEW SAVED EDIT DURING FINISH");SaveNewEditDuringClose=false;}_path=null;return Task.CompletedTask;}
  public void Dispose(){_path=null;}
 }
}

namespace AccommodationTestManager.Services
{
 // TEST DOUBLE ONLY. Never runs registry/UAC/network operations.
 public sealed class RestrictionService
 {
  public bool IsInstalled {get;set;}=true;
  public bool FailRestore {get;set;}
  public Dictionary<string,string> States {get;}=[];
  public List<string> PendingIds()=>States.Where(x=>x.Value!="Restored").Select(x=>x.Key).ToList();
  public string Status(string id)=>States.GetValueOrDefault(id,"Missing");
  public Task ApplyAsync(AccommodationTestManager.Models.TestSession session){States[session.Id]="Applied";return Task.CompletedTask;}
  public Task ExportAccessAsync(string id){States[id]="ExportAccess";return Task.CompletedTask;}
  public Task RestoreAsync(string id){if(FailRestore)throw new IOException("Simulated machine restore failure");States[id]="Restored";return Task.CompletedTask;}
 }
}
