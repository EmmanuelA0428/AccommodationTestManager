# Native Windows test of identification-only administrator proof. No PIN/settings writes.
param([Parameter(Mandatory=$true)][string]$Helper)
$ErrorActionPreference='Stop'
$helperFull=(Resolve-Path $Helper).Path
if(-not (New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Ephemeral CI runner must be elevated.'}
foreach($test in @('Accepted','WrongChallenge')) {
 $name='ATM-PinReset-'+[guid]::NewGuid().ToString('N');$challenge=(-join ((1..32)|ForEach-Object{'AB'}))
 $server=New-Object IO.Pipes.NamedPipeServerStream($name,[IO.Pipes.PipeDirection]::InOut,1,[IO.Pipes.PipeTransmissionMode]::Byte,[IO.Pipes.PipeOptions]::Asynchronous)
 try {
  $wait=$server.WaitForConnectionAsync()
  $info=New-Object Diagnostics.ProcessStartInfo
  $info.FileName=Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
  $info.UseShellExecute=$false;$info.CreateNoWindow=$true
  $info.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$helperFull+'" -PipeName '+$name+' -Challenge '+$challenge
  $process=[Diagnostics.Process]::Start($info)
  if(-not $wait.Wait(15000)){throw 'Pipe helper failed to connect.'}
  $reader=New-Object IO.StreamReader($server,[Text.Encoding]::UTF8,$false,1024,$true)
  $writer=New-Object IO.StreamWriter($server,(New-Object Text.UTF8Encoding($false)),1024,$true);$writer.AutoFlush=$true
  $reply=$reader.ReadLine()
  $script:proof=$false
  $server.RunAsClient([IO.Pipes.PipeStreamImpersonationWorker]{
    $identity=[Security.Principal.WindowsIdentity]::GetCurrent([Security.Principal.TokenAccessLevels]::Query)
    try { $script:proof=(New-Object Security.Principal.WindowsPrincipal($identity)).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) } finally { $identity.Dispose() }
  })
  if($test-eq 'Accepted') {if($reply-ne $challenge-or -not $script:proof){throw 'Identification-only administrator proof failed.'};$writer.WriteLine('verified')}
  else {if($reply-eq ('0'*64)){throw 'Wrong challenge was incorrectly accepted.'};$writer.WriteLine('rejected')}
  if(-not $process.WaitForExit(15000)){throw 'Helper did not terminate.'}
  if($test-eq 'Accepted'-and $process.ExitCode-ne 0){throw 'Authorized helper failed.'}
  if($test-eq 'WrongChallenge'-and $process.ExitCode-eq 0){throw 'Rejected helper claimed success.'}
  Write-Output "PASS: native PIN authorization protocol $test (no PIN changed)"
  $reader.Dispose();$writer.Dispose();$process.Dispose()
 } finally { $server.Dispose() }
}
