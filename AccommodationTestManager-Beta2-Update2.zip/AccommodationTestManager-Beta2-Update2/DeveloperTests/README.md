# Synthetic developer regression tests

Run `dotnet run --project DeveloperTests/BetaTests.csproj` from the solution root with .NET 10 SDK. No Windows changes are performed. Real linked models/settings/allowlist/filesystem/recovery/coordinator code runs with mock Word, manual DispatcherTimer and mock RestrictionService. Synthetic .docx fixtures are plain text, NOT valid Word documents. This is not Word COM, WPF, registry/UAC/USB/network, or browser policy acceptance testing. See root TEST-CHECKLIST for native Windows tests.

Network helper regression suite: `pwsh -NoProfile -File DeveloperTests/NetworkHelper.Tests.ps1`. It AST-extracts only network functions and substitutes all network cmdlets/snapshot writes. Does not invoke the installed helper entrypoint or any registry operations.
