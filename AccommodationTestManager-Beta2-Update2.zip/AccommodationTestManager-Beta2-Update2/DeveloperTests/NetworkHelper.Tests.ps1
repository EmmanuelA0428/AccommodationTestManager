# Pure regression test: extracts ONLY network function definitions from helper AST.
# NO helper entrypoint, admin, registry, installer or actual network cmdlets run.
$ErrorActionPreference='Stop'
$helper=Join-Path (Split-Path -Parent $PSScriptRoot) 'AccommodationTestManager/Scripts/Beta2Restrictions.ps1'
$tokens=$null;$errors=$null;$ast=[System.Management.Automation.Language.Parser]::ParseFile($helper,[ref]$tokens,[ref]$errors)
if($errors.Count){throw $errors[0]}
$wanted=@('Is-WindowsInfrastructureAdapter','Find-Adapter','Active-Adapters','Record-NetworkNote','Restore-Network','Disable-RecordedAdapters')
$definitions=$ast.FindAll({param($node) $node -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $node.Name -in $wanted},$true)
if($definitions.Count-ne $wanted.Count){throw 'Missing network functions.'}
foreach($definition in $definitions){. ([scriptblock]::Create($definition.Extent.Text))}
# All operating-system cmdlets and snapshot writes below are TEST DOUBLES.
function Get-NetAdapter {param([switch]$IncludeHidden) $script:Inventory}
function Start-Sleep {param([int]$Milliseconds) }
function Enable-NetAdapter {
 param($InputObject,[switch]$Confirm,[string]$ErrorAction)
 if($null-eq $InputObject){throw 'NULL ENABLE INPUT'}
 $script:Calls+=('Enable:'+ $InputObject.Name)
 if($InputObject.Name-eq $script:FailEnableName){throw 'Simulated enable failure'}
 $InputObject.Status='Disconnected'
 if($InputObject.Name-eq 'Wi-Fi' -and $script:DropDirectOnEnable){$script:Inventory=@($script:Inventory|Where-Object{$_.InterfaceDescription-notlike 'Microsoft Wi-Fi Direct*'})}
}
function Write-Atomic {param([string]$Path,$Value) $script:Written=$Value|ConvertTo-Json -Depth 15|ConvertFrom-Json}
function Disable-NetAdapter {
 param($InputObject,[switch]$Confirm,[string]$ErrorAction)
 if($null-eq $InputObject){throw 'NULL DISABLE INPUT'}
 $record=$script:Written.Adapters|Where-Object{$_.Guid-eq $InputObject.InterfaceGuid}|Select-Object -First 1
 if(-not $record.ChangedByHelper){throw 'Change intent not recorded before disable'}
 $script:Calls+=('Disable:'+ $InputObject.Name);$InputObject.Status='Disabled'
 if($InputObject.Name-eq 'Wi-Fi'){$script:Inventory=@($script:Inventory|Where-Object{$_.InterfaceDescription-notlike 'Microsoft Wi-Fi Direct*'})}
}
$script:Checks=0
function Check($condition,[string]$label){if(-not $condition){throw ('FAILED: '+$label)};$script:Checks++;Write-Output ('PASS: '+$label)}
function Expect-Failure([scriptblock]$Action,[string]$label){$failed=$false;try{& $Action}catch{$failed=$true};Check $failed $label}
function Adapter([string]$name,[string]$description,[string]$status,[bool]$physical=$false){[pscustomobject]@{Name=$name;InterfaceDescription=$description;Status=$status;InterfaceGuid=('{'+[guid]::NewGuid().ToString().ToUpperInvariant()+'}');HardwareInterface=$physical}}
function Fixture {
 $script:Calls=@();$script:FailEnableName='';$script:DropDirectOnEnable=$false;$script:Written=$null
 $script:Inventory=@(
  (Adapter 'Local Area Connection* 3' 'WAN Miniport (SSTP)' 'Disconnected'),
  (Adapter 'Wi-Fi' 'MediaTek Wi-Fi 6E MT7922 160MHz Wireless LAN Card' 'Up' $true),
  (Adapter 'Ethernet 4' 'Realtek USB GbE Family Controller #2' 'Disconnected' $true),
  (Adapter 'Local Area Connection* 2' 'Microsoft Wi-Fi Direct Virtual Adapter #2' 'Disconnected'),
  (Adapter 'Bluetooth Network Connection' 'Bluetooth Device (Personal Area Network)' 'Disconnected'),
  (Adapter 'Ethernet (Kernel Debugger)' 'Microsoft Kernel Debug Network Adapter' 'Not Present'),
  (Adapter 'Teredo Tunneling Pseudo-Interface' '' 'Not Present'),
  (Adapter 'Local Area Connection* 7' 'WAN Miniport (PPPOE)' 'Disconnected'),
  (Adapter 'Local Area Connection* 4' 'WAN Miniport (IKEv2)' 'Disconnected'),
  (Adapter 'Ethernet' 'Realtek PCIe GbE Family Controller' 'Disconnected' $true),
  (Adapter 'Local Area Connection* 1' 'Microsoft Wi-Fi Direct Virtual Adapter' 'Disconnected'),
  (Adapter 'Local Area Connection* 8' 'WAN Miniport (IP)' 'Up'),
  (Adapter 'Local Area Connection* 6' 'WAN Miniport (PPTP)' 'Disconnected'),
  (Adapter 'Microsoft IP-HTTPS Platform Interface' '' 'Not Present'),
  (Adapter 'Local Area Connection* 5' 'WAN Miniport (L2TP)' 'Disconnected'),
  (Adapter 'Local Area Connection* 9' 'WAN Miniport (IPv6)' 'Up'),
  (Adapter '6to4 Adapter' '' 'Not Present'),
  (Adapter 'Local Area Connection* 10' 'WAN Miniport (Network Monitor)' 'Up'),
  (Adapter 'Ethernet 3' 'Realtek USB 2.5GbE Family Controller' 'Disconnected' $true)
 )
}
function Legacy-State { [pscustomobject]@{Adapters=@($script:Inventory|ForEach-Object{[pscustomobject]@{Name=$_.Name;Guid=$_.InterfaceGuid}})} }
Fixture
$selected=@(Active-Adapters)
Check ($script:Inventory.Count-eq 19 -and $selected.Count-eq 5) '19-interface supplied inventory selects five connection adapters'
Check ('Ethernet 4'-in $selected.Name -and 'Ethernet 3'-in $selected.Name -and 'Ethernet'-in $selected.Name) 'disconnected dock/USB/Ethernet interfaces remain included'
Check ('Wi-Fi'-in $selected.Name -and 'Bluetooth Network Connection'-in $selected.Name) 'Wi-Fi and Bluetooth PAN remain included'
Check (-not @($selected|Where-Object{$_.Status-eq 'Not Present'}).Count) 'Not Present interfaces excluded from Apply'
Check (-not @($selected|Where-Object{$_.InterfaceDescription-like 'WAN Miniport*' -or $_.InterfaceDescription-like 'Microsoft Wi-Fi Direct*'}).Count) 'WAN miniports and Wi-Fi Direct excluded from direct changes'
$disabled=Adapter 'Disabled NIC' 'Intel network device' 'Disabled' $true;$script:Inventory+=$disabled
Check ('Disabled NIC'-notin @(Active-Adapters).Name) 'already-disabled adapter excluded'
$vpn=Adapter 'Vendor VPN' 'Vendor tunnel adapter' 'Up';$script:Inventory+=$vpn
Check ('Vendor VPN'-in @(Active-Adapters).Name) 'unknown vendor/virtual adapters not silently exempted'
Check ((Find-Adapter $vpn.InterfaceGuid.Trim([char[]]'{}').ToLowerInvariant()).Name-eq 'Vendor VPN') 'GUID lookup normalizes braces and case'
Fixture
$state=Legacy-State;Restore-Network $state
Check ($script:Calls.Count-eq 0) 'legacy healthy inventory restores without unnecessary enable calls'
Check (@($state.NetworkRestoreNotes).Count-eq 4) 'legacy not-present infrastructure documented instead of blocking physical restore'
Fixture
$state=Legacy-State;($script:Inventory|Where-Object Name -eq 'Wi-Fi').Status='Disabled';($script:Inventory|Where-Object Name -eq 'Local Area Connection* 3').Status='Disabled'
Restore-Network $state
Check ($script:Calls[0]-eq 'Enable:Wi-Fi' -and 'Enable:Local Area Connection* 3'-in $script:Calls) 'restore physical first then previously disabled legacy miniport'
Fixture
$state=Legacy-State;($script:Inventory|Where-Object Name -eq 'Wi-Fi').Status='Disabled';$script:DropDirectOnEnable=$true
Restore-Network $state
Check (@($state.NetworkRestoreNotes|Where-Object{$_-like '*Local Area Connection*'}).Count-eq 2) 'known child adapters disappearing during parent restore get notes'
Fixture
$state=Legacy-State;$script:Inventory=@($script:Inventory|Where-Object Name -ne 'Ethernet 4');($script:Inventory|Where-Object Name -eq 'Wi-Fi').Status='Disabled'
Expect-Failure {Restore-Network $state} 'missing physical adapter remains fail-closed'
Check ('Enable:Wi-Fi'-in $script:Calls) 'other physical adapters restored despite one missing connection'
Fixture
$state=Legacy-State;($script:Inventory|Where-Object Name -eq 'Wi-Fi').InterfaceGuid='{00000000-0000-0000-0000-000000000000}'
Expect-Failure {Restore-Network $state} 'same name with different GUID never treated as original adapter'
Fixture
$nic=$script:Inventory|Where-Object Name -eq 'Wi-Fi';$nic.Status='Disabled'
$state=@{Adapters=@(@{Name=$nic.Name;Guid=$nic.InterfaceGuid;OriginalStatus='Disabled';ChangedByHelper=$true;HardwareInterface=$true})}
Restore-Network $state;Check ($nic.Status-eq 'Disabled' -and $script:Calls.Count-eq 0) 'snapshot initially disabled adapter never force-enabled'
$state.Adapters[0].OriginalStatus='Up';$state.Adapters[0].ChangedByHelper=$false
Restore-Network $state;Check ($nic.Status-eq 'Disabled' -and $script:Calls.Count-eq 0) 'unchanged adapter not enabled by recovery'
Fixture
$state=Legacy-State;($script:Inventory|Where-Object Name -eq 'Local Area Connection* 3').Status='Disabled';$script:FailEnableName='Local Area Connection* 3'
Expect-Failure {Restore-Network $state} 'failed restoration of a present disabled legacy miniport still reported'
Fixture
$vpn=Adapter 'Vendor VPN' 'Vendor tunnel adapter' 'Up';$script:Inventory+=$vpn;$state=Legacy-State;$script:Inventory=@($script:Inventory|Where-Object Name -ne 'Vendor VPN')
Expect-Failure {Restore-Network $state} 'missing unknown virtual adapter not dismissed as Windows infrastructure'
Fixture
$state=@{Adapters=@(Active-Adapters|Sort-Object HardwareInterface|ForEach-Object{@{Guid=$_.InterfaceGuid;Name=$_.Name;OriginalStatus=$_.Status;InterfaceDescription=$_.InterfaceDescription;HardwareInterface=$_.HardwareInterface;ChangedByHelper=$false}})}
Disable-RecordedAdapters $state 'MOCK-SNAPSHOT'
Check (@(Active-Adapters).Count-eq 0 -and $script:Calls.Count-eq 5) 'new Apply survives Wi-Fi Direct disappearance and disables selected connections'
Check (@($state.Adapters|Where-Object{-not $_.ChangedByHelper}).Count-eq 0) 'disable intent journaled before every adapter change'
Fixture
$missing=@{Name='Missing NIC';Guid='{00000000-0000-0000-0000-000000000001}';ChangedByHelper=$false;OriginalStatus='Up'}
Expect-Failure {Disable-RecordedAdapters @{Adapters=@($missing)} 'MOCK-SNAPSHOT'} 'vanished adapter rejected before any null InputObject call'
Check ($script:Calls.Count-eq 0 -and -not $missing.ChangedByHelper) 'vanished-adapter guard changes no adapter'
Write-Output ('ALL '+$script:Checks+' NETWORK CHECKS PASSED - mocked adapter cmdlets/snapshot writes, not Windows device validation.')
