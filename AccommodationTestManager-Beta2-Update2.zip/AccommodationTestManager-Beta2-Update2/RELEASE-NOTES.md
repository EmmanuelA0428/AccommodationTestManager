## Beta 2 Update 2 — navigation and layout fixes

[Download Update 2 setup](https://github.com/EmmanuelA0428/AccommodationTestManager/releases/download/v1.0.0-beta.2.3/AccommodationTestManager-Setup-Beta2-Update2.exe)

- Continue works for reviewing a populated draft even when older recovery is outstanding. Start remains blocked with a visible explanation and recovery actions. Readiness is refreshed after recovery/settings/session changes; no session is deleted or bypassed.
- Full-width, 44-DIP staff dropdown and matching chrome; immediate selection binding.
- Settings/theme icons aligned with toolbar buttons.
- Clear primary Continue appearance, including Windows high-contrast colors. Setup footer hidden during the current-session screen.
- Native WPF synthetic UI checks cover size/alignment, actual navigation, recovery gating, and Check for updates. Existing save/recovery, PIN helper, installer and network/coordinator checks retained.
- Update 1's actual updater is tested after publication for real release detection, checksum/digest download, Internet marking and rejection of tampered bytes without launching an installer.

## Test the updater
In installed Update 1: Settings → Updates → Check for updates should offer **v1.0.0-beta.2.3**. Download/install only between tests, with no unfinished session or unresolved machine controls. Windows admin approval and security policies still apply. Saved settings/sessions are preserved. If old recovery is unresolved, do not delete it to update: use the documented staff-controlled manual update/recovery route.

Installer remains unsigned; synthetic tests only, not production exam-ready. No app lockdown, protected student-data broker, secure individual staff identity or comprehensive in-site AI prevention. Native UI tests are not real Word/UAC/device acceptance testing. Source package includes complete solution, installer sources and checklists; automatic GitHub Source code ZIP is not the full app.
