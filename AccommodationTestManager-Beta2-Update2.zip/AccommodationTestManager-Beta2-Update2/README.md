# Accommodation Test Manager — Beta 2 Update 2

Windows 11 x64. Dedicated synthetic tests only; not a secure production exam kiosk.

## Update 2 UI fixes
- Draft Continue is no longer silently blocked by a cached recovery flag. A persistent banner explains unresolved sessions, unreadable storage, or pending machine restoration. Draft review may proceed; Start never bypasses recovery. Recheck status and staff recovery actions are visible.
- Readiness is recomputed after settings, records, and session operations and immediately before Start. The setup footer is hidden when a current session is shown.
- Staff dropdown and its inner chrome stretch to match text inputs at a 44-DIP height. Staff selection updates the draft immediately.
- Settings/theme icon margins match the text buttons. Continue has an explicit high-contrast primary action appearance (respecting Windows high-contrast colors).
- Native WPF synthetic tests validate control size/alignment, actual Continue navigation, blocking/resolution banners, and the Check for updates button. Released Update 1's update service is also tested against this release after publication: detection, verified download, Internet marking and corruption rejection, without launching an installer.

## Previously included changes
- Word recovery uses compatible read/write/delete sharing, before/copy/after SHA-256 checks, file metadata checks, DOCX package validation and post-capture Word state checks. Save/capture is coordinated on Word's STA gate; background saves are not accepted as complete. A changed/unavailable document fails closed; the working file is not overwritten.
- One-row student toolbar: Voice Access | Read, Pause, Stop | Help, Finish. Optional timer only for timed sessions. Content-sized height avoids clipping.
- Light/dark toggle by Settings; explicit dark-compatible input/button/dropdown/tab templates.
- Four setup steps: Student, Test, Supports, Review. Review includes the security summary; preflight remains mandatory for required controls.
- Asset tag auto-filled from Windows laptop name without trailing W; editable. No default staff list. Registration's one-name-per-line editor can add/remove staff before saving.
- Forgotten PIN: fresh Windows administrator approval verifies an identification-only named-pipe client token and one-time challenge; then staff sets a new PIN. The helper never receives the PIN. Attribution is recorded locally. This does not make the shared-account data or staff identity secure.
- Settings > Updates manually checks newer Beta 2 releases in the fixed public repository. Download size/checksum and GitHub digest (when present) are checked, Internet-origin marking retained, bytes rechecked/locked before launch. No account sign-in or student data is sent. Current/unfinished sessions, busy operations and pending machine restoration block the in-app install action. No silent auto-update.
- Restriction helper requests a hidden PowerShell window; Windows UAC must remain visible. Windows policies may still block an unsigned beta.

## Install/update
Use the GitHub release's one-click EXE. It installs app/helper/private .NET runtime together and preserves saved settings, sessions, laptop identity, and protected restriction snapshots. No separate PowerShell install. Close the app and restore unresolved machine controls before running setup. Open the desktop shortcut normally under the standard testing account.

If an older beta's broken Finish leaves a test unresolved: keep it with staff, Ctrl+S in Word and preserve a separate backup if possible. Use Settings > Recovery > Emergency restore to restore recorded machine controls. Close Word normally after saving, then close the app while preserving the unfinished session. The manual setup can update the program without deleting that session. Reopen, adopt/reconnect the session through staff recovery, verify its working document, and repeat preflight before any handoff. Never delete/reset a test just to get an installer to run.

Update 1 users can use Settings > Updates for Update 2 after resolving all sessions/controls. Earlier versions need the direct setup EXE. Future compatible Beta 2 updates can be checked/downloaded from Settings. Unsigned installers can still produce Unknown Publisher/SmartScreen warnings. Do not disable Windows protections.

## Development
Open AccommodationTestManager.sln in Visual Studio with .NET 10 WPF tools. Runtime storage stays outside the source tree; replacing source ZIPs is not a data reset. Installer builds are automated by GitHub's workflow. DeveloperTests substitutes Word/timer/restriction coordinator; native Word/Windows UI/UAC still need dummy-exam acceptance testing.

## Remaining limitations
No OS application lockdown, protected student-data broker, secure individual staff identity, comprehensive in-site AI blocking, cloud configuration sync or portal. No real student/test data belongs in GitHub. Do not use this beta for real examinations without the required security work and institutional review.
