# Uses an isolated current-user registry branch, never the real Edge policies.
$ErrorActionPreference='Stop'
. (Join-Path $PSScriptRoot 'Edge-BackgroundPolicy.ps1')
$path='HKCU:\Software\ATM-EdgeBaseline-Test-'+[guid]::NewGuid().ToString('N')
$state=Join-Path ([IO.Path]::GetTempPath()) ('ATM-EdgeBaseline-'+[guid]::NewGuid().ToString('N')+'.json')
function Check($condition,$message){if(-not $condition){throw "FAIL: $message"};Write-Output "PASS: $message"}
try{
 Set-EdgeBaselineDword $path 'Unrelated' 42
 Set-EdgeBaselineDword $path 'StartupBoostEnabled' 1
 Install-EdgeBaseline $path $state
 Check ((Read-EdgeBaselineValue $path 'StartupBoostEnabled').Value-eq 0) 'startup boost disabled'
 Check ((Read-EdgeBaselineValue $path 'BackgroundModeEnabled').Value-eq 0) 'background mode disabled'
 Check ((Read-EdgeBaselineValue $path 'Unrelated').Value-eq 42) 'unrelated policy preserved'
 $before=Get-Content $state -Raw|ConvertFrom-Json
 Install-EdgeBaseline $path $state
 $after=Get-Content $state -Raw|ConvertFrom-Json
 Check (($before.Values|ConvertTo-Json -Compress)-eq ($after.Values|ConvertTo-Json -Compress)) 'upgrade retains original baseline'
 Set-EdgeBaselineDword $path 'BackgroundModeEnabled' 1
 $failed=$false;try{Install-EdgeBaseline $path $state}catch{$failed=$true};Check $failed 'upgrade refuses external changes'
 $failed=$false;try{Restore-EdgeBaseline $path $state}catch{$failed=$true};Check $failed 'uninstall refuses external changes'
 Check ((Read-EdgeBaselineValue $path 'StartupBoostEnabled').Value-eq 0) 'conflict prevents partial restoration'
 Set-EdgeBaselineDword $path 'BackgroundModeEnabled' 0
 Restore-EdgeBaseline $path $state
 Check ((Read-EdgeBaselineValue $path 'StartupBoostEnabled').Value-eq 1) 'original startup policy restored'
 Check (-not (Read-EdgeBaselineValue $path 'BackgroundModeEnabled').Present) 'originally absent policy removed'
 Check ((Read-EdgeBaselineValue $path 'Unrelated').Value-eq 42) 'unrelated policy still preserved'
 Check (-not(Test-Path $state)) 'receipt removed after successful restore'
 # Simulate an interruption after the first write: recovery accepts original and desired values.
 $snapshot=@{Version=1;Status='Applying';Values=@((Read-EdgeBaselineValue $path 'StartupBoostEnabled'),(Read-EdgeBaselineValue $path 'BackgroundModeEnabled'))}
 Write-EdgeBaseline $state $snapshot;Set-EdgeBaselineDword $path 'StartupBoostEnabled' 0
 Restore-EdgeBaseline $path $state
 Check ((Read-EdgeBaselineValue $path 'StartupBoostEnabled').Value-eq 1) 'interrupted install can roll back'
 Check (-not (Read-EdgeBaselineValue $path 'BackgroundModeEnabled').Present) 'interrupted install preserves absent value'
 Write-Output 'Edge baseline tests passed in isolated HKCU branch.'
}finally{if(Test-Path $path){Remove-Item $path -Recurse -Force};if(Test-Path $state){Remove-Item $state -Force}}
