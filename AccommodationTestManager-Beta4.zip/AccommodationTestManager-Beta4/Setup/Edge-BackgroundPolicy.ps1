# Setup-only baseline for testing laptops. Only these two Edge values are touched.
# StatePath must be in the already protected ProgramData directory.
function Read-EdgeBaselineValue([string]$Path,[string]$Name){
 $key=Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
 if($null-eq $key -or $key.GetValueNames() -notcontains $Name){return @{Name=$Name;Present=$false;Value=$null}}
 if($key.GetValueKind($Name) -ne [Microsoft.Win32.RegistryValueKind]::DWord){throw "Unexpected Edge policy type: $Name. Administrator review required."}
 return @{Name=$Name;Present=$true;Value=[int]$key.GetValue($Name)}
}
function Same-EdgeBaselineValue($a,$b){return $a.Present-eq $b.Present -and (-not $a.Present -or [int]$a.Value-eq [int]$b.Value)}
function Set-EdgeBaselineDword([string]$Path,[string]$Name,[int]$Value){
 # New-Item -Force on an existing registry key can delete unrelated values.
 $hive=if($Path.StartsWith('HKLM:\')){[Microsoft.Win32.RegistryHive]::LocalMachine}elseif($Path.StartsWith('HKCU:\')){[Microsoft.Win32.RegistryHive]::CurrentUser}else{throw 'Unsupported hive.'}
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey($hive,[Microsoft.Win32.RegistryView]::Registry64)
 try{$key=$base.CreateSubKey($Path.Substring(6),$true);try{$key.SetValue($Name,$Value,[Microsoft.Win32.RegistryValueKind]::DWord);$key.Flush()}finally{$key.Dispose()}}finally{$base.Dispose()}
}
function Write-EdgeBaseline([string]$StatePath,$State){
 $tmp=$StatePath+'.'+[guid]::NewGuid().ToString('N')+'.tmp';$bytes=[Text.Encoding]::UTF8.GetBytes(($State|ConvertTo-Json -Depth 8))
 $stream=[IO.File]::Open($tmp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$stream.Write($bytes,0,$bytes.Length);$stream.Flush($true)}finally{$stream.Dispose()}
 if(Test-Path -LiteralPath $StatePath){$backup=$StatePath+".bak";if(Test-Path -LiteralPath $backup){Remove-Item -LiteralPath $backup -Force};[IO.File]::Replace($tmp,$StatePath,$backup)}else{[IO.File]::Move($tmp,$StatePath)}
}
function Assert-EdgeBaselineState($state){
 if($state.Version-ne 1 -or $state.Status-notin @('Applying','Applied') -or @($state.Values).Count-ne 2){throw 'Invalid Edge setup baseline; administrator review required.'}
 $names=@($state.Values|ForEach-Object{$_.Name}|Sort-Object)
 if(($names -join ',') -ne 'BackgroundModeEnabled,StartupBoostEnabled'){throw 'Invalid Edge baseline values.'}
 foreach($v in $state.Values){if($v.Present -isnot [bool] -or ($v.Present -and $v.Value -isnot [int] -and $v.Value -isnot [long])){throw 'Invalid Edge baseline data.'}}
}
function Install-EdgeBaseline([string]$Path,[string]$StatePath){
 if(Test-Path -LiteralPath $StatePath){
  $state=Get-Content -LiteralPath $StatePath -Raw -Encoding UTF8|ConvertFrom-Json;Assert-EdgeBaselineState $state
  foreach($v in $state.Values){$now=Read-EdgeBaselineValue $Path $v.Name;$zero=@{Present=$true;Value=0};if(-not(Same-EdgeBaselineValue $now $zero) -and ($state.Status-eq 'Applied' -or -not(Same-EdgeBaselineValue $now $v))){throw ('Edge policy changed since setup: '+$v.Name+'. Preserved; administrator review required.')}}
 }else{
  $values=@(Read-EdgeBaselineValue $Path 'StartupBoostEnabled';Read-EdgeBaselineValue $Path 'BackgroundModeEnabled')
  $state=@{Version=1;Status='Applying';Values=$values};Write-EdgeBaseline $StatePath $state
 }
 foreach($v in $state.Values){Set-EdgeBaselineDword $Path $v.Name 0;$now=Read-EdgeBaselineValue $Path $v.Name;if(-not $now.Present -or $now.Value-ne 0){throw ('Edge baseline verification failed: '+$v.Name)}}
 $state.Status='Applied';Write-EdgeBaseline $StatePath $state
}
function Restore-EdgeBaseline([string]$Path,[string]$StatePath){
 if(-not(Test-Path -LiteralPath $StatePath)){return}
 $state=Get-Content -LiteralPath $StatePath -Raw -Encoding UTF8|ConvertFrom-Json;Assert-EdgeBaselineState $state
 # Preflight all values first; never overwrite a subsequent administrator change.
 foreach($v in $state.Values){$now=Read-EdgeBaselineValue $Path $v.Name;$zero=@{Present=$true;Value=0};if(-not(Same-EdgeBaselineValue $now $zero) -and -not(Same-EdgeBaselineValue $now $v)){throw ('Edge policy changed since setup: '+$v.Name+'. Preserved; administrator review required.')}}
 foreach($v in $state.Values){
  if($v.Present){Set-EdgeBaselineDword $Path $v.Name ([int]$v.Value)}elseif(Test-Path -LiteralPath $Path){Remove-ItemProperty -LiteralPath $Path -Name $v.Name -ErrorAction SilentlyContinue}
  if(-not(Same-EdgeBaselineValue (Read-EdgeBaselineValue $Path $v.Name) $v)){throw ('Edge baseline restoration failed: '+$v.Name)}
 }
 Remove-Item -LiteralPath $StatePath -Force
 if(Test-Path -LiteralPath ($StatePath+".bak")){Remove-Item -LiteralPath ($StatePath+".bak") -Force}
}
