!ifndef SOURCE_DIR
 !error "Supply SOURCE_DIR"
!endif
!ifndef PAYLOAD_DIR
 !error "Supply PAYLOAD_DIR"
!endif
!ifndef OUTPUT_FILE
 !error "Supply OUTPUT_FILE"
!endif
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "LogicLib.nsh"
Name "CTL TestDesk"
OutFile "${OUTPUT_FILE}"
InstallDir "$PROGRAMFILES64\AccommodationTestManagerBeta2"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
CRCCheck on
ManifestDPIAware true
VIProductVersion "1.0.0.12"
VIAddVersionKey "ProductName" "CTL TestDesk"
VIAddVersionKey "FileDescription" "CTL TestDesk Setup"
VIAddVersionKey "FileVersion" "1.0.0.12"
VIAddVersionKey "ProductVersion" "1.0.0-beta.4.3-setup.1"
VIAddVersionKey "LegalCopyright" "CTL TestDesk"
!define MUI_ICON "${SOURCE_DIR}/../AccommodationTestManager/Assets/CTL-TestDesk.ico"
!define MUI_UNICON "${SOURCE_DIR}/../AccommodationTestManager/Assets/CTL-TestDesk.ico"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Install CTL TestDesk"
!define MUI_WELCOMEPAGE_TEXT "Installs CTL TestDesk and its background service.$\r$\n$\r$\nClose CTL TestDesk before continuing. Administrator approval is required for installation.$\r$\n$\r$\nSaved tests and recovery data are kept. This unsigned release candidate requires your organization's approval before use."
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_TITLE "Setup finished"
!define MUI_FINISHPAGE_TEXT "Open CTL TestDesk normally from the desktop shortcut in the testing account.$\r$\n$\r$\nRoutine tests use the staff PIN. Do not run the whole app as administrator.$\r$\n$\r$\nValidate installation, export and restoration on a test laptop before wider use."
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_UNPAGE_FINISH
!insertmacro MUI_LANGUAGE "English"
Var Result
Var BrokerConfigure
Function .onInit
 ${IfNot} ${RunningX64}
  MessageBox MB_ICONSTOP|MB_OK "This beta requires Windows 11 x64." /SD IDOK
  Abort
 ${EndIf}
 SetRegView 64
 StrCpy $INSTDIR "$PROGRAMFILES64\AccommodationTestManagerBeta2"
 SetShellVarContext all
FunctionEnd
Section "Install"
 InitPluginsDir
 SetOutPath "$PLUGINSDIR\AppPayload"
 File /r "${PAYLOAD_DIR}/*"
 SetOutPath "$PLUGINSDIR\Docs"
 File /r "${SOURCE_DIR}/Docs/*"
 SetOutPath "$PLUGINSDIR"
 File "${SOURCE_DIR}/Install-OneClick.ps1"
 StrCpy $BrokerConfigure "-ConfigureBroker"
 IfSilent 0 +2
 StrCpy $BrokerConfigure ""
 DetailPrint "Installing app, bundled runtime and protected helper..."
 nsExec::ExecToLog '"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\Install-OneClick.ps1" -PayloadFolder "$PLUGINSDIR\AppPayload" -DocsFolder "$PLUGINSDIR\Docs" $BrokerConfigure'
 Pop $Result
 ${If} $Result != 0
  SetErrorLevel 1
  MessageBox MB_ICONSTOP|MB_OK "Setup did not complete. See the Details log. Close the app. Preserve unresolved controls and snapshots; legacy state requires review, not the old helper. Ask an administrator about script policy/permissions. Existing session files and snapshots were not deleted." /SD IDOK
  Abort
 ${EndIf}
 SetOutPath "$INSTDIR"
 WriteUninstaller "$INSTDIR\Uninstall.exe"
 Delete "$DESKTOP\Accommodation Test Manager Beta 4.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 4\Accommodation Test Manager.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 4\Installation guide.lnk"
 RMDir "$SMPROGRAMS\Accommodation Test Manager Beta 4"
 Delete "$DESKTOP\Accommodation Test Manager Beta 3.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 3\Accommodation Test Manager.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 3\Installation guide.lnk"
 RMDir "$SMPROGRAMS\Accommodation Test Manager Beta 3"
 Delete "$DESKTOP\Accommodation Test Manager Beta 2.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 2\Accommodation Test Manager.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 2\Installation guide.lnk"
 RMDir "$SMPROGRAMS\Accommodation Test Manager Beta 2"
 CreateShortcut "$DESKTOP\CTL TestDesk.lnk" "$INSTDIR\AccommodationTestManager.exe" "" "$INSTDIR\AccommodationTestManager.exe" 0
 CreateDirectory "$SMPROGRAMS\CTL TestDesk"
 CreateShortcut "$SMPROGRAMS\CTL TestDesk\Accommodation Test Manager.lnk" "$INSTDIR\AccommodationTestManager.exe" "" "$INSTDIR\AccommodationTestManager.exe" 0
 CreateShortcut "$SMPROGRAMS\CTL TestDesk\Installation guide.lnk" "$INSTDIR\Docs\START-HERE.txt"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "DisplayName" "CTL TestDesk"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "DisplayVersion" "1.0.0-beta.4.3-setup.1"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "InstallLocation" "$INSTDIR"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "DisplayIcon" "$INSTDIR\AccommodationTestManager.exe"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "URLInfoAbout" "https://github.com/EmmanuelA0428/AccommodationTestManager"
 WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "NoModify" 1
 WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "NoRepair" 1
SectionEnd
Function un.onInit
 SetRegView 64
 SetShellVarContext all
FunctionEnd
Section "Uninstall"
 nsExec::ExecToLog '"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\SetupSupport\Uninstall-OneClick.ps1" -InstallFolder "$INSTDIR"'
 Pop $Result
 ${If} $Result != 0
  SetErrorLevel 1
  MessageBox MB_ICONSTOP|MB_OK "Uninstall stopped. Close the app and restore pending machine controls first, or ask IT. Exam sessions/settings and recovery snapshots were not deleted." /SD IDOK
  Abort
 ${EndIf}
 Delete "$DESKTOP\CTL TestDesk.lnk"
 Delete "$SMPROGRAMS\CTL TestDesk\Accommodation Test Manager.lnk"
 Delete "$SMPROGRAMS\CTL TestDesk\Installation guide.lnk"
 RMDir "$SMPROGRAMS\CTL TestDesk"
 DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2"
 Delete "$INSTDIR\Uninstall.exe"
 RMDir "$INSTDIR"
SectionEnd
