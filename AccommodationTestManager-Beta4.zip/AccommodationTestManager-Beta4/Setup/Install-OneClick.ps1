# Embedded setup operation; invoked only by the elevated setup EXE.
# Installs files/ACLs and the documented persistent Edge background baseline. Never applies test restrictions.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$PayloadFolder,[Parameter(Mandatory=$true)][string]$DocsFolder,[switch]$ConfigureBroker)
$ErrorActionPreference='Stop'
# Use only built-in Windows PowerShell modules in this installer process.
# A parent PowerShell 7 process can otherwise pass conflicting module paths.
$env:PSModulePath=Join-Path $PSHOME 'Modules'
Import-Module (Join-Path $PSHOME 'Modules\Microsoft.PowerShell.Security\Microsoft.PowerShell.Security.psd1') -ErrorAction Stop
$identity=[Security.Principal.WindowsIdentity]::GetCurrent()
$principal=New-Object Security.Principal.WindowsPrincipal($identity)
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator approval required.'}
if(-not [Environment]::Is64BitProcess){throw 'Setup must invoke 64-bit Windows PowerShell.'}
$build=[int](Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion').CurrentBuildNumber
if($build-lt 22000){throw 'This beta requires Windows 11 x64.'}
$install=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2'
$stateParent='C:\ProgramData\AccommodationTestingBeta2'
$state=Join-Path $stateParent 'RestrictionState'
function Assert-NoReparse([string]$Path){
 $current=[IO.Path]::GetFullPath($Path)
 while($current){if(Test-Path -LiteralPath $current){if((Get-Item -LiteralPath $current -Force).Attributes-band [IO.FileAttributes]::ReparsePoint){throw ('Reparse-point path rejected: '+$current)}};$parent=[IO.Path]::GetDirectoryName($current);if($parent-eq $current){break};$current=$parent}
}
function Protect-Folder([string]$Path){
 Assert-NoReparse $Path;New-Item -ItemType Directory -Path $Path -Force|Out-Null
 $acl=New-Object Security.AccessControl.DirectorySecurity;$acl.SetAccessRuleProtection($true,$false)
 $acl.SetOwner((New-Object Security.Principal.SecurityIdentifier('S-1-5-32-544')))
 foreach($entry in @(@('S-1-5-18','FullControl'),@('S-1-5-32-544','FullControl'),@('S-1-5-32-545','ReadAndExecute'))){
  $sid=New-Object Security.Principal.SecurityIdentifier($entry[0]);$rule=New-Object Security.AccessControl.FileSystemAccessRule($sid,$entry[1],'ContainerInherit,ObjectInherit','None','Allow');$acl.AddAccessRule($rule)
 };Set-Acl -LiteralPath $Path -AclObject $acl
}
function Check-UnresolvedState {
 Assert-NoReparse $state
 if(Test-Path -LiteralPath $state){foreach($file in @(Get-ChildItem -LiteralPath $state -Filter '*.json' -File|Where-Object{$_.Name-notlike '*.report.json'})){
  Assert-NoReparse $file.FullName;$record=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json
  if($record.Status-ne 'Restored'){
   if($record.SchemaVersion -in @(1,2) -and $record.Status-in @('Applying','Applied','ExportAccess','RestoreFailed','LegacyPartialRestored')){Write-Warning 'Installing corrected helper in maintenance mode. Legacy review remains required; no restrictions/restoration executed.'}
   elseif($record.SchemaVersion-eq 3 -and $record.Status-eq 'RestoreFailed' -and $record.HelperRevision-eq 'beta3-safe-registry-1' -and $record.SessionId-match '^[a-f0-9]{32}$' -and $file.BaseName-eq $record.SessionId -and $record.Detail-eq 'Unrelated registry properties changed. Preserved evidence; do not overwrite external changes.'){
    $reportPath=Join-Path $state ($record.SessionId+'.Restore.report.json')
    if(-not(Test-Path -LiteralPath $reportPath)){throw 'Verified USB-enumeration recovery report is missing. Preserve evidence; setup stopped.'}
    Assert-NoReparse $reportPath;$report=Get-Content -LiteralPath $reportPath -Raw -Encoding UTF8|ConvertFrom-Json
    if($report.SessionId-ne $record.SessionId -or $report.Action-ne 'Restore' -or $report.Success-ne $false -or $report.Message-ne $record.Detail){throw 'USB-enumeration recovery evidence does not match the protected snapshot. Preserve evidence; setup stopped.'}
    Write-Warning 'Installing the corrected helper for the verified USB-enumeration restoration false conflict. Snapshot remains unresolved and is not edited or restored by setup.'
   }
   else{throw 'Unresolved/corrupt Beta 3 state blocks setup. Preserve evidence; resolve with corrected helper.'}
  }
 }}
}
function Wait-AppExit {
 for($attempt=0;$attempt-lt 30;$attempt++){
  if(@(Get-Process AccommodationTestManager -ErrorAction SilentlyContinue).Count-eq 0){return}
  if($attempt-eq 0){Write-Output 'Waiting for the app and its windows to close...'}
  Start-Sleep -Seconds 1
 }
 if(@(Get-Process AccommodationTestManager -ErrorAction SilentlyContinue).Count-gt 0){throw 'The app has not closed yet. Close remaining windows and retry. No process was forced to stop.'}
}
Wait-AppExit
Check-UnresolvedState
Assert-NoReparse $install;Assert-NoReparse $stateParent;Assert-NoReparse $PayloadFolder;Assert-NoReparse $DocsFolder
foreach($needed in @('AccommodationTestManager.exe','AccommodationTestManager.dll','coreclr.dll','hostfxr.dll','Scripts\Beta2Restrictions.ps1','Scripts\Beta2PinReset.ps1','Broker\AtmMachineBroker.exe')){
 if(-not(Test-Path -LiteralPath (Join-Path $PayloadFolder $needed))){throw ('Bundled setup payload incomplete: '+$needed)}
}
$id=[guid]::NewGuid().ToString('N');$staging=Join-Path $env:ProgramFiles ('AccommodationTestManagerBeta2-setup-'+$id);$backup=Join-Path $env:ProgramFiles ('AccommodationTestManagerBeta2-backup-'+$id)
$swapped=$false;$hadPrevious=Test-Path -LiteralPath $install
$oldService=$null;$serviceCreated=$false;$serviceWasRunning=$false;$committed=$false
$edgeState=Join-Path $stateParent "EdgeBackgroundPolicy.json";$edgePath="HKLM:\SOFTWARE\Policies\Microsoft\Edge";$edgeNew=$false
. (Join-Path $PSScriptRoot "Edge-BackgroundPolicy.ps1")
try {
 Protect-Folder $staging
 Copy-Item -Path (Join-Path $PayloadFolder '*') -Destination $staging -Recurse -Force
 New-Item -ItemType Directory -Path (Join-Path $staging 'Docs') -Force|Out-Null
 Copy-Item -Path (Join-Path $DocsFolder '*') -Destination (Join-Path $staging 'Docs') -Recurse -Force
 $files=@(Get-ChildItem -LiteralPath $staging -Recurse -File|ForEach-Object{$_.FullName.Substring($staging.Length+1)})
 foreach($file in Get-ChildItem -LiteralPath $PayloadFolder -Recurse -File){
  $relative=$file.FullName.Substring([IO.Path]::GetFullPath($PayloadFolder).TrimEnd('\').Length+1)
  if((Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash-ne (Get-FileHash -LiteralPath (Join-Path $staging $relative) -Algorithm SHA256).Hash){throw ('Payload copy verification failed: '+$relative)}
 }
 $manifest=@{Product='AccommodationTestManagerBeta2';SetupVersion='1.0.0-beta.4.6-setup.1';Files=$files}
 $manifest|ConvertTo-Json -Depth 5|Set-Content -LiteralPath (Join-Path $staging 'setup-installed-files.json') -Encoding UTF8
 # Ensure copied files inherit the protected, administrator-owned staging ACL.
 & icacls.exe $staging /reset /T /C|Out-Null;if($LASTEXITCODE-ne 0){throw 'File permission reset failed.'}
 Protect-Folder $staging
 Protect-Folder $stateParent;Protect-Folder $state
 # Archive before swapping the helper, including old .bak and diagnostic files. Never modify the source snapshots.
 $legacy=@(Get-ChildItem -LiteralPath $state -Filter '*.json' -File|Where-Object{$_.Name-notlike '*.report.json'}|Where-Object{(Get-Content $_.FullName -Raw|ConvertFrom-Json).SchemaVersion-lt 3})
 if($legacy.Count){
  $archive=Join-Path $stateParent ('LegacyEvidence\'+$id);Protect-Folder $archive
  foreach($source in Get-ChildItem -LiteralPath $state -File){Assert-NoReparse $source.FullName;Copy-Item -LiteralPath $source.FullName -Destination $archive;if((Get-FileHash $source.FullName).Hash-ne (Get-FileHash (Join-Path $archive $source.Name)).Hash){throw 'Legacy evidence archive hash mismatch.'}}
 }
 Check-UnresolvedState
 if(@(Get-Process AccommodationTestManager -ErrorAction SilentlyContinue).Count-gt 0){throw 'App reopened during setup. Close it and retry.'}
 # Collect/validate service configuration before stopping anything.
 $serviceConfig=Get-CimInstance Win32_Service -Filter "Name='AtmMachineBroker'" -ErrorAction Stop
 if($serviceConfig -and ($serviceConfig.PathName.Trim('"') -ne (Join-Path $install 'Broker\AtmMachineBroker.exe') -or $serviceConfig.StartName -ne 'LocalSystem')){throw 'Unexpected broker service configuration. Administrator review required.'}
 $oldService=Get-Service AtmMachineBroker -ErrorAction SilentlyContinue
 $serviceWasRunning=$oldService -and $oldService.Status-eq 'Running' 
 if($oldService){Stop-Service AtmMachineBroker -ErrorAction Stop;$oldService.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(30))}
 if($hadPrevious){Move-Item -LiteralPath $install -Destination $backup}
 try{Move-Item -LiteralPath $staging -Destination $install;$swapped=$true}
 catch{if($hadPrevious -and (Test-Path -LiteralPath $backup) -and -not(Test-Path -LiteralPath $install)){Move-Item -LiteralPath $backup -Destination $install};throw}
 $broker=Join-Path $install 'Broker\AtmMachineBroker.exe'
 if(-not(Test-Path -LiteralPath $broker)){throw 'Machine broker payload missing.'}
 $brokerCredential='C:\ProgramData\AccommodationTestingBeta2\Broker\credential.json'
 if($ConfigureBroker -and -not(Test-Path -LiteralPath $brokerCredential)){
  $enroll=Start-Process $broker -ArgumentList '--enroll' -Wait -PassThru
  if($enroll.ExitCode-ne 0){throw 'Machine PIN setup cancelled. Run setup again to finish.'}
 }
 if(-not(Get-Service AtmMachineBroker -ErrorAction SilentlyContinue)){
  $serviceCreated=$true
  New-Service -Name AtmMachineBroker -BinaryPathName ('"'+$broker+'"') -DisplayName 'Accommodation Test Manager controls' -StartupType Automatic|Out-Null
 }
 Start-Service AtmMachineBroker -ErrorAction Stop
 (Get-Service AtmMachineBroker).WaitForStatus('Running',[TimeSpan]::FromSeconds(30))
 # Do not change policy while a prior machine-state restoration is unresolved.
 $pending=@(Get-ChildItem -LiteralPath $state -Filter '*.json' -File|Where-Object{$_.Name-notlike '*.report.json'}|Where-Object{(Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json).Status-ne 'Restored'})
 if($pending.Count-eq 0){Assert-NoReparse $edgeState;$edgeNew=-not(Test-Path -LiteralPath $edgeState);Install-EdgeBaseline $edgePath $edgeState}
 else{Write-Warning 'Edge background setup skipped while recovery is pending. Resolve recovery and run setup again.'}
 $committed=$true
 if(Test-Path -LiteralPath $backup){try{Remove-Item -LiteralPath $backup -Recurse -Force}catch{Write-Warning ('Previous install backup retained: '+$backup)}}
 Write-Output 'App, bundled runtime, helper and protected helper-state folders installed. Existing local settings/sessions/snapshots preserved.'
 Write-Output 'No test restrictions applied. Run the app normally under the standard testing account.'
} catch {
 $failure=$_
 if(-not $committed){
  if($edgeNew -and (Test-Path -LiteralPath $edgeState)){try{Restore-EdgeBaseline $edgePath $edgeState}catch{Write-Warning "Edge setup rollback needs administrator review; baseline retained."}}
  # Never delete the previous install until the replacement service has started.
  if($swapped){
   $replacement=Get-Service AtmMachineBroker -ErrorAction SilentlyContinue
   if($replacement){Stop-Service AtmMachineBroker -ErrorAction Stop;$replacement.WaitForStatus('Stopped',[TimeSpan]::FromSeconds(180))}
   if(Test-Path -LiteralPath $install){Assert-NoReparse $install;Remove-Item -LiteralPath $install -Recurse -Force}
  }
  if($hadPrevious -and (Test-Path -LiteralPath $backup) -and -not(Test-Path -LiteralPath $install)){Move-Item -LiteralPath $backup -Destination $install}
  if($serviceCreated){& sc.exe delete AtmMachineBroker|Out-Null;if($LASTEXITCODE-ne 0){throw 'Setup failed; new service removal needs administrator review. Previous install backup is retained.'}}
  if($oldService -and $serviceWasRunning){Start-Service AtmMachineBroker -ErrorAction Stop}
 }
 throw $failure
} finally {
 if(-not $swapped -and (Test-Path -LiteralPath $staging)){Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue}
}
