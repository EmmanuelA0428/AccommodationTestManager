# CTL TestDesk RC1

Display branding only: existing device identity, service name, storage locations and upgrade paths are retained.

- New app/installer icon and CTL TestDesk name.
- Concise setup/review/handoff; no old Start Beta 3 dialog; startup progress overlay.
- Update action alongside sync status; existing verified download/install and unresolved-session gates retained.
- TTS/STT default on; reading guide/tint default off; all four available. Visual overlays begin inactive each new session. Timer hidden without inheriting a configured deadline.
- Session-scoped PIN reuse for Resume/Export/Cancel; revoked on student return, expiry, PIN change, Windows session switch and app closure. Administrative settings are not unlocked by that cache.
- Chronological start/completion sorting with ascending/descending headers, completion column, real laptop access labels, local-only folder opening, visible errors.
- One-time shared six-person roster migration and Jen Johnson deactivation; conflict checks and historical attribution retained.
- Deterministic archival view of completed pilot records before a fixed boundary. No file/snapshot deletions or Firestore security-rule expansion.

## Validation scope
Portable tests exercise coordinator, storage, outbox, roster, archive policy and update paths. Firebase emulator tests exercise access rules and two-client REST synchronization. Windows CI exercises real WPF controls, install/uninstall and standard-user broker identity/PIN. Real Word, physical USB, managed Edge behavior and campus policies still need a laptop acceptance pass.
