# CTL TestDesk RC2

RC2 retains the RC1 workflow, storage, service and upgrade identities.

- Corrects a false restoration conflict caused by normal USB device-enumeration changes after staff insert an export drive. Unrelated service-root values and policy branches remain protected from overwrite.
- Leaves USB storage connected during Export & Complete without removal or reinsertion prompts. Opens the save dialog at a single available removable drive, or uses the normal destination picker when automatic selection is unavailable.
- Keeps existing recovery snapshots compatible so a failed RC1 restoration can be retried after updating.
- Allows setup to replace the helper only for the exact preserved RC1 USB-enumeration false-conflict snapshot and matching failed Restore report. All other unresolved schema 3 states still block setup.
- Restores readable All tests column headers in dark mode by inheriting the active theme style while retaining sorting tooltips and indicators.

## Validation scope

Portable coordinator, storage, outbox, configuration, update and policy checks run before publication. Windows CI must also pass the isolated real-registry preservation test, native WPF light/dark checks, install/upgrade/uninstall, and standard-user protected-service authorization. Physical USB-connected export/restore and the affected laptop’s preserved recovery snapshot still require a real-laptop acceptance pass.
## Export without USB prompts
Leave USB storage connected during Export & Complete. No removal or reinsertion prompt is shown. The save window selects a single available removable drive automatically; otherwise choose the destination normally. Recovery snapshots and policy-conflict safeguards remain unchanged.
