# CTL TestDesk RC2

RC2 retains the RC1 workflow, storage, service and upgrade identities.

- Corrects a false restoration conflict caused by normal USB device-enumeration changes after staff insert an export drive. Unrelated service-root values and policy branches remain protected from overwrite.
- Guides staff to remove the USB drive before export access, detects the reinserted drive (including external disks Windows reports as fixed), and opens the save dialog directly there when one drive is found.
- Keeps existing recovery snapshots compatible so a failed RC1 restoration can be retried after updating.
- Restores readable All tests column headers in dark mode by inheriting the active theme style while retaining sorting tooltips and indicators.

## Validation scope

Portable coordinator, storage, outbox, configuration, update and policy checks run before publication. Windows CI must also pass the isolated real-registry preservation test, native WPF light/dark checks, install/upgrade/uninstall, and standard-user protected-service authorization. Physical USB removal/reinsertion and the affected laptop’s preserved recovery snapshot still require a real-laptop acceptance pass.