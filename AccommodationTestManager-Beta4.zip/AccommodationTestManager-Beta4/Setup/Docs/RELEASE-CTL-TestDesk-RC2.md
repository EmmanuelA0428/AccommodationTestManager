# CTL TestDesk Beta 4.5 — accessibility window and supports polish

- Edge opens Canvas/Posit/custom websites in a normal, resizable window, not forced full-screen or maximized. Word also starts in normal window mode.
- Focus-return assistance no longer pins the exam window always-on-top, avoiding an overlap condition that can cover Windows Voice Access controls. Accessibility-process exemptions and staff-PIN handoff remain. This is focus assistance, not Windows kiosk lockdown.
- Approved supports now use evenly sized, themed choice cards matching Choose the test. Multiple selections, accessible checkbox semantics, and existing defaults remain: TTS/STT on, reading guide/tint/larger controls off.
- Retains Beta 4.4 USB-connected export, registry preservation and narrowly verified recovery-maintenance setup behavior. Existing local files, settings and recovery evidence are preserved.

## Acceptance
Native Windows CI validates support bindings, layout, light/dark themes, normal owned Edge windows, registry preservation and installer/broker behavior. Real Voice Access (language/microphone readiness, toolbar visibility and dictation), Word, managed Canvas/Posit and physical export/restore still require laptop acceptance. No claim of secure app containment. The unrelated updater null-reference and cloud-only pilot record deletion remain separate unresolved items.
