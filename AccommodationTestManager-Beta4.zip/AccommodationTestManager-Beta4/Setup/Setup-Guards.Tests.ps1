# Read-only/mocked setup guard tests. Does not execute either script entrypoint,
# apply ACLs, invoke Windows cmdlets, install, uninstall or change machine settings.
$ErrorActionPreference='Stop'
$source=Join-Path $PSScriptRoot 'Install-OneClick.ps1'
$tokens=$null;$errors=$null;$ast=[System.Management.Automation.Language.Parser]::ParseFile($source,[ref]$tokens,[ref]$errors)
if($errors.Count){throw $errors[0]}
$wanted=@('Assert-NoReparse','Check-UnresolvedState','Wait-AppExit')
$definitions=$ast.FindAll({param($n) $n -is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name -in $wanted},$true)
foreach($d in $definitions){. ([scriptblock]::Create($d.Extent.Text))}
$checks=0
function Check($condition,[string]$label){if(-not $condition){throw ('FAILED: '+$label)};$script:checks++;Write-Output ('PASS: '+$label)}
function Expect-Failure([scriptblock]$action,[string]$label){$failed=$false;try{& $action}catch{$failed=$true};Check $failed $label}
$root=Join-Path ([IO.Path]::GetTempPath()) ('ATM-Setup-Guards-'+[guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $root|Out-Null
$script:state=Join-Path $root 'RestrictionState'
try {
 Check-UnresolvedState;Check $true 'missing state folder allowed for first install'
 New-Item -ItemType Directory -Path $state|Out-Null
 Check-UnresolvedState;Check $true 'empty state folder allowed'
 $file=Join-Path $state 'synthetic.json'
 '{"Status":"Restored"}'|Set-Content -LiteralPath $file
 '{"Success":false,"Message":"Synthetic diagnostics"}'|Set-Content (Join-Path $state 'synthetic.Apply.report.json')
 Check-UnresolvedState;Check $true 'diagnostic action report is not a restriction snapshot'
 $before=[IO.File]::ReadAllBytes($file)
 Check-UnresolvedState;Check $true 'Restored snapshot permits setup'
 Check ([Convert]::ToBase64String($before)-eq [Convert]::ToBase64String([IO.File]::ReadAllBytes($file))) 'guard preserves snapshot bytes'
 foreach($status in @('Applying','Applied','ExportAccess','RestoreFailed')){
  ('{"Status":"'+$status+'"}')|Set-Content -LiteralPath $file
  Expect-Failure {Check-UnresolvedState} ('unresolved '+$status+' blocks setup')
 }
 '{"SchemaVersion":2,"Status":"Applied"}'|Set-Content -LiteralPath $file
 $legacyBefore=[IO.File]::ReadAllBytes($file)
 Check-UnresolvedState;Check $true 'legacy pending state permits corrected-helper maintenance install'
 Check ([Convert]::ToBase64String($legacyBefore)-eq [Convert]::ToBase64String([IO.File]::ReadAllBytes($file))) 'maintenance guard never edits legacy snapshot'
 '{"SchemaVersion":3,"Status":"Applied"}'|Set-Content -LiteralPath $file
 Expect-Failure {Check-UnresolvedState} 'pending Beta 3 state still blocks ordinary upgrade'
 '{ broken JSON'|Set-Content -LiteralPath $file
 Expect-Failure {Check-UnresolvedState} 'damaged state blocks setup'
 '{}'|Set-Content -LiteralPath $file
 Expect-Failure {Check-UnresolvedState} 'missing status blocks setup'
 '{"Status":"Restored"}'|Set-Content -LiteralPath $file
 '{"Status":"Applied"}'|Set-Content -LiteralPath ($file+'.bak')
 Check-UnresolvedState;Check $true 'backup files are not mistaken for canonical snapshots'
 Check (Test-Path -LiteralPath ($file+'.bak')) 'snapshot backup not deleted'
 $link=Join-Path $root 'LinkedState';New-Item -ItemType SymbolicLink -Path $link -Target $state|Out-Null
 $script:state=$link
 Expect-Failure {Check-UnresolvedState} 'reparse/symlink state directory rejected'
 $script:poll=0;$script:sleeps=0;$script:closeAfter=2
 function Get-Process {param($Name,$ErrorAction) $script:poll++;if($script:poll-le $script:closeAfter){[pscustomobject]@{Id=123}}}
 function Start-Sleep {param($Seconds) $script:sleeps++}
 Wait-AppExit;Check ($script:sleeps-eq 2) 'installer waits for leftover app windows without killing processes'
 $script:poll=0;$script:sleeps=0;$script:closeAfter=999
 Expect-Failure {Wait-AppExit} 'installer refuses app still running after bounded wait'
 Check ($script:sleeps-eq 30) 'installer wait is bounded to thirty seconds'
 Check (-not ((Get-Content $source -Raw)-match 'Stop-Process|taskkill')) 'installer has no forced process termination'
 Write-Output ('ALL '+$checks+' SETUP GUARD CHECKS PASSED - filesystem checks only; no native Windows installation validation.')
} finally {Remove-Item -LiteralPath $root -Recurse -Force}
