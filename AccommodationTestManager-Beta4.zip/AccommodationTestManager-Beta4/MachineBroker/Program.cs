using System.Diagnostics;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Cryptography;
using System.Security.Principal;
using System.ServiceProcess;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Windows.Forms;

internal sealed record Credential(string Salt,string Hash);
internal sealed record Request(string Action,string? Pin=null,string? Token=null,string? SessionId=null,JsonElement? Plan=null);
internal sealed record Response(bool Success,string Message,string? Token=null);
internal static class Program
{
 internal const string PipeName="ATM-Machine-Broker-v4";
 internal static readonly string Root=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"AccommodationTestingBeta2","Broker");
 internal static readonly string CredentialPath=Path.Combine(Root,"credential.json");
 internal static void NoLinks(string path){for(var d=new DirectoryInfo(path);d is not null;d=d.Parent)if(d.Exists&&(d.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked broker path rejected.");}
 internal static void ProtectRoot(){NoLinks(Root);Directory.CreateDirectory(Root);var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);acl.SetOwner(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null));foreach(var sid in new[]{WellKnownSidType.LocalSystemSid,WellKnownSidType.BuiltinAdministratorsSid})acl.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid,null),FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));new DirectoryInfo(Root).SetAccessControl(acl);foreach(var file in new[]{CredentialPath,CredentialPath+".new"}){if(!File.Exists(file))continue;if((File.GetAttributes(file)&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked credential file rejected.");var access=new FileSecurity();access.SetAccessRuleProtection(true,false);access.SetOwner(new SecurityIdentifier(WellKnownSidType.BuiltinAdministratorsSid,null));foreach(var sid in new[]{WellKnownSidType.LocalSystemSid,WellKnownSidType.BuiltinAdministratorsSid})access.AddAccessRule(new FileSystemAccessRule(new SecurityIdentifier(sid,null),FileSystemRights.FullControl,AccessControlType.Allow));new FileInfo(file).SetAccessControl(access);}}
 internal static void SaveCredential(string pin){if(!Regex.IsMatch(pin,@"^[0-9]{6,32}$"))throw new ArgumentException("Use 6–32 digits.");ProtectRoot();byte[] salt=RandomNumberGenerator.GetBytes(16);var c=new Credential(Convert.ToBase64String(salt),Convert.ToBase64String(Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(pin),salt,100000,HashAlgorithmName.SHA256,32)));string temp=CredentialPath+".new";if(File.Exists(temp))File.Delete(temp);File.WriteAllText(temp,JsonSerializer.Serialize(c));File.Move(temp,CredentialPath,true);}
 internal static bool Verify(string? pin){if(pin is null||!Regex.IsMatch(pin,@"^[0-9]{6,32}$"))return false;NoLinks(Root);var c=JsonSerializer.Deserialize<Credential>(File.ReadAllText(CredentialPath))!;return CryptographicOperations.FixedTimeEquals(Convert.FromBase64String(c.Hash),Rfc2898DeriveBytes.Pbkdf2(Encoding.UTF8.GetBytes(pin),Convert.FromBase64String(c.Salt),100000,HashAlgorithmName.SHA256,32));}
 [STAThread]static void Main(string[] args){if(args.SequenceEqual(new[]{"--enroll"})){using var id=WindowsIdentity.GetCurrent();if(!new WindowsPrincipal(id).IsInRole(WindowsBuiltInRole.Administrator))throw new UnauthorizedAccessException("Administrator setup required.");Application.EnableVisualStyles();var f=new Form{Text="Set staff PIN for machine controls",Width=420,Height=245,StartPosition=FormStartPosition.CenterScreen};var p=new FlowLayoutPanel{Dock=DockStyle.Fill,FlowDirection=FlowDirection.TopDown,Padding=new Padding(18),WrapContents=false};f.Controls.Add(p);p.Controls.Add(new Label{Text="Use the same staff PIN as the app (6–32 digits).",AutoSize=true});var a=new TextBox{UseSystemPasswordChar=true,Width=350};var b=new TextBox{UseSystemPasswordChar=true,Width=350};p.Controls.Add(a);p.Controls.Add(new Label{Text="Confirm PIN",AutoSize=true});p.Controls.Add(b);var error=new Label{AutoSize=true};var save=new Button{Text="Save PIN",Width=120};p.Controls.Add(error);p.Controls.Add(save);save.Click+=(_,_)=>{try{if(a.Text!=b.Text)throw new ArgumentException("PINs do not match.");SaveCredential(a.Text);a.Clear();b.Clear();f.DialogResult=DialogResult.OK;f.Close();}catch(Exception e){error.Text=e.Message;}};if(f.ShowDialog()!=DialogResult.OK)Environment.Exit(2);return;}ServiceBase.Run(new BrokerService());}
}
internal sealed class BrokerService:ServiceBase
{
 private readonly CancellationTokenSource stop=new();private readonly SemaphoreSlim operations=new(1,1);
 private Task? listener;
 private readonly Dictionary<string,(string Sid,uint Session,DateTimeOffset Until,string Credential)> grants=[];
 private static string CredentialRevision()=>Convert.ToHexString(SHA256.HashData(File.ReadAllBytes(Program.CredentialPath)));
 private readonly Dictionary<string,(int Count,DateTimeOffset Until)> failures=[];
 [DllImport("kernel32.dll",SetLastError=true)]static extern bool GetNamedPipeClientSessionId(IntPtr pipe,out uint session);
 public BrokerService(){ServiceName="AtmMachineBroker";CanStop=true;AutoLog=false;}
 protected override void OnStart(string[] args){Program.ProtectRoot();listener=Listen();}
 protected override void OnStop(){stop.Cancel();RequestAdditionalTime(180000);if(listener is not null&&!listener.Wait(TimeSpan.FromMinutes(3)))throw new IOException("Machine action still running; service was not stopped safely.");}
 private async Task Listen(){while(!stop.IsCancellationRequested){NamedPipeServerStream? pipe=null;try{var acl=new PipeSecurity();acl.SetAccessRuleProtection(true,false);acl.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.NetworkSid,null),PipeAccessRights.FullControl,AccessControlType.Deny));foreach(var sid in new[]{WellKnownSidType.LocalSystemSid,WellKnownSidType.BuiltinAdministratorsSid})acl.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(sid,null),PipeAccessRights.FullControl,AccessControlType.Allow));acl.AddAccessRule(new PipeAccessRule(new SecurityIdentifier(WellKnownSidType.InteractiveSid,null),PipeAccessRights.ReadWrite,AccessControlType.Allow));pipe=NamedPipeServerStreamAcl.Create(Program.PipeName,PipeDirection.InOut,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous|PipeOptions.FirstPipeInstance,4096,4096,acl);await pipe.WaitForConnectionAsync(stop.Token);await Handle(pipe);}catch(OperationCanceledException){break;}catch{if(!stop.IsCancellationRequested)await Task.Delay(500);}finally{pipe?.Dispose();}}}
 private async Task Handle(NamedPipeServerStream pipe){Response response;try{using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(10));string? sid=null;pipe.RunAsClient(()=>{using var user=WindowsIdentity.GetCurrent(TokenAccessLevels.Query);if(!user.IsAuthenticated||user.User is null)throw new UnauthorizedAccessException();sid=user.User.Value;});if(!GetNamedPipeClientSessionId(pipe.SafePipeHandle.DangerousGetHandle(),out uint session)||session==0)throw new UnauthorizedAccessException("Interactive laptop session required.");using var reader=new StreamReader(pipe,new UTF8Encoding(false,true),false,4096,true);var text=new StringBuilder();char[] ch=new char[1];while(text.Length<=65536){int n=await reader.ReadAsync(ch,timeout.Token);if(n==0)throw new IOException("Incomplete request.");if(ch[0]=='\n')break;text.Append(ch[0]);}if(text.Length>65536)throw new IOException("Request too large.");var request=JsonSerializer.Deserialize<Request>(text.ToString())??throw new IOException("Invalid request.");response=await Execute(request,sid!,session);}catch(Exception e){response=new(false,e is UnauthorizedAccessException?"Staff authorization required.":e.Message);}using var writer=new StreamWriter(pipe,new UTF8Encoding(false),4096,true){AutoFlush=true};using var replyTimeout=new CancellationTokenSource(TimeSpan.FromSeconds(5));await writer.WriteLineAsync(JsonSerializer.Serialize(response).AsMemory(),replyTimeout.Token);}
 private async Task<Response> Execute(Request r,string sid,uint session)
 {
  if(r.Action=="Authenticate"){
   if(failures.TryGetValue(sid,out var f)&&f.Until>DateTimeOffset.UtcNow&&f.Count>=5)return new(false,"Too many attempts. Wait one minute.");
   if(!File.Exists(Program.CredentialPath))return new(false,"Machine PIN is not configured. Run setup normally to configure it.");
   if(!Program.Verify(r.Pin)){int count=failures.TryGetValue(sid,out f)&&f.Until>DateTimeOffset.UtcNow?f.Count+1:1;failures[sid]=(count,DateTimeOffset.UtcNow.AddMinutes(1));return new(false,"Incorrect machine-control PIN.");}
   failures.Remove(sid);foreach(var key in grants.Where(x=>x.Value.Until<DateTimeOffset.UtcNow||x.Value.Sid==sid).Select(x=>x.Key).ToArray())grants.Remove(key);string token=Convert.ToHexString(RandomNumberGenerator.GetBytes(32));grants[token]=(sid,session,DateTimeOffset.UtcNow.AddMinutes(30),CredentialRevision());return new(true,"Authorized",token);
  }
  if(r.Token is null||!grants.TryGetValue(r.Token,out var grant)||grant.Sid!=sid||grant.Session!=session||grant.Until<DateTimeOffset.UtcNow||grant.Credential!=CredentialRevision())return new(false,"Enter the staff PIN again.");
  if(r.Action=="SetPin"){Program.SaveCredential(r.Pin??"");grants.Clear();return new(true,"Machine PIN updated.");}
  if(r.Action=="CloseEdge"){
   var plan=r.Plan??throw new IOException("Missing Edge close scope.");
   if(plan.ValueKind!=JsonValueKind.Object||plan.EnumerateObject().Count()!=1||!plan.TryGetProperty("Scope",out var scopeValue)||scopeValue.ValueKind!=JsonValueKind.String||scopeValue.GetString() is not ("current" or "all"))throw new IOException("Invalid Edge close scope.");
   await operations.WaitAsync();try{return await CloseEdge(scopeValue.GetString()!,session);}finally{operations.Release();}
  }
  if(r.Action is not ("Apply" or "Restore" or "ExportAccess")||r.SessionId is null||!Regex.IsMatch(r.SessionId,"^[a-f0-9]{32}$"))throw new UnauthorizedAccessException("Unsupported machine action.");
  await operations.WaitAsync();string? requestPath=null;
  try{
   string install=Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"AccommodationTestManagerBeta2");Program.NoLinks(install);string helper=Path.Combine(install,"Scripts","Beta2Restrictions.ps1");if(!File.Exists(helper)||(File.GetAttributes(helper)&FileAttributes.ReparsePoint)!=0)throw new IOException("Protected helper unavailable.");
   if(r.Action=="Apply"){
    var plan=r.Plan??throw new IOException("Missing control plan.");ValidatePlan(plan);requestPath=Path.Combine(Program.Root,Guid.NewGuid().ToString("N")+".json");await File.WriteAllTextAsync(requestPath,plan.GetRawText());
   }
   var info=new ProcessStartInfo(Path.Combine(Environment.SystemDirectory,"WindowsPowerShell","v1.0","powershell.exe")){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};foreach(var arg in new[]{"-NoProfile","-NonInteractive","-ExecutionPolicy","Bypass","-File",helper,"-Action",r.Action,"-SessionId",r.SessionId})info.ArgumentList.Add(arg);if(requestPath is not null){info.ArgumentList.Add("-RequestPath");info.ArgumentList.Add(requestPath);}using var process=Process.Start(info)??throw new IOException("Machine helper could not start.");var stdout=process.StandardOutput.BaseStream.CopyToAsync(Stream.Null);var stderr=process.StandardError.BaseStream.CopyToAsync(Stream.Null);await process.WaitForExitAsync();await Task.WhenAll(stdout,stderr);return new(process.ExitCode==0,process.ExitCode==0?"Machine action completed.":"Machine action failed. Open diagnostics; keep the recovery snapshot.");
  }finally{if(requestPath is not null)File.Delete(requestPath);operations.Release();}
 }
 // Only the installed stable Edge executable is eligible. Never kill an arbitrary PID or process tree.
 private static async Task<Response> CloseEdge(string scope,uint requesterSession)
 {
  var allowed=new[]{Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles)}
   .Where(x=>!string.IsNullOrWhiteSpace(x)).Select(x=>Path.GetFullPath(Path.Combine(x,"Microsoft","Edge","Application","msedge.exe"))).ToArray();
  for(int attempt=0;attempt<20;attempt++){
   var all=Process.GetProcessesByName("msedge");bool found=false;
   try{foreach(var p in all){
    try{if(p.HasExited)continue;if(scope=="current"&&p.SessionId!=(int)requesterSession)continue;found=true;
     string? exe=p.MainModule?.FileName;if(exe is null||!allowed.Contains(Path.GetFullPath(exe),StringComparer.OrdinalIgnoreCase))throw new IOException("Unverified Edge process; no further processes were closed. Ask staff to review.");
     p.Kill(entireProcessTree:false);
    }catch(InvalidOperationException){/* Process exited. */}
   }}finally{foreach(var p in all)p.Dispose();}
   if(!found)return new(true,"Edge processes closed.");await Task.Delay(250);
  }
  throw new IOException("Edge did not fully close. No test was started; ask staff to review running processes.");
 }
 internal static void ValidatePlan(JsonElement p){var permitted=new[]{"Mode","IsolateNetwork","Allowlist","DisableBrowserAI","AiPolicies","BlockedAIUrls","ApplicationLockdown"};if(p.ValueKind!=JsonValueKind.Object||p.EnumerateObject().Any(x=>!permitted.Contains(x.Name))||p.GetProperty("Mode").GetString() is not ("Online" or "Word" or "Desktop")||p.GetProperty("ApplicationLockdown").GetBoolean())throw new IOException("Unsupported control plan.");foreach(var name in new[]{"IsolateNetwork","DisableBrowserAI"})_ =p.GetProperty(name).GetBoolean();foreach(var name in new[]{"Allowlist","BlockedAIUrls"}){var values=p.GetProperty(name).EnumerateArray().ToArray();if(values.Length>999||values.Any(x=>x.GetString() is not string v||v.Length>2048||!v.StartsWith("https://",StringComparison.OrdinalIgnoreCase)||v.Any(char.IsControl)))throw new IOException("Invalid URL policy.");}var ai=new[]{"HubsSidebarEnabled","Microsoft365CopilotChatIconEnabled","ComposeInlineEnabled","AllowBrowsingWithCopilot","CopilotNewTabPageEnabled"};if(p.GetProperty("AiPolicies").EnumerateArray().Any(x=>!ai.Contains(x.GetString())))throw new IOException("Invalid AI policy.");}
}
