# Beta 3.2 working source — NOT PUBLISHED

## Prepared changes
- Startup public-release check with 8-second cancellation budget; nonblocking and no automatic download/install.
- Numeric stable/beta version ordering across beta generations; restricted project release assets and checksums retained.
- Separate verified download from installation. Downloads may occur with unfinished work; launch still requires idle sessions, restored machine state, and completed legacy review. Internet zone metadata retained.
- Update screen automatically checks when opened and explains no-update/network/install-blocked states.
- Consent-based normal Edge closure before creating a session. Current Windows session only, no force-kill, 10-second wait; refuses other-user or remaining background processes. Existing helper checks retained.
- Live student toolbar appears during preflight with actions disabled, and remains independent of staff-window minimization. Staff still must verify live controls before handoff.
- Opt-in automatic Word start: verifies intended saved writable document, corrected snapshot, USB restriction readback, and read-only adapter/USB-disk inventory before activation. Failed checks retain work and block manual bypass; timer waits for success. Resume rechecks controls and preserves remaining time. Manual preflight defaults ON until Windows acceptance.
- Browser/custom modes still require manual preflight/effective-policy evidence. With manual checks disabled, unsupported modes stop before session creation; this is not automatic browser handoff.
- The new PowerShell diagnostic was parsed without execution. Only commands are read-only Get-NetAdapter/Get-Disk, Where-Object, Join-Path, Infrastructure and ConvertTo-Json. Its own timed-out diagnostic process may be terminated, never Word/Edge.
- Version/install metadata advanced to 1.0.0-beta.3.2. Existing protected helper unchanged.

## Validation actually completed
- 176 developer checks passed on Linux: mock Word/restriction helper; real filesystem/config/coordinator; controlled HTTP update selection, download integrity, cancellation, install-gate and mutation regressions; automatic Word success/failure/cancellation/resume/restart and timer tests (Word/live machine verifier substituted).
- App and Windows UI harness compile with zero warnings/errors.
- Windows UI toolbar checks added, compiled but NOT EXECUTED. Graceful Edge closure and actual setup/download/UAC require Windows testing.
- No new installer produced or uploaded. Existing GitHub release remains Beta 3.1.

## Not implemented
Automatic effective browser policy validation/production browser handoff. Do not disable its evidence gate.

PIN-only machine operations. Current helper requires UAC. A separately designed, administrator-installed privileged broker is needed with protected staff authentication, fixed commands, secure IPC, and student-tamper resistance. Never treat an ordinary UI PIN as Windows elevation or expose arbitrary privileged commands.

## Windows acceptance before distribution
1. Verify offline startup remains responsive and update unavailable state is actionable.
2. Use a test newer release to check metadata, download, bad/incomplete checksum rejection, and no install with pending work/recovery.
3. Normal Edge closure: multiple windows, save/download prompts, background mode, another signed-in user, and closure cancellation. No force termination.
4. Preflight toolbar disabled; explicit staff confirmation enables controls. Minimize staff window; toolbar remains visible. Test actual full-screen Edge foreground/Z-order and multi-monitor positioning.
5. Start/finish/cancel/restart recovery with synthetic sessions; validate Wi-Fi/USB/Edge restoration and existing unrelated registry-value preservation.

6. Automatic Word mode (Manual preflight checks off): real Word COM document/save verification, standard-account read-only diagnostic permissions, correct adapter infrastructure exclusions, no online USB storage, timer activation only after success, failed query/readback blocking, retry/cancel restoration, restart recovery. Re-enable manual preflight before browser/custom tests. These Windows cases have NOT run.
