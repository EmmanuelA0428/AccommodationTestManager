using AccommodationTestManager;
using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using AccommodationTestManager.Views;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

sealed class ProbeApp:App { protected override void OnStartup(StartupEventArgs e) { /* Never run real app startup/registration in CI. */ } }
static class UiProbe
{
 static int _checks;
 static void Check(bool value,string message){if(!value)throw new Exception("UI FAIL: "+message);_checks++;Console.WriteLine("UI PASS: "+message);}
 static void Pump(){var frame=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ContextIdle,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}
 static T Named<T>(FrameworkElement element,string name) where T:DependencyObject=>(T)element.FindName(name);
 static void Invoke(object target,string name)=>target.GetType().GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(target,null);
 static void SetHost(App app,string name,object value)=>typeof(App).GetProperty(name)!.SetValue(app,value);
 [STAThread] public static int Main()
 {
  string root=Path.Combine(Path.GetTempPath(),"ATM-UiProbe-"+Guid.NewGuid().ToString("N"));
  Directory.CreateDirectory(root);
  try
  {
   SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext(Dispatcher.CurrentDispatcher));
   #pragma warning disable WPF0001 // Match the production App.xaml ThemeMode.
   var app=new ProbeApp { ShutdownMode=ShutdownMode.OnExplicitShutdown, ThemeMode=ThemeMode.Light };
   #pragma warning restore WPF0001
   // Load the real shared dictionaries without App.InitializeComponent, whose
   // generated resource loader requires the exact App type rather than ProbeApp.
   foreach(string resource in new[]{"Theme.xaml","Components.xaml"})
    app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source=new Uri("/AccommodationTestManager;component/Resources/"+resource,UriKind.Relative) });
   var storage=new LocalStorageService(root);
   LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),RequireMachineRestrictions=false});
   var settings=new SettingsService(storage);settings.Load();settings.Register("SYNTHETIC UI LAPTOP","FAKE",["Synthetic staff"],"654321");
   var lists=new AllowlistService(storage);lists.Initialize();var restrictions=new RestrictionService();var theme=new ThemeService(settings);var sessions=new SessionService(storage,settings,lists,restrictions);
   SetHost(app,"Storage",storage);SetHost(app,"Settings",settings);SetHost(app,"Allowlists",lists);SetHost(app,"Restrictions",restrictions);SetHost(app,"Theme",theme);SetHost(app,"Sessions",sessions);
   theme.Apply();var window=new MainWindow();window.Show();Pump();window.UpdateLayout();
   Check(window.Title=="CTL TestDesk"&&window.Icon is not null,"release branding and icon load");
   Check(Named<TextBlock>(window,"StartupUpdateStatus").Visibility==Visibility.Collapsed&&Named<TextBlock>(window,"GlobalConfigStatus").Visibility==Visibility.Collapsed,"developer startup prose hidden");
   var currentButtons=(StackPanel)Named<Button>(window,"ResumeSessionButton").Parent;
   Check(currentButtons.Orientation==Orientation.Horizontal&&ReferenceEquals(Named<Button>(window,"ExportSessionButton").Parent,currentButtons)&&ReferenceEquals(Named<Button>(window,"CancelPreparationButton").Parent,currentButtons),"resume, export and cancel share one horizontal row");
   var host=Named<ContentControl>(window,"StepHost");var student=(FrameworkElement)host.Content;
   var staff=Named<ComboBox>(student,"StaffChoice");var studentName=Named<TextBox>(student,"StudentNameInput");var testName=Named<TextBox>(student,"TestNameInput");
   staff.SelectedIndex=0;studentName.Text="Synthetic student";testName.Text="Layout probe only";Pump();window.UpdateLayout();
   foreach(string mode in new[]{"Light","Dark"})
   {
    settings.Current.Theme=mode;theme.Apply();Pump();window.UpdateLayout();staff.ApplyTemplate();
    var toggle=(ToggleButton)staff.Template.FindName("DropToggle",staff);
    Check(staff.ActualHeight>=43.5,mode+" staff selector retains 44-DIP height");
    Check(Math.Abs(staff.ActualWidth-studentName.ActualWidth)<2,mode+" staff selector fills the form like text fields");
    Check(toggle.ActualHeight>=43.5&&Math.Abs(toggle.ActualWidth-staff.ActualWidth)<2,mode+" dropdown chrome fills its selector");
    var feature=Named<Button>(window,"FeatureTestingButton");var gear=Named<Button>(window,"SettingsButton");var appearance=Named<Button>(window,"ThemeButton");
    Check(feature.Visibility==Visibility.Collapsed,"developer feature entry is hidden");
    double y=gear.TranslatePoint(new Point(),window).Y;
    Check(Math.Abs(gear.TranslatePoint(new Point(),window).Y-y)<1&&Math.Abs(appearance.TranslatePoint(new Point(),window).Y-y)<1,mode+" toolbar icons align with text buttons");
    Check(Named<Button>(window,"NextButton").IsEnabled,mode+" completed student information allows Continue");
    var bitmap=new RenderTargetBitmap((int)window.ActualWidth,(int)window.ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(window);
    var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using(var file=File.Create(Path.Combine(Environment.CurrentDirectory,"CTL-TestDesk-"+mode+"-synthetic-ui.png")))png.Save(file);
   }
   // Real support-card bindings, focus/accessibility semantics and equal spacing in both themes.
   typeof(MainWindow).GetField("_step",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(window,2);Invoke(window,"Refresh");Pump();
   var supports=(FrameworkElement)host.Content;
   var cards=new[]{"TextToSpeechChoice","SpeechToTextChoice","ReadingGuideChoice","ScreenTintChoice","LargeControlsChoice"}.Select(n=>Named<CheckBox>(supports,n)).ToArray();
   foreach(string mode in new[]{"Light","Dark"})
   {
    settings.Current.Theme=mode;theme.Apply();Pump();window.UpdateLayout();
    foreach(var card in cards){card.ApplyTemplate();Check(card.Template.FindName("Outline",card) is Border&&card.Template.FindName("Indicator",card) is Border,mode+" support uses the shared bordered choice-card template");}
    Check(cards.All(c=>Math.Abs(c.ActualHeight-cards[0].ActualHeight)<1)&&cards[0].ActualHeight>=88,mode+" all support cards have equal generous heights");
    Check(Math.Abs(cards[0].ActualWidth-cards[1].ActualWidth)<1&&Math.Abs(cards[2].ActualWidth-cards[3].ActualWidth)<1,mode+" two-column supports have equal widths");
    Check(cards[0].IsChecked==true&&cards[1].IsChecked==true&&cards.Skip(2).All(c=>c.IsChecked==false),mode+" TTS/STT stay enabled and other supports start off");
    var draft=(AccommodationTestManager.Models.TestSetupDraft)supports.DataContext;
    cards[2].IsChecked=true;Pump();Check(draft.ReadingGuide,"support card changes the draft binding");
    var peer=new System.Windows.Automation.Peers.CheckBoxAutomationPeer(cards[2]);
    var toggleProvider=(System.Windows.Automation.Provider.IToggleProvider)peer.GetPattern(System.Windows.Automation.Peers.PatternInterface.Toggle);
    toggleProvider.Toggle();Pump();Check(!draft.ReadingGuide,"support retains accessible checkbox toggle behavior");
    var bitmap=new RenderTargetBitmap((int)window.ActualWidth,(int)window.ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(window);
    var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using(var file=File.Create(Path.Combine(Environment.CurrentDirectory,"CTL-TestDesk-Supports-"+mode+"-synthetic-ui.png")))png.Save(file);
   }
   typeof(MainWindow).GetField("_step",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(window,0);Invoke(window,"Refresh");Pump();
   var next=Named<Button>(window,"NextButton");next.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));Pump();
   Check(Named<TextBlock>(window,"StepCounter").Text.Contains("Step 2"),"Continue advances from populated Student step");
   var testPage=(FrameworkElement)host.Content;Check(Named<TextBox>(testPage,"DurationInput").Visibility==Visibility.Collapsed&&Named<TextBlock>(testPage,"OnlineNotice").Visibility==Visibility.Collapsed,"timer and configured site prose are hidden");
   typeof(MainWindow).GetField("_step",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(window,0);Invoke(window,"Refresh");
   string id=Guid.NewGuid().ToString("N");string folder=storage.NewSessionFolder(id);
   var pending=new TestSession{Id=id,DeviceId=settings.Current.DeviceId,Status="Preparing",TestName="SYNTHETIC unfinished",CreatedUtc=DateTimeOffset.UtcNow};LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),pending);
   Invoke(window,"RecheckSetupReadiness");Invoke(window,"Refresh");Pump();
   Check(Named<Border>(window,"SetupBlockBanner").Visibility==Visibility.Visible,"unfinished session has visible actionable banner");
   Check(next.IsEnabled,"unfinished session permits draft Continue, not silent dead-end");
   typeof(MainWindow).GetField("_step",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(window,3);Invoke(window,"Refresh");Check(!next.IsEnabled,"Start remains blocked for unresolved session");
   pending.Status="Cancelled";LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),pending);Invoke(window,"RecheckSetupReadiness");Invoke(window,"Refresh");Check(next.IsEnabled,"resolved fixture clears cached navigation gate");
   // Real WPF collection-view sorting uses timestamps, never localized display strings.
   foreach(int minutes in new[]{1,10,2}){string rid=Guid.NewGuid().ToString("N");string rf=storage.NewSessionFolder(rid);LocalStorageService.WriteJson(Path.Combine(rf,"session.json"),new TestSession{Id=rid,DeviceId=settings.Current.DeviceId,TestName="Synthetic sort "+minutes,Mode="Word",Status="Completed",CreatedUtc=PilotRecordPolicy.Cutoff.AddDays(1).AddMinutes(minutes),CompletedUtc=PilotRecordPolicy.Cutoff.AddDays(1).AddMinutes(minutes+30)});}
   var records=new RecordsWindow("Synthetic staff"){Owner=window};records.Show();Pump();
   var grid=Named<DataGrid>(records,"SessionGrid");
   var dateColumn=grid.Columns.Single(x=>x.SortMemberPath=="Created");var completedColumn=grid.Columns.Single(x=>x.SortMemberPath=="Completed");
   Check(dateColumn.SortDirection==System.ComponentModel.ListSortDirection.Descending,"All tests starts newest first with a direction indicator");
   Check(grid.Columns.All(c=>c.HeaderStyle?.BasedOn is not null),"sorting header styles inherit readable light/dark theme colors");
   typeof(RecordsWindow).GetMethod("Grid_Sorting",BindingFlags.NonPublic|BindingFlags.Instance)!.Invoke(records,new object[]{grid,new DataGridSortingEventArgs(completedColumn)});Pump();
   var times=grid.Items.Cast<object>().Select(x=>(DateTimeOffset?)x.GetType().GetProperty("Completed")!.GetValue(x)).Where(x=>x is not null).ToArray();
   Check(times.SequenceEqual(times.OrderBy(x=>x))&&completedColumn.SortDirection==System.ComponentModel.ListSortDirection.Ascending,"completion sorting uses actual timestamps and ascending glyph");
   Named<TextBox>(records,"SearchBox").Text="Synthetic sort";Pump();
   Check(completedColumn.SortDirection==System.ComponentModel.ListSortDirection.Ascending,"filter preserves active sort and direction");
   Check(grid.Items.Cast<object>().All(x=>(string)x.GetType().GetProperty("Access")!.GetValue(x)! == settings.Current.LaptopName),"Access displays actual laptop label");records.Close();
   var pane=new SettingsWindow("Synthetic staff"){Owner=window};pane.Show();Pump();
   var check=Named<Button>(pane,"CheckUpdatesButton");check.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
   var deadline=DateTime.UtcNow.AddSeconds(40);while(!check.IsEnabled&&DateTime.UtcNow<deadline){Pump();Thread.Sleep(50);}
   Check(check.IsEnabled,"Check for updates completes without freezing UI");
   string status=Named<TextBlock>(pane,"UpdateStatusText").Text;
   Check(status.StartsWith("No newer compatible")||status.StartsWith("Available:"),"Check for updates reads real public release metadata");
   pane.Close();
   // UI-only fixture: no real helper, browser, document, or machine controls are invoked.
   var fixtureSession=new TestSession{Id=Guid.NewGuid().ToString("N"),Mode="Canvas",Status="Preflight",ReadingGuide=true,ScreenTint=true,LargeControls=true};
   typeof(SessionService).GetProperty("Current")!.SetValue(sessions,fixtureSession);
   Invoke(window,"EnsureStudentControls");Pump();
   var toolbar=(StudentTestWindow)typeof(MainWindow).GetField("_studentWindow",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(window)!;
   Check(toolbar.IsVisible&&toolbar.Owner is null&&toolbar.ShowInTaskbar,"live controls appear independently of staff window during preflight");
   Check(Named<Button>(toolbar,"FinishButton").Width==48&&Named<Button>(toolbar,"StaffButton").Width==48,"larger-controls accommodation enlarges live toolbar and targets");
   Check(Math.Abs(Named<Button>(toolbar,"StaffButton").TranslatePoint(new Point(),toolbar).Y-Named<Button>(toolbar,"FinishButton").TranslatePoint(new Point(),toolbar).Y)<1,"student controls remain in one row");
   Check(Named<CheckBox>(toolbar,"GuideToggle").IsChecked==false&&Named<CheckBox>(toolbar,"TintToggle").IsChecked==false,"approved visual supports start switched off");
   Check(!Named<Button>(toolbar,"FinishButton").IsEnabled&&Named<TextBlock>(toolbar,"StatusText").Text.Contains("Waiting for staff"),"preflight toolbar cannot finish or imply handoff readiness");
   fixtureSession.Status="Active";Invoke(toolbar,"Refresh");Pump();
   window.AuthorizeCurrentSession("Synthetic staff");
   var cached=typeof(MainWindow).GetMethod("SessionStaff",BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(window,new object[]{"Reuse current session"});
   Check((string?)cached=="Synthetic staff","current-session staff authorization reuses PIN grant");
   Invoke(window,"ClearSessionAuthorization");
   Check(typeof(MainWindow).GetField("_sessionStaff",BindingFlags.Instance|BindingFlags.NonPublic)!.GetValue(window) is null,"session authorization can be revoked without keeping PIN text");
   Check(Named<Button>(toolbar,"FinishButton").IsEnabled,"student Finish becomes enabled only for active session");
   window.Hide();Pump();
   Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>
   {
    var pinWindow=Application.Current.Windows.Cast<Window>().First(x=>x.Title=="Open staff controls");
    Check(!window.IsVisible,"staff screen remains hidden while PIN authorization is pending");pinWindow.Close();
   }));
   Named<Button>(toolbar,"StaffButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));Pump();
   Check(!window.IsVisible&&toolbar.IsVisible,"cancelled staff PIN returns to student without revealing staff screen");window.Show();Pump();
   var overlay=new VisualSupportWindow{Guide=true,Tint=true};nint beforeOverlay=NativeSupportChecks.Foreground;overlay.Show();overlay.UpdateBounds(new System.Windows.Interop.WindowInteropHelper(window).Handle);Pump();
   NativeSupportChecks.VerifyOverlay(overlay,Check,beforeOverlay);overlay.Close();
   bool focusActive=true;int overlaysShown=0;var pendingTarget=new TaskCompletionSource<nint>();
   using(var focus=new TestWindowFocusService(()=>pendingTarget.Task,()=>focusActive))
   {
    focus.ShowVisualSupports=_=>overlaysShown++;
    typeof(TestWindowFocusService).GetMethod("Tick",BindingFlags.NonPublic|BindingFlags.Instance)!.Invoke(focus,new object?[]{null,EventArgs.Empty});
    focus.SuspendForStaff();pendingTarget.SetResult(new System.Windows.Interop.WindowInteropHelper(window).Handle);Pump();
    Check(overlaysShown==0,"pending async focus lookup cannot re-cover a staff authorization dialog");
   }
   Task.Run(()=>NativeSupportChecks.VerifyOwnedBrowsers(root,Check)).GetAwaiter().GetResult();
   window.WindowState=WindowState.Minimized;Pump();Check(toolbar.IsVisible,"student controls survive minimizing staff window");window.WindowState=WindowState.Normal;
   fixtureSession.Status="AwaitingStaff";Invoke(window,"EnsureStudentControls");Pump();
   Check(!toolbar.IsVisible,"student controls close after student Finish rather than waiting for staff PIN");
   typeof(SessionService).GetProperty("Current")!.SetValue(sessions,null);
   var diag=new DiagnosticsWindow(){Owner=window};diag.Show();Pump();Check(diag.Title.Contains("read-only"),"in-app diagnostics opens without invoking a helper");diag.Close();
   var browserCheck=new BrowserPreflightWindow(){Owner=window};browserCheck.Show();Pump();
   var panel=(StackPanel)((ScrollViewer)browserCheck.Content).Content;
   Check(!panel.Children.OfType<Button>().First(x=>x.Name=="ApproveBrowserHandoffButton").IsEnabled,"browser handoff defaults blocked without evidence");
   Check(panel.Children.OfType<CheckBox>().Count()==4,"browser readiness presents all four live checks");
   Check(panel.Children.OfType<CheckBox>().All(x=>x.Content is TextBlock text&&text.TextWrapping==TextWrapping.Wrap),"browser check labels wrap on smaller screens");
   browserCheck.Close();
   var handoff=new AwaitingStaffWindow(){Owner=window};handoff.Show();Pump();handoff.Close();Check(handoff.IsVisible,"closing handoff without PIN is vetoed");
   // Exercise actual StaffDialogs PIN verification inside its modal dispatcher loop.
   Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>
   {
       var pinWindow=Application.Current.Windows.Cast<Window>().First(x=>x.Title=="Authorize finished-test handoff");
       IEnumerable<FrameworkElement> Walk(DependencyObject d){for(int i=0;i<VisualTreeHelper.GetChildrenCount(d);i++){var c=VisualTreeHelper.GetChild(d,i);if(c is FrameworkElement f)yield return f;foreach(var nested in Walk(c))yield return nested;}}
       var controls=Walk(pinWindow).ToList();controls.OfType<ComboBox>().First(x=>x.Name=="StaffAuthorizationChoice").SelectedIndex=0;
       controls.OfType<PasswordBox>().First(x=>x.Name=="StaffAuthorizationPin").Password="654321";
       controls.OfType<Button>().First(x=>x.Name=="StaffAuthorizeButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
   }));
   // A modal handoff's DialogResult cannot be set from a modeless Show; test the PIN
   // dialog separately, and permit fixture shutdown explicitly afterward.
   string? authorized=StaffDialogs.Authorize(handoff,settings,"Authorize finished-test handoff","Synthetic staff");
   Check(authorized=="Synthetic staff","real staff PIN authorizes handoff");handoff.AllowShutdown=true;handoff.Close();
   window.Close();app.Shutdown();
   Console.WriteLine($"ALL {_checks} NATIVE WPF CHECKS PASSED — synthetic data; no Word, machine-control or PIN action.");return 0;
  }
  catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
