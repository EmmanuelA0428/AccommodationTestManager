using System.IO;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;
using AccommodationTestManager.Services;
using AccommodationTestManager.Views;
static class NativeSupportChecks
{
 [DllImport("user32.dll")]private static extern nint GetForegroundWindow();
 [DllImport("user32.dll",EntryPoint="GetWindowLongPtrW")]private static extern nint GetStyle(nint window,int index);
 public static nint Foreground=>GetForegroundWindow();
 public static void VerifyOverlay(VisualSupportWindow overlay,Action<bool,string> check,nint before)
 {
  long styles=(long)GetStyle(new WindowInteropHelper(overlay).Handle,-20);
  check((styles&0x20)!=0&&(styles&0x8000000)!=0,"visual overlay has native click-through and no-activation styles");
  check(!overlay.IsHitTestVisible&&!overlay.Focusable&&!overlay.ShowActivated,"reading guide/tint never intercept student input or focus");
  check(GetForegroundWindow()==before,"showing the visual overlay does not take foreground focus");
  check(overlay.Width>1&&overlay.Height>1,"visual overlay tracks the intended test-window bounds");
 }
 public static async Task VerifyOwnedBrowsers(string root,Action<bool,string> check)
 {
  bool installed=new[]{Environment.SpecialFolder.ProgramFiles,Environment.SpecialFolder.ProgramFilesX86}.Any(f=>File.Exists(Path.Combine(Environment.GetFolderPath(f),"Microsoft","Edge","Application","msedge.exe")));
  if(!installed){Console.WriteLine("SKIP: actual Edge ownership smoke check — Edge not installed.");return;}
  var browser=new ExamBrowserService();string a=Path.Combine(root,"OwnedBrowserA"),b=Path.Combine(root,"OwnedBrowserB");
  try
  {
   await browser.OpenAsync(a,"about:blank");await browser.OpenAsync(b,"about:blank");
   check(browser.GetWindow(a)!=0&&browser.GetWindow(b)!=0,"native Edge roots are located by their exact separate profile arguments");
   await browser.CloseAsync(a);
   check(browser.GetWindow(a)==0&&browser.GetWindow(b)!=0,"closing one session-owned Edge leaves a different profile browser open");
   await browser.CloseAsync(b);check(browser.GetWindow(b)==0,"normal session browser close exits without a process kill");
  }
  finally{try{await browser.CloseAsync(a);}finally{await browser.CloseAsync(b);}}
 }
}
