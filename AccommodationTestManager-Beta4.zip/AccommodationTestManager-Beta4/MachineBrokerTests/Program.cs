using AccommodationTestManager.Services;
using System.IO.Pipes;
using System.Security.Principal;
using System.Runtime.InteropServices;

if (!OperatingSystem.IsWindows()) throw new Exception("Native Windows test required.");
using var identity=WindowsIdentity.GetCurrent();
if (new WindowsPrincipal(identity).IsInRole(WindowsBuiltInRole.Administrator)) throw new Exception("Regression must run as a genuine standard account.");
Console.WriteLine("PASS genuine non-administrator process");
if (args.Length!=1) throw new Exception("Synthetic PIN required.");
string pin=args[0];
async Task Reject(Func<Task> op,string expected)
{
 try { await op(); } catch(IOException e) when(e.Message.Contains(expected,StringComparison.Ordinal)) {Console.WriteLine("PASS "+expected);return;}
 throw new Exception("Expected rejection: "+expected);
}
// A local process owning a different pipe must not pass identity verification.
string spoof="ATM-Synthetic-Spoof-"+Guid.NewGuid().ToString("N");
using(var server=new NamedPipeServerStream(spoof,PipeDirection.InOut,1,PipeTransmissionMode.Byte,PipeOptions.Asynchronous))
using(var client=new NamedPipeClientStream(".",spoof,PipeDirection.InOut,PipeOptions.Asynchronous))
{
 var connected=server.WaitForConnectionAsync();await client.ConnectAsync(5000);await connected;
 bool denied=false;
 try{MachineServiceIdentity.Verify(client,MachineBrokerClient.Executable);}catch(IOException e)when(e.Message.Contains("Unexpected machine service owner")){denied=true;}
 if(!denied)throw new Exception("Spoof pipe accepted.");
 client.Dispose();byte[] buffer=new byte[1];using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(5));
 if(await server.ReadAsync(buffer,timeout.Token)!=0)throw new Exception("Credentials sent to spoof.");
 Console.WriteLine("PASS spoof pipe rejected without sending credentials");
}
await Reject(()=>MachineBrokerClient.Run("Unsupported",new string('a',32),null),"Enter the staff PIN again.");
await Reject(()=>MachineBrokerClient.CloseEdge("all"),"Enter the staff PIN again.");
await Reject(()=>MachineBrokerClient.Authenticate("000000"),"Incorrect machine-control PIN.");
await MachineBrokerClient.Authenticate(pin);
Console.WriteLine("PASS standard-account service identity verification and real broker PIN authentication");
await Reject(()=>MachineBrokerClient.CloseEdge("invalid"),"Invalid Edge close scope.");
// An authenticated grant must still not authorize arbitrary commands.
await Reject(()=>MachineBrokerClient.Run("Unsupported",new string('a',32),null),"Staff authorization required.");
Console.WriteLine("PASS no machine restrictions or test files modified");
