# CTL TestDesk — Release candidate 2

Windows 11 x64 accommodation testing app. Version **1.0.0-beta.4.6** keeps the established update channel and on-disk/service identities so existing installations can upgrade in place.

See `Setup/Docs/RELEASE-CTL-TestDesk-RC2.md` for the current change list and `Setup/Docs/START-HERE.txt` for staff instructions. Older beta documents in this archive are historical, not current setup instructions.

Routine test starts use the staff PIN with the installed, administrator-provisioned service. Administrative installation/recovery remains protected. Metadata/staff sync uses Firebase; test files and identifying test/student content remain local.

Initial completed/cancelled pilot records are archived from the current catalog using a fixed cutoff. Metadata, saved files and restoration snapshots are retained. Unfinished/recovery-required records remain visible. No public database access or file upload is introduced.

The installer remains unsigned. This is a release candidate, not an OS kiosk guarantee. Native Windows CI is required before publishing; a real-laptop Word/export/USB/network/Edge/offline-resync acceptance pass is still required before wider rollout.

## Development checks
- `dotnet run --project DeveloperTests/BetaTests.csproj`
- Firebase emulator suite in `CloudSync/` (rules plus two-client REST sync)
- Windows WPF harness `NativeUiTests/UiSmoke.csproj`
- Windows standard-user service/PIN harness `MachineBrokerTests/BrokerSmoke.csproj`
- Installer guards and mocked network/diagnostics tests in `Setup/` and `DeveloperTests/`

Internal names and legacy storage paths intentionally remain AccommodationTestManager for safe upgrades.

Beta 4.6 configures Edge background mode once during setup (with reversible policy receipts), prompts before force-closing another Windows session, opens test windows maximized rather than fullscreen, and closes Voice Access in the testing session after Finish. Real-laptop validation remains required.
