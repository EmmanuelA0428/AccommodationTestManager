using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
static class TestDeletionTests
{
 public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
 {
  var storage=new LocalStorageService(Path.Combine(root,"DeleteTests"));var q=new TestDeletionQueue(storage);string device=Guid.NewGuid().ToString("N");
  SessionEntry Make(string status){var id=Guid.NewGuid().ToString("N");var folder=storage.NewSessionFolder(id);var s=new TestSession{Id=id,DeviceId=device,Status=status,Mode="Word",CreatedUtc=DateTimeOffset.UtcNow,WorkingRelativePath="Exam.doc"};File.WriteAllText(Path.Combine(folder,"Exam.doc"),"synthetic answers");LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),s);folder=storage.MoveArea(folder,"Completed");return new(folder,s);}
  var entry=Make("Completed");
  await throws(()=>{q.DeleteLocal(entry,Guid.NewGuid().ToString("N"),false,"Restored");return Task.CompletedTask;},"another device cannot delete a local test");
  await throws(()=>{q.DeleteLocal(entry,device,true,"Restored");return Task.CompletedTask;},"busy session blocks test deletion");
  await throws(()=>{q.DeleteLocal(entry,device,false,"RestoreFailed");return Task.CompletedTask;},"unrestored machine state blocks deletion");
  var active=Make("Active");await throws(()=>{q.DeleteLocal(active,device,false,"Restored");return Task.CompletedTask;},"unfinished session cannot be deleted");
  check(File.Exists(Path.Combine(entry.Folder,"Exam.doc"))&&q.Ready(device).Count==0,"rejected deletions preserve files and queue");
  q.DeleteLocal(entry,device,false,"Restored");check(!Directory.Exists(entry.Folder),"confirmed owner deletion removes local session and files");
  var pending=q.Ready(device).Single();check(pending.SessionId==entry.Session.Id,"cloud deletion is durably queued after local deletion");
  check(new TestDeletionQueue(storage).Ready(device).Count==1,"cloud deletion queue survives restart");
  var activeCopy=Path.Combine(storage.Root,"Sessions","Active",pending.SessionId);Directory.CreateDirectory(activeCopy);
  check(q.HasPending&&q.Ready(device).Count==0,"a session in any lifecycle area blocks cloud deletion");
  await throws(()=>{q.Acknowledge(pending,device);return Task.CompletedTask;},"an active session blocks deletion acknowledgement");
  Directory.Delete(activeCopy);q.Acknowledge(pending,device);check(!q.HasPending&&q.Ready(device).Count==0,"successful cloud deletion acknowledgement clears queue");
 }
}
