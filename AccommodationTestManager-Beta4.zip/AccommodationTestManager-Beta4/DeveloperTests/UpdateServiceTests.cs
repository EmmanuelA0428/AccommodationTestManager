using AccommodationTestManager.Services;
using AccommodationTestManager.Models;
using System.Net;
using System.Security.Cryptography;
using System.Text.Json;

static class UpdateServiceTests
{
    private sealed class Handler(Func<HttpRequestMessage,CancellationToken,Task<HttpResponseMessage>> send):HttpMessageHandler
    {protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)=>send(request,token);}
    public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
    {
        var storage=new LocalStorageService(Path.Combine(root,"UpdaterRegression"));
        LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{RequireMachineRestrictions=false,DeviceId=Guid.NewGuid().ToString("N")});
        var settings=new SettingsService(storage);settings.Load();
        using var sessions=new SessionService(storage,settings,browser:new MockExamBrowser());var restrictions=new RestrictionService();
        byte[] bytes=Enumerable.Range(0,128).Select(i=>(byte)i).ToArray();string hash=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        string name="AccommodationTestManager-Setup-Beta4.7.exe",tag="v1.0.0-beta.4.7";
        string prefix="https://github.com/"+UpdatePolicy.Repository+"/releases/download/";
        object Release(string releaseTag,bool sums=true)=>new {draft=false,tag_name=releaseTag,assets=new[]{new {name, browser_download_url=prefix+releaseTag+"/"+name,size=(long)bytes.Length,digest="sha256:"+hash},new {name=sums?name+".sha256":"wrong.sha256",browser_download_url=prefix+releaseTag+"/"+name+".sha256",size=90L,digest=""}}};
        bool corrupt=false;int requests=0;
        using var updater=new UpdateService(storage,sessions,restrictions,new Handler((request,token)=>
        {
            requests++;var response=new HttpResponseMessage(HttpStatusCode.OK);
            if(request.RequestUri!.Host=="api.github.com")response.Content=new StringContent(JsonSerializer.Serialize(new[]{Release("v1.0.0-beta.2.99"),Release(tag),Release("v1.0.0-beta.5.1",false)}));
            else if(request.RequestUri.AbsolutePath.EndsWith(".sha256"))response.Content=new StringContent(hash+"  "+name);
            else response.Content=new ByteArrayContent(corrupt?new byte[bytes.Length]:bytes);
            return Task.FromResult(response);
        }));
        var update=await updater.CheckAsync();check(update?.Version==tag,"updater selects future beta across generations and skips missing checksum");
        restrictions.States[Guid.NewGuid().ToString("N")]="Applied";
        string downloaded=await updater.DownloadAsync(update!);
        check(File.ReadAllBytes(downloaded).SequenceEqual(bytes),"verified download works while machine installation gate remains blocked");
        check(File.Exists(downloaded+":Zone.Identifier"),"download retains internet origin marker");
        await throws(()=>{updater.AssertCanInstall();return Task.CompletedTask;},"download does not bypass install safety gate");
        await throws(()=>{updater.Launch(downloaded,update!);return Task.CompletedTask;},"pending controls block launch before execution");
        restrictions.States.Clear();restrictions.LegacyReviewRequired=true;
        await throws(()=>{updater.AssertCanInstall();return Task.CompletedTask;},"legacy review gate blocks installation even with no pending snapshot");
        restrictions.LegacyReviewRequired=false;File.WriteAllBytes(downloaded,new byte[bytes.Length]);
        await throws(()=>{updater.Launch(downloaded,update!);return Task.CompletedTask;},"installer mutation is detected without launching anything");
        corrupt=true;await throws(()=>updater.DownloadAsync(update!),"checksum mismatch rejects download");
        check(!Directory.GetFiles(Path.Combine(storage.Root,"Updates"),"*.partial",SearchOption.AllDirectories).Any(),"failed download leaves no partial installer");
        using var slow=new UpdateService(storage,sessions,restrictions,new Handler(async(_,token)=>{await Task.Delay(10000,token);return new HttpResponseMessage(HttpStatusCode.OK);}));
        using var timeout=new CancellationTokenSource(TimeSpan.FromMilliseconds(50));
        await throws(()=>slow.CheckAsync(timeout.Token),"startup metadata check respects cancellation budget");
        check(requests==5,"network regressions used controlled responses only");
    }
}
