using System;
using AccommodationTestManager.Services;

public static class WordWindowPresentationTests
{
    public static void Run(Action<bool,string> check)
    {
        // These fakes deliberately expose only the Word-shaped members used here.
        // Application has no DisplayFullScreen member: reintroducing that error fails.
        var app = new FakeWordApplication();
        var doc = new FakeWordDocument();
        WordWindowPresentation.ShowNormalMaximized(app, doc);
        check(app.Visible, "Word presentation makes application visible");
        check(doc.ActivatedBeforeWindowAccess, "Word document activated before window state change");
        check(!doc.Window.View.FullScreen, "Word View.FullScreen switched off");
        check(doc.Window.WindowState == 1, "Word document window maximized normally");
    }
}
public sealed class FakeWordApplication { public bool Visible { get; set; } }
public sealed class FakeWordDocument
{
    private bool _activated;
    public bool ActivatedBeforeWindowAccess { get; private set; }
    public FakeWordWindow Window { get; } = new();
    public FakeWordWindow ActiveWindow { get { ActivatedBeforeWindowAccess = _activated; if (!_activated) throw new InvalidOperationException("Window is not active"); return Window; } }
    public void Activate() => _activated = true;
}
public sealed class FakeWordWindow { public FakeWordView View { get; } = new(); public int WindowState { get; set; } }
public sealed class FakeWordView { public bool FullScreen { get; set; } = true; }
