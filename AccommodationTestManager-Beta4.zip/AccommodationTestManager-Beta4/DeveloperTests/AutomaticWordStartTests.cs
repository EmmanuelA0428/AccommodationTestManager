using AccommodationTestManager.Models;
using AccommodationTestManager.Services;

static class AutomaticWordStartTests
{
 public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
 {
  var storage=new LocalStorageService(Path.Combine(root,"AutomaticWord"));
  LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),RequireMachineRestrictions=true,ManualPreflightChecks=false});
  var settings=new SettingsService(storage);settings.Load();settings.Register("Synthetic laptop","FAKE",["Synthetic staff"],"654321");
  string source=Path.Combine(root,"AutoSource.doc");await File.WriteAllTextAsync(source,"Synthetic automatic-start fixture; not a real Word document.");string hash=LocalStorageService.HashFile(source);
  var draft=new TestSetupDraft{StaffName="Synthetic staff",StudentName="Synthetic",TestName="Automatic lifecycle",Preset="Word",DocumentPath=source,UseTimeLimit=true,DurationText="10"};
  var helper=new RestrictionService();
  using(var service=new SessionService(storage,settings,null,helper,browser:new MockExamBrowser()))
  {
   service.ConfirmRemoveStorage=()=>Task.FromResult(true);await service.StartAsync(draft);
   check(service.Current!.Status=="Active"&&service.Current.AutomaticStartupVerifiedUtc is not null,"automatic Word start activates without manual preflight");
   check(helper.StartupVerificationCount==1,"automatic start performs live-check hook exactly once");
   check(service.Current.StartedUtc is not null&&service.Current.DeadlineUtc>service.Current.AutomaticStartupVerifiedUtc,"timer begins only after successful automatic startup");
   check(service.Current.Events.Any(e=>e.Action=="Automatic Word startup verified")&&!service.Current.Events.Any(e=>e.Action=="Staff preflight confirmed"),"automatic checks do not fabricate staff live attestation");
   await service.FinishAsync();double remaining=service.Current!.RemainingSeconds!.Value;await service.ResumeAsync("Synthetic staff");
   check(service.Current!.Status=="Active"&&helper.StartupVerificationCount==2,"automatic resume re-verifies controls before activation");
   check(Math.Abs((service.Current.DeadlineUtc!.Value-DateTimeOffset.UtcNow).TotalSeconds-remaining)<2,"resume retains remaining time rather than resetting duration");
   await service.FinishAsync();await service.PrepareFinalAsync("Synthetic staff");await service.ExportAsync(Path.Combine(root,"AutoFinal.doc"),"Synthetic staff");await service.CompleteAsync("Synthetic staff");
   check(service.Current is null&&helper.States.Values.All(s=>s=="Restored"),"automatic lifecycle completes with recorded controls restored");
  }
  var broken=new RestrictionService{FailStartupVerification=true};
  using(var service=new SessionService(storage,settings,null,broken,browser:new MockExamBrowser()))
  {
   service.ConfirmRemoveStorage=()=>Task.FromResult(true);await throws(()=>service.StartAsync(draft),"automatic live-check failure blocks handoff");
   check(service.Current?.Status=="Preflight"&&service.Current.StartedUtc is null&&service.Current.DeadlineUtc is null,"failed startup has no active state or running deadline");
   string working=storage.FileInSession(service.Folder!,service.Current!.WorkingRelativePath);
   check(File.Exists(working)&&LocalStorageService.HashFile(working)==hash&&broken.Status(service.Current.Id)=="Applied","failed checks retain work and unresolved snapshot for restoration");
   await throws(()=>service.FinishAsync(),"student cannot finish an unverified automatic startup");
   await throws(()=>service.ConfirmPreflightAsync("Synthetic staff"),"manual confirmation cannot bypass failed automatic checks");
   await service.CancelPreparationAsync("Synthetic staff");
   check(service.Current is null&&broken.States.Values.All(s=>s=="Restored")&&storage.ListSessions().Any(e=>e.Session.Status=="Cancelled"&&Directory.Exists(e.Folder)),"cancel failed startup restores controls and archives evidence");
  }
  var retry=new RestrictionService{FailStartupVerification=true};
  using(var service=new SessionService(storage,settings,null,retry,browser:new MockExamBrowser()))
  {
   service.ConfirmRemoveStorage=()=>Task.FromResult(true);await throws(()=>service.StartAsync(draft),"retry fixture starts blocked");retry.FailStartupVerification=false;
   await service.ResumeAsync("Synthetic staff");check(service.Current?.Status=="Active"&&service.Current.StartedUtc is not null,"resolved startup can resume through fresh verification");
   // Force a resume check failure from an already timed active session.
   retry.FailStartupVerification=true;await throws(()=>service.ResumeAsync("Synthetic staff"),"resume verification failure pauses active session");
   check(service.Current?.Status=="Preflight"&&service.Current.DeadlineUtc is null&&service.Current.RemainingSeconds>0,"failed resume preserves remaining time and clears active deadline");
   await service.CancelPreparationAsync("Synthetic staff");
  }
  using(var service=new SessionService(storage,settings,null,new RestrictionService(),browser:new MockExamBrowser()))
  {
   draft.Preset="Canvas";await throws(()=>service.StartAsync(draft),"automatic browser start refuses unsupported effective-policy verification");
   check(service.Current is null&&storage.ListSessions(true).Count==0,"unsupported automatic mode creates no session or pending work");
  }
  draft.Preset="Word";var restartHelper=new RestrictionService();string restartId;
  using(var first=new SessionService(storage,settings,null,restartHelper,browser:new MockExamBrowser()))
  {first.ConfirmRemoveStorage=()=>Task.FromResult(true);await first.StartAsync(draft);restartId=first.Current!.Id;}
  var interrupted=storage.ListSessions(true).Single();
  using(var second=new SessionService(storage,settings,null,restartHelper,browser:new MockExamBrowser()))
  {
   second.ConfirmRemoveStorage=()=>Task.FromResult(true);await second.AdoptAsync(interrupted,"Synthetic staff");await second.ResumeAsync("Synthetic staff");
   check(second.Current!.Id==restartId&&second.Current.Status=="Active"&&restartHelper.StartupVerificationCount==2,"restart recovery reuses the same session and freshly verifies startup");
   check(LocalStorageService.HashFile(storage.FileInSession(second.Folder!,second.Current.WorkingRelativePath))==hash,"restart recovery preserves working file bytes");
   await second.FinishAsync();await second.PrepareFinalAsync("Synthetic staff");await second.ExportAsync(Path.Combine(root,"RestartFinal.doc"),"Synthetic staff");await second.CompleteAsync("Synthetic staff");
   check(second.Current is null&&restartHelper.Status(restartId)=="Restored","restart recovery can finish/export/restore successfully");
  }
  WordStartReadiness.VerifyDocument(new(source,false,false),source);check(true,"intended saved writable document passes readiness");
  await throws(()=>{WordStartReadiness.VerifyDocument(new(source,true,false),source);return Task.CompletedTask;},"read-only document blocks automatic handoff");
  await throws(()=>{WordStartReadiness.VerifyDocument(new(source,false,true),source);return Task.CompletedTask;},"unsaved changes block automatic handoff");
  await throws(()=>{WordStartReadiness.VerifyDocument(new(Path.Combine(root,"Other.doc"),false,false),source);return Task.CompletedTask;},"wrong Word document blocks automatic handoff");
  check(LocalStorageService.HashFile(source)==hash,"automatic success/failure/resume/cancel never changes original import");
 }
}
