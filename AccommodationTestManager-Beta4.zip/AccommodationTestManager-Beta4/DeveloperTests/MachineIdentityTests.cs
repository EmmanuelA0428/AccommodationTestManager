using AccommodationTestManager.Services;
static class MachineIdentityTests
{
 public static void Run(Action<bool,string> check)
 {
  string exe=Path.GetFullPath(Path.Combine(Path.GetTempPath(),"ProtectedInstall","AtmMachineBroker.exe"));
  void Valid(uint state=4,uint statusType=16,uint configType=16,uint servicePid=123,uint pipePid=123,string? path=null,string account="LocalSystem")=>MachineServiceIdentity.Validate(state,statusType,configType,servicePid,pipePid,path??'"'+exe+'"',account,exe);
  void Reject(Action op,string message){bool rejected=false;try{op();}catch(IOException){rejected=true;}check(rejected,message);}
  Valid();check(true,"SCM identity accepts installed running SYSTEM own-process service");
  Valid(path:exe);check(true,"SCM identity accepts exact unquoted executable");
  Reject(()=>Valid(state:1),"stopped service rejected");
  Reject(()=>Valid(servicePid:0,pipePid:0),"zero PID rejected");
  Reject(()=>Valid(pipePid:124),"spoofed pipe owner rejected before credentials");
  Reject(()=>Valid(statusType:32),"shared-process service status rejected");
  Reject(()=>Valid(configType:32),"shared-process service config rejected");
  Reject(()=>Valid(account:@"NT AUTHORITY\LocalService"),"non-SYSTEM service rejected");
  Reject(()=>Valid(path:exe+".evil"),"lookalike executable rejected");
  Reject(()=>Valid(path:'"'+exe+'"'+" --argument"),"service command arguments rejected");
  Reject(()=>Valid(path:"AtmMachineBroker.exe"),"relative service path rejected");
  Reject(()=>Valid(path:'"'+exe+" --argument"+'"'),"quoted wrapper command rejected");
 }
}
