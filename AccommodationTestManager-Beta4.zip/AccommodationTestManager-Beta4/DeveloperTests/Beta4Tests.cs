using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
static class Beta4Tests
{
 public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
 {
  var storage=new LocalStorageService(Path.Combine(root,"Beta4"));
  LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),RequireMachineRestrictions=true,ManualPreflightChecks=true});
  var settings=new SettingsService(storage);settings.Load();settings.Register("CTLgreen","FAKE",["Staff A"],"654321");
  string source=Path.Combine(root,"Beta4-source.doc");await File.WriteAllTextAsync(source,"Synthetic saved local work");string hash=LocalStorageService.HashFile(source);
  var draft=new TestSetupDraft{StaffName="Staff A",StudentName="Synthetic",TestName="Beta4 lifecycle",Preset="Word",DocumentPath=source};
  var helper=new RestrictionService();
  using(var service=new SessionService(storage,settings,null,helper,browser:new MockExamBrowser()){AutomaticHandoff=true}){
   service.ConfirmRemoveStorage=()=>Task.FromResult(true);await service.StartAsync(draft);
   check(service.Current?.Status=="Active"&&!service.Current.SettingsSnapshot.ManualPreflightChecks,"production start bypasses manual developer preflight only after automatic checks");
   var entry=new SessionEntry(service.Folder!,service.Current!);string working=storage.FileInSession(entry.Folder,entry.Session.WorkingRelativePath);
   helper.FailRestore=true;await throws(()=>service.CancelStoredAsync(entry,"Staff A",true),"direct cancellation reports restore failure");
   check(service.Current!.CancellationRequested&&service.Current.Status=="RecoveryRequired"&&service.Current.DeadlineUtc is null,"failed cancel persists restoration-needed state and stops deadline");
   check(File.Exists(working)&&LocalStorageService.HashFile(working)==hash,"cancel failure preserves saved work");
   await throws(()=>service.ResumeAsync("Staff A"),"pending cancellation cannot reopen the test");
   helper.FailRestore=false;await service.CancelStoredAsync(entry,"Staff A",true);
   check(service.Current is null&&helper.States.Values.All(x=>x=="Restored"),"cancel retry restores controls and releases current session");
   var cancelled=storage.ListSessions().Single();check(cancelled.Session.Status=="Cancelled"&&File.Exists(storage.FileInSession(cancelled.Folder,cancelled.Session.WorkingRelativePath)),"cancel archives saved work without deleting it");
   check(string.IsNullOrEmpty(cancelled.Session.FinalRelativePath),"cancel does not invent a final submission receipt");
  }
  // Recovery cancellation never invokes Resume/Open; it operates on the stored record.
  string folder=storage.NewSessionFolder(Guid.NewGuid().ToString("N"));
  var saved=new TestSession{Id=Path.GetFileName(folder),DeviceId=settings.Current.DeviceId,LaptopName="CTLgreen",Mode="Word",Status="RecoveryRequired",TestName="Stored cancel"};
  LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),saved);
  using(var recovery=new SessionService(storage,settings,null,helper,browser:new MockExamBrowser())){
   await throws(()=>recovery.CancelStoredAsync(new(folder,saved),"Staff A",false),"stored cancellation requires confirmation");
   check(recovery.Current is null,"unconfirmed cancellation leaves recovery record untouched");
   await recovery.CancelStoredAsync(new(folder,saved),"Staff A",true);
   check(recovery.Current is null&&storage.ListSessions().Any(x=>x.Session.Id==saved.Id&&x.Session.Status=="Cancelled"),"stored test cancels without opening Word");
  }
  var roster=new SharedStaffStore(storage,settings);var initial=settings.Current.StaffMembers.Single();
  roster.SeedIfNeeded([]);check(roster.PendingCount==1,"initial staff publication is queued durably");
  var pending=roster.State.Pending[initial.Id];roster.Acknowledge(initial.Id,"wrong-operation");check(roster.PendingCount==1,"stale acknowledgement cannot clear a newer staff edit");
  roster.Acknowledge(initial.Id,pending.Data.Operation);roster.Store([new(initial.Id,initial.Name,true,pending.Data.Operation,"version1")],true);
  var next=LocalStorageService.Clone(settings.Current);var added=new StaffMember{Name="Staff B"};next.StaffMembers.Add(added);settings.Update(next);
  check(roster.PendingCount==1&&roster.State.Pending.ContainsKey(added.Id),"adding staff queues global update");
  var restarted=new SharedStaffStore(storage,settings);check(restarted.State.Pending.ContainsKey(added.Id),"offline staff addition survives store restart");
  var operation=restarted.State.Pending[added.Id].Data.Operation;restarted.Acknowledge(added.Id,operation);
  var remote=new List<SharedStaff>{new(initial.Id,initial.Name,true,pending.Data.Operation,"version1"),new(added.Id,"Staff B renamed",true,Guid.NewGuid().ToString("N"),"version2")};
  restarted.Store(remote,false);check(settings.Current.StaffNames.Contains("Staff B")&&!settings.Current.StaffNames.Contains("Staff B renamed")&&restarted.NeedsApply,"remote roster changes wait during an active test");
  restarted.ApplyPending();check(settings.Current.StaffNames.Contains("Staff B renamed")&&!restarted.NeedsApply,"latest roster activates when idle");
  await throws(()=>{restarted.Store(remote.Select(x=>x with{Active=false}).ToList(),true);return Task.CompletedTask;},"all-inactive shared roster is rejected");
  await throws(()=>{SharedStaffStore.Validate(added.Id,"Staff\nInjected");return Task.CompletedTask;},"staff control characters rejected before cloud upload");
  var serialized=System.Text.Json.JsonSerializer.Serialize(restarted.State);check(!serialized.Contains("654321")&&!serialized.Contains(settings.Current.StaffPinHash),"staff sync state contains neither PIN nor local PIN hash");
 }
}
