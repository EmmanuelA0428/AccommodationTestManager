using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using System.Text.Json;
static class VisualSupportsAndBrowserTests
{
 public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
 {
  string profile=Path.Combine(root,"GuidProfile"),other=profile+"Other";
  bool Match(params string[] args)=>ExamBrowserService.MatchesProfile(args,profile);
  check(Match("msedge.exe","--user-data-dir="+profile),"browser ownership accepts exact session profile");
  check(Match("msedge.exe","--user-data-dir",profile),"browser ownership accepts split exact-profile argument");
  check(!Match("msedge.exe","--user-data-dir="+other),"browser ownership rejects similarly prefixed profile");
  check(!Match("msedge.exe","--user-data-dir="+profile,"--type=renderer"),"renderer cannot impersonate browser root");
  check(!Match("msedge.exe","--user-data-dir="+profile,"--type","gpu-process"),"split child-process type cannot impersonate root");
  check(!Match("msedge.exe","--user-data-dir="+profile,"--user-data-dir="+other),"duplicate profile switches fail closed");
  check(!Match("msedge.exe","--user-data-dir="+profile,"--user-data-dir"),"dangling duplicate profile switch fails closed");
  check(!Match("msedge.exe","--user-data-dir=relative"),"relative browser profile is rejected");
  check(!Match("msedge.exe","--user-data-dir"),"missing browser profile argument is rejected");
  check(!Match("msedge.exe",profile),"profile text alone is not ownership proof");
  check(!Match("msedge.exe","--user-data-dir="+Path.Combine(profile,"..","Other")),"different normalized profile cannot match");
  var defaults=new TestSetupDraft();check(!defaults.ReadingGuide&&!defaults.ScreenTint&&!defaults.LargeControls,"extra supports are opt-in by default");
  var changed=new List<string>();defaults.PropertyChanged+=(_,e)=>changed.Add(e.PropertyName!);defaults.ReadingGuide=true;defaults.ScreenTint=true;defaults.LargeControls=true;
  check(changed.SequenceEqual(new[]{"ReadingGuide","ScreenTint","LargeControls"}),"support switches notify setup review bindings");
  var storage=new LocalStorageService(Path.Combine(root,"SupportsLifecycle"));
  LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),RequireMachineRestrictions=false,CanvasUrl="https://canvas.hws.edu/"});
  var settings=new SettingsService(storage);settings.Load();settings.Register("Synthetic laptop","FAKE",["Staff"],"654321");
  string source=Path.Combine(root,"SupportSource.doc");File.WriteAllText(source,"Synthetic fixture; not a Word document");
  var lists=new AllowlistService(storage);lists.Initialize();var browser=new MockExamBrowser();using var service=new SessionService(storage,settings,lists,browser:browser);
  var draft=new TestSetupDraft{StaffName="Staff",StudentName="Synthetic",TestName="Supports",DocumentPath=source,Preset="Word",ReadingGuide=true,ScreenTint=true,LargeControls=true};
  await service.StartAsync(draft);var s=service.Current!;
  check(s.ReadingGuide&&s.ScreenTint&&s.LargeControls,"start copies selected supports into durable session");
  string cloud=JsonSerializer.Serialize(MetadataOutbox.Project(storage,new(service.Folder!,s),settings.Current.DeviceId));
  check(!cloud.Contains("ReadingGuide")&&!cloud.Contains("ScreenTint")&&!cloud.Contains("LargeControls"),"accommodation choices stay local and are not uploaded to Firebase");
  var copy=LocalStorageService.ReadJson<TestSession>(Path.Combine(service.Folder!,"session.json"));
  check(copy.ReadingGuide&&copy.ScreenTint&&copy.LargeControls,"support selection survives metadata reload");
  var legacy=JsonSerializer.Deserialize<TestSession>("{\"Mode\":\"Word\"}")!;
  check(!legacy.ReadingGuide&&!legacy.ScreenTint&&!legacy.LargeControls,"old sessions load with extra supports disabled");
  await service.FinishAsync();await service.PrepareFinalAsync("Staff");await service.ExportAsync(Path.Combine(root,"SupportsFinal.doc"),"Staff");await service.CompleteAsync("Staff");
  draft.Preset="Canvas";draft.ReadingGuide=false;draft.ScreenTint=false;draft.LargeControls=false;
  await service.StartAsync(draft);check(browser.Opens==1,"online startup goes through owned-profile browser service");
  check(!service.Current!.ReadingGuide&&!service.Current.ScreenTint&&!service.Current.LargeControls,"new test does not inherit previous support choices implicitly");
  await throws(()=>service.CancelOnlineTestAsync("Staff",false),"online abandonment requires explicit confirmation");
  browser.FailClose=true;await throws(()=>service.CancelOnlineTestAsync("Staff",true),"online cancel stops when browser refuses normal close");
  check(service.Current.Status=="Active"&&Directory.Exists(service.Folder),"failed browser close preserves active local session and files");
  browser.FailClose=false;await service.CancelOnlineTestAsync("Staff",true);
  var cancelled=storage.ListSessions().Single(e=>e.Session.Mode=="Canvas");
  check(service.Current is null&&cancelled.Session.Status=="Cancelled"&&!cancelled.Session.SubmissionVerifiedByStaff,"cancel archives test without inventing a submission receipt");
  check(cancelled.Session.Events.Any(e=>e.Action=="Online test abandoned"),"abandonment remains explicit in local audit history");
  await service.StartAsync(draft);await service.FinishAsync();browser.FailClose=true;
  await throws(()=>service.CompleteAsync("Staff",true),"online completion stops when browser refuses normal close");
  check(service.Current?.Status=="AwaitingStaff"&&!service.Current.SubmissionVerifiedByStaff,"failed completion does not record successful submission/completion");
  browser.FailClose=false;await service.CompleteAsync("Staff",true);
  check(service.Current is null&&storage.ListSessions().Any(e=>e.Session.Mode=="Canvas"&&e.Session.Status=="Completed"),"retry normal browser close can complete verified online test");
  var protectedStore=new LocalStorageService(Path.Combine(root,"BrowserRestoreOrdering"));
  LocalStorageService.WriteJson(protectedStore.SettingsPath,settings.Current);var protectedSettings=new SettingsService(protectedStore);protectedSettings.Load();
  string id=Guid.NewGuid().ToString("N"),folder=protectedStore.NewSessionFolder(id);
  var active=new TestSession{Id=id,DeviceId=settings.Current.DeviceId,Mode="Canvas",Status="Active",RestrictionsApplied=true,CreatedUtc=DateTimeOffset.UtcNow,SettingsSnapshot=LocalStorageService.Clone(settings.Current)};
  LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),active);folder=protectedStore.MoveArea(folder,"Active");
  var helper=new RestrictionService();helper.States[id]="Applied";var owned=new MockExamBrowser{FailClose=true};
  using var ordered=new SessionService(protectedStore,protectedSettings,restrictions:helper,browser:owned);await ordered.AdoptAsync(new(folder,active),"Staff");
  await throws(()=>ordered.CancelOnlineTestAsync("Staff",true),"browser failure blocks machine restoration during online cancel");
  check(helper.Status(id)=="Applied"&&ordered.Current?.Status=="Active","blocked browser closure leaves controls and recovery record intact");
  owned.FailClose=false;helper.FailRestore=true;await throws(()=>ordered.CancelOnlineTestAsync("Staff",true),"machine restore failure blocks cancellation receipt");
  check(ordered.Current?.Status=="Active"&&Directory.Exists(ordered.Folder),"restore failure preserves unfinished session for retry");
  helper.FailRestore=false;await ordered.CancelOnlineTestAsync("Staff",true);var archive=protectedStore.ListSessions().Single();
  check(helper.Status(id)=="Restored"&&archive.Session.RestrictionsRestored&&archive.Session.Status=="Cancelled","retry closes browser, restores controls and only then archives cancellation");
 }
}
