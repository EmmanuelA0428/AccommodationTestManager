using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
static class ReleasePolishTests
{
 public static void Run(string root,Action<bool,string> check)
 {
  var draft=new TestSetupDraft();check(draft.TextToSpeech&&draft.SpeechToText&&!draft.ReadingGuide&&!draft.ScreenTint&&!draft.UseTimeLimit,"new tests default to speech supports only, without timer");
  var cut=PilotRecordPolicy.Cutoff;var old=cut.AddDays(-1);
  check(PilotRecordPolicy.IsArchived(old,old.AddMinutes(60),"Completed"),"completed initial pilot record is archived from current catalog");
  check(PilotRecordPolicy.IsArchived(old,old.AddMinutes(60),"Cancelled"),"restored cancelled pilot record is archived");
  foreach(var status in new[]{"Active","AwaitingStaff","RecoveryRequired","NeedsReview","Completing","ExportPending","Preflight","Preparing"})check(!PilotRecordPolicy.IsArchived(old,old.AddMinutes(60),status),"unfinished "+status+" never hidden by pilot cleanup");
  check(!PilotRecordPolicy.IsArchived(old,null,"Completed"),"missing completion receipt remains visible");
  check(!PilotRecordPolicy.IsArchived(old,cut.AddMinutes(1),"Completed"),"old unfinished test resolved after boundary remains visible");
  check(!PilotRecordPolicy.IsArchived(cut,cut.AddMinutes(1),"Completed"),"future real tests do not disappear on next launch");
  var storage=new LocalStorageService(Path.Combine(root,"ReleaseRoster"));LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N")});
  var settings=new SettingsService(storage);settings.Load();settings.Register("CTLgreen","FAKE",["Jen Johnson","Existing staff"],"654321");
  var store=new SharedStaffStore(storage,settings);var remote=settings.Current.StaffMembers.Select(x=>new SharedStaff(x.Id,x.Name,x.Active,Guid.NewGuid().ToString("N"),"v1")).ToList();store.Store(remote,true);store.PrepareReleaseRoster(remote);
  check(store.PendingCount==7,"six staff additions and Jen deactivation queue globally");
  check(store.State.Pending.Values.Single(x=>x.Data.Name=="Jen Johnson").Data.Active==false,"test staff deactivates rather than deleting historical identity");
  check(store.State.Pending.Values.Where(x=>x.Data.Name!="Jen Johnson").All(x=>SharedStaffStore.ReleaseRoster.Contains(x.Data.Name)&&x.Data.Active),"release staff names retain exact requested spelling");
  check(!store.State.Pending.ContainsKey(remote.Single(x=>x.Name=="Existing staff").Id),"unrelated staff records are preserved");
  var published=remote.Where(x=>x.Name!="Jen Johnson").Concat(store.State.Pending.Values.Select(x=>x.Data with{Version="v2"})).ToList();
  foreach(var p in store.State.Pending.ToArray())store.Acknowledge(p.Key,p.Value.Data.Operation);store.Store(published,true);
  check(SharedStaffStore.ReleaseRoster.All(settings.Current.StaffNames.Contains)&&!settings.Current.StaffNames.Contains("Jen Johnson"),"published release roster activates locally");
  store=new SharedStaffStore(storage,settings);store.PrepareReleaseRoster(published);check(store.PendingCount==0,"roster policy is one-time across restarts");
  var folder=storage.NewSessionFolder(Guid.NewGuid().ToString("N"));var file=Path.Combine(folder,"saved.docx");File.WriteAllText(file,"saved test");var session=new TestSession{Id=Path.GetFileName(folder),CreatedUtc=old,CompletedUtc=old.AddHours(1),Status="Completed"};LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),session);
  check(storage.ListSessions().Count==1&&File.Exists(file),"pilot catalog filtering never deletes underlying metadata or saved documents");
 }
}
