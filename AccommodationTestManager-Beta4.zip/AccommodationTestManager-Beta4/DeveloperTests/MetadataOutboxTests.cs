using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using System.Text.Json;

static class MetadataOutboxTests
{
 public static async Task Run(string root, Action<bool,string> check, Func<Func<Task>,string,Task> throws)
 {
  var storage = new LocalStorageService(Path.Combine(root,"Metadata"));
  string device=Guid.NewGuid().ToString("N"), id=Guid.NewGuid().ToString("N");
  string folder=storage.NewSessionFolder(id);string file=Path.Combine(folder,"working.docx");await File.WriteAllTextAsync(file,"SECRET_ANSWERS");
  var session=new TestSession {Id=id,DeviceId=device,LaptopName="PRIVATE_LAPTOP",StudentName="SECRET_STUDENT",TestName="SECRET_TEST",StartedBy="SECRET_STAFF",SourcePath="SECRET_PATH",ExportPath="SECRET_EXPORT",WebUrl="https://example.org/?SECRET_TOKEN",Mode="Word",Status="Active",CreatedUtc=DateTimeOffset.UtcNow,WorkingRelativePath="working.docx",SettingsSnapshot=new AppSettings{StaffPinHash="SECRET_PIN",StaffPinSalt="SECRET_SALT"}};
  session.Events.Add(new("SECRET_EVENT",DateTimeOffset.UtcNow,"SECRET_ACTION","SECRET_STAFF","SECRET_DETAILS"));
  var data=MetadataOutbox.Project(storage,new(folder,session),device);string json=JsonSerializer.Serialize(data);
  check(!json.Contains("SECRET_")&&!json.Contains("PRIVATE_")&&!json.Contains("working.docx"),"metadata projection excludes student/staff/test names, file paths, answers, URLs, PINs, and events");
  check(data.SessionId==id&&data.DeviceId==device&&data.RecoveryReportedAvailable,"anonymous metadata retains identifiers and local-availability report");
  var queue=new MetadataOutbox(storage);check(queue.Enqueue(data)&&queue.Pending().Count==1,"first metadata update persists to local queue");
  check(!queue.Enqueue(data)&&queue.Pending().Single().Revision==1,"unchanged metadata does not repeatedly enqueue");
  var first=queue.Pending().Single();var updated=data with {Status="Cancelled",EndedUtc=DateTimeOffset.UtcNow};queue.Enqueue(updated);
  check(queue.Pending().Count==1&&queue.Pending().Single().Revision==2,"new status coalesces into a newer pending revision");
  check(!queue.Acknowledge(id,first.Revision,first.Fingerprint)&&queue.Pending().Count==1,"old in-flight acknowledgement cannot discard newer queued state");
  queue=new MetadataOutbox(storage);check(queue.Pending().Single().Data.Status=="Cancelled","pending metadata survives app restart");
  var second=queue.Pending().Single();check(!queue.Acknowledge(id,second.Revision,"wrong"),"mismatched fingerprint acknowledgement is rejected");
  check(queue.Acknowledge(id,second.Revision,second.Fingerprint)&&queue.Pending().Count==0,"matching acknowledged upload clears only its pending revision");
  queue=new MetadataOutbox(storage);check(!queue.Enqueue(updated)&&queue.Pending().Count==0,"acknowledged unchanged session remains deduplicated after restart");
  queue.Enqueue(updated with{Status="Completed"});check(queue.Pending().Single().Revision==3,"revision survives acknowledged-queue restart");
  await throws(()=>{MetadataOutbox.Project(storage,new(folder,session),Guid.NewGuid().ToString("N"));return Task.CompletedTask;},"foreign device record cannot be reassigned to this laptop");
  session.WorkingRelativePath="../escape.docx";
  await throws(()=>{MetadataOutbox.Project(storage,new(folder,session),device);return Task.CompletedTask;},"metadata availability check rejects traversing local path");
  await throws(()=>{queue.Enqueue(data with{Status="SECRET_ARBITRARY_TEXT"});return Task.CompletedTask;},"metadata rejects arbitrary status text");
  await throws(()=>{queue.Enqueue(data with{Mode="SECRET_ARBITRARY_MODE"});return Task.CompletedTask;},"metadata rejects arbitrary mode text");
  await throws(()=>{queue.Enqueue(data with{SessionId="student-name"});return Task.CompletedTask;},"metadata rejects identifying free-text session IDs");
  string path=Path.Combine(storage.Root,"CloudSync","metadata-outbox.json");string before=File.ReadAllText(path);
  await File.WriteAllTextAsync(path,"{ damaged queue");await throws(()=>{_ = new MetadataOutbox(storage);return Task.CompletedTask;},"corrupt queue is not silently reset");
  check(File.ReadAllText(path)=="{ damaged queue","corrupt queue remains intact for review");
  await File.WriteAllTextAsync(path,before);var state=LocalStorageService.ReadJson<MetadataQueueState>(path);state.Pending[id]=state.Pending[id] with {Revision=99};LocalStorageService.WriteJson(path,state);
  await throws(()=>{_ = new MetadataOutbox(storage);return Task.CompletedTask;},"inconsistent queue revision fails closed without changing session data");
  check(File.ReadAllText(file)=="SECRET_ANSWERS","queue operations do not alter test document bytes");
 }
}
