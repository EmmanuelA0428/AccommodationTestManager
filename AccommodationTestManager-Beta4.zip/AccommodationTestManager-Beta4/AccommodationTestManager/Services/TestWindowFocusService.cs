using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Threading;
namespace AccommodationTestManager.Services;
// Convenience focus management, never a Windows security boundary. No hooks, injected keys or process termination.
public sealed class TestWindowFocusService : IDisposable
{
 private readonly Func<Task<nint>> _target;private readonly Func<bool> _active;
 private readonly DispatcherTimer _timer=new(){Interval=TimeSpan.FromMilliseconds(750)};private bool _working,_disposed;
 public Action<nint>? ShowVisualSupports {get;set;}
 public Action? HideVisualSupports {get;set;}
 public Action? KeepControlsAbove {get;set;}
 public Func<nint,bool>? IsStudentWindow {get;set;}
 public bool StaffMode {get;set;}
 public string Status {get;private set;}="";
 [DllImport("user32.dll")]private static extern bool IsWindow(nint window);
 [DllImport("user32.dll")]private static extern nint GetForegroundWindow();
 [DllImport("user32.dll")]private static extern uint GetWindowThreadProcessId(nint window,out uint pid);
 [DllImport("user32.dll")]private static extern bool SetWindowPos(nint window,nint after,int x,int y,int cx,int cy,uint flags);
 [DllImport("user32.dll")]private static extern bool SetForegroundWindow(nint window);
 [DllImport("user32.dll")]private static extern bool IsIconic(nint window);
 [DllImport("user32.dll")]private static extern bool ShowWindow(nint window,int command);
 private static readonly HashSet<string> Allowed=new(StringComparer.OrdinalIgnoreCase){"VoiceAccess","Narrator","osk","TabTip","TextInputHost","ctfmon","CredentialUIBroker","consent","LogonUI","Taskmgr"};
 public TestWindowFocusService(Func<Task<nint>> target,Func<bool> active){_target=target;_active=active;_timer.Tick+=Tick;_timer.Start();}
 private async void Tick(object? sender,EventArgs e)
 {
  if(_working||_disposed)return;_working=true;
  try{
   if(StaffMode||!_active()){HideVisualSupports?.Invoke();return;}
   nint window=await _target();if(_disposed)return;if(StaffMode||!_active()){HideVisualSupports?.Invoke();return;}if(window==0||!IsWindow(window)){Status="Test window unavailable — ask staff to resume.";return;}
   nint foreground=GetForegroundWindow();if(foreground==0)return;GetWindowThreadProcessId(foreground,out uint frontPid);GetWindowThreadProcessId(window,out uint targetPid);
   if(frontPid==Environment.ProcessId){if(IsStudentWindow?.Invoke(foreground)==true){ShowVisualSupports?.Invoke(window);KeepControlsAbove?.Invoke();}else{HideVisualSupports?.Invoke();}return;}
   if(frontPid==targetPid){ShowVisualSupports?.Invoke(window);KeepControlsAbove?.Invoke();return;}
   try{using var p=Process.GetProcessById((int)frontPid);if(Allowed.Contains(p.ProcessName)){HideVisualSupports?.Invoke();return;}}catch{return;}
   ShowVisualSupports?.Invoke(window);
   // Return focus without making the exam always-on-top: that can cover Voice Access.
   if(IsIconic(window))ShowWindow(window,9);
   KeepControlsAbove?.Invoke();
   Status=SetForegroundWindow(window)?"Test kept in front; accessibility and staff controls remain available.":"Windows declined foreground activation — ask staff. This is not kiosk lockdown.";
  }catch{Status="Focus assistance paused; no apps were closed.";}finally{_working=false;}
 }
 public static void RaiseControls(nint window){if(window!=0)SetWindowPos(window,-1,0,0,0,0,0x13);}
 public void SuspendForStaff(){StaffMode=true;HideVisualSupports?.Invoke();}
 public void Dispose(){_disposed=true;_timer.Stop();_timer.Tick-=Tick;HideVisualSupports?.Invoke();}
}
