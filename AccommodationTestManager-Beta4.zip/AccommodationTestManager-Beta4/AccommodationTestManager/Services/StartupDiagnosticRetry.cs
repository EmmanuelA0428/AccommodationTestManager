using System.IO;
namespace AccommodationTestManager.Services;

// A timeout permits one fresh read-only attempt; no other failure is bypassed.
public sealed class StartupDiagnosticTimeoutException : IOException
{
 public StartupDiagnosticTimeoutException() : base("Read-only startup diagnostics timed out. Session remains with staff; no test countdown started. Use Resume Test to retry, or cancel safely.") { }
}
public static class StartupDiagnosticRetry
{
 public static async Task<T> RunAsync<T>(Func<TimeSpan,Task<T>> run)
 {
  // Let slower laptops complete their first check; bound the retry as well.
  try { return await run(TimeSpan.FromSeconds(20)); }
  catch (StartupDiagnosticTimeoutException) { return await run(TimeSpan.FromSeconds(10)); }
 }
}
