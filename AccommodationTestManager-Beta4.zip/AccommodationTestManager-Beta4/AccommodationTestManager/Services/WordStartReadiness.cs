using AccommodationTestManager.Models;
using System.IO;
namespace AccommodationTestManager.Services;
public static class WordStartReadiness
{
    public static void VerifyDocument(WordDocumentStatus status,string intendedPath)
    {
        if(!Path.GetFullPath(status.FilePath).Equals(Path.GetFullPath(intendedPath),StringComparison.OrdinalIgnoreCase))throw new IOException("Word is not connected to the intended working document. Student handoff blocked.");
        if(status.IsReadOnly||status.HasUnsavedChanges)throw new IOException("The working document is read-only or has unverified unsaved changes. Student handoff blocked.");
        if(!File.Exists(intendedPath))throw new IOException("The working document is missing. Student handoff blocked.");
    }
}
