namespace AccommodationTestManager.Services;

// Match permanent device IDs, not laptop labels, which can be changed or duplicated.
public static class RecordViewPolicy
{
 public static bool IncludeDevice(string? rowDeviceId,string? thisDeviceId,bool thisLaptopOnly) =>
  !thisLaptopOnly || (!string.IsNullOrWhiteSpace(thisDeviceId) && string.Equals(rowDeviceId,thisDeviceId,System.StringComparison.OrdinalIgnoreCase));
}
