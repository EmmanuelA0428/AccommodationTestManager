using AccommodationTestManager.Models;
using System.IO;

namespace AccommodationTestManager.Services;

// Local durable intent. An intent is eligible for cloud deletion only after the
// original local directory has disappeared. No document content is sent to cloud.
public sealed record TestDeletionIntent(string SessionId,string DeviceId);
public sealed class TestDeletionQueue
{
 private readonly LocalStorageService _storage;
 private readonly string _directory;
 public TestDeletionQueue(LocalStorageService storage){_storage=storage;_directory=Path.Combine(storage.Root,"CloudSync","pending-deletions");Directory.CreateDirectory(_directory);}
 private string FileFor(string id){if(!Guid.TryParseExact(id,"N",out _))throw new IOException("Invalid test ID.");return Path.Combine(_directory,id+".json");}
 private string TestFolder(string id)=>Path.Combine(_storage.Root,"Sessions","Completed",id);
 private bool ExistsInAnyArea(string id)=>new[]{"Preparing","Active","Completed"}.Any(area=>Directory.Exists(Path.Combine(_storage.Root,"Sessions",area,id))||File.Exists(Path.Combine(_storage.Root,"Sessions",area,id)));
 public bool HasPending {get {try{return Directory.EnumerateFiles(_directory,"*.json").Any();}catch{return true;}}}
 public void DeleteLocal(SessionEntry entry,string deviceId,bool sessionBusy,string machineState)
 {
  _storage.EnsureSessionFolder(entry.Folder);
  var actual=LocalStorageService.ReadJson<TestSession>(Path.Combine(entry.Folder,"session.json"));
  if(!Guid.TryParseExact(actual.Id,"N",out _) || actual.Id!=Path.GetFileName(entry.Folder) || !string.Equals(Path.GetFullPath(entry.Folder),Path.GetFullPath(TestFolder(actual.Id)),StringComparison.OrdinalIgnoreCase))throw new IOException("Test folder or ID is invalid.");
  if(string.IsNullOrWhiteSpace(deviceId)||actual.DeviceId!=deviceId)throw new IOException("Delete this test on its original laptop.");
  if(sessionBusy||actual.Status is not ("Completed" or "Cancelled"))throw new IOException("Finish or cancel the test and restore laptop controls before deleting it.");
  if(actual.RestrictionsApplied&&!actual.RestrictionsRestored || machineState is not ("Missing" or "Restored"))throw new IOException("Laptop restoration is not confirmed. Keep this test and resolve recovery first.");
  CheckNoLinks(entry.Folder);
  string intent=FileFor(actual.Id);
  if(File.Exists(intent)){
   var existing=LocalStorageService.ReadJson<TestDeletionIntent>(intent);
   if(existing.SessionId!=actual.Id||existing.DeviceId!=deviceId)throw new IOException("Deletion queue needs review.");
  }else LocalStorageService.WriteJson(intent,new TestDeletionIntent(actual.Id,deviceId));
  try{Directory.Delete(entry.Folder,true);}
  catch(Exception ex)when(ex is IOException or UnauthorizedAccessException){throw new IOException("Deletion did not finish; some files may already be removed. Close any open document and review the test folder before retrying. Shared history was not removed.",ex);}
 }
 private static void CheckNoLinks(string directory)
 {
  foreach(string path in Directory.EnumerateFileSystemEntries(directory)){
   var attrs=File.GetAttributes(path);if((attrs&FileAttributes.ReparsePoint)!=0)throw new IOException("A link was found in this test folder. Delete blocked for staff review.");
   if((attrs&FileAttributes.Directory)!=0)CheckNoLinks(path);
  }
 }
 public IReadOnlyList<TestDeletionIntent> Ready(string deviceId)
 {
  var list=new List<TestDeletionIntent>();
  foreach(string path in Directory.GetFiles(_directory,"*.json")){
   var item=LocalStorageService.ReadJson<TestDeletionIntent>(path);
   if(item.SessionId!=Path.GetFileNameWithoutExtension(path)||!Guid.TryParseExact(item.SessionId,"N",out _)||item.DeviceId!=deviceId)throw new IOException("Deletion queue needs review.");
   if(!ExistsInAnyArea(item.SessionId))list.Add(item);
  }
  return list;
 }
 public void Acknowledge(TestDeletionIntent item,string deviceId)
 {
  if(item.DeviceId!=deviceId||ExistsInAnyArea(item.SessionId))throw new IOException("Deletion acknowledgement is unsafe.");
  string path=FileFor(item.SessionId);var saved=LocalStorageService.ReadJson<TestDeletionIntent>(path);
  if(saved!=item)throw new IOException("Deletion request changed; review required.");File.Delete(path);
 }
}
