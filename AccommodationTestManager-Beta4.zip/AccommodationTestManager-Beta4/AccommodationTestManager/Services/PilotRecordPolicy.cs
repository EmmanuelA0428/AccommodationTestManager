namespace AccommodationTestManager.Services;
// Fixed release boundary: never rolls forward on startup and never deletes documents,
// metadata, or machine snapshots. Recovery always enumerates the unfiltered inventory.
public static class PilotRecordPolicy
{
 public static readonly DateTimeOffset Cutoff=DateTimeOffset.Parse("2026-10-20T23:09:00Z",System.Globalization.CultureInfo.InvariantCulture);
 public static bool IsArchived(DateTimeOffset created,DateTimeOffset? ended,string status)=>
  created<Cutoff && ended is not null && ended<Cutoff && status is "Completed" or "Cancelled";
}
