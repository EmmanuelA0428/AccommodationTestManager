using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
namespace AccommodationTestManager.Services;
public static class MachineBrokerClient
{
 private static string? _token;
 public static string Executable=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"AccommodationTestManagerBeta2","Broker","AtmMachineBroker.exe");
 public static bool Installed=>File.Exists(Executable);
 private static async Task<JsonElement> Send(object request)
 {
  if(!Installed)throw new IOException("Install Beta 4 normally to enable PIN-only machine controls.");
  using var timeout=new CancellationTokenSource(TimeSpan.FromMinutes(3));using var pipe=new NamedPipeClientStream(".","ATM-Machine-Broker-v4",PipeDirection.InOut,PipeOptions.Asynchronous,TokenImpersonationLevel.Identification);await pipe.ConnectAsync(5000,timeout.Token).ConfigureAwait(false);
  MachineServiceIdentity.Verify(pipe,Executable);
  using var writer=new StreamWriter(pipe,new UTF8Encoding(false),4096,true){AutoFlush=true};await writer.WriteLineAsync(JsonSerializer.Serialize(request).AsMemory(),timeout.Token).ConfigureAwait(false);using var reader=new StreamReader(pipe,Encoding.UTF8,false,4096,true);var text=new StringBuilder();char[] ch=new char[1];while(text.Length<16384){if(await reader.ReadAsync(ch,timeout.Token).ConfigureAwait(false)==0)throw new IOException("Machine service disconnected. Check diagnostics before retrying.");if(ch[0]=='\n')break;text.Append(ch[0]);}if(text.Length>=16384)throw new IOException("Invalid service reply.");using var doc=JsonDocument.Parse(text.ToString());var reply=doc.RootElement;if(!reply.GetProperty("Success").GetBoolean())throw new IOException(reply.GetProperty("Message").GetString());return reply.Clone();
 }
 public static async Task EnrollWithAdministrator(){using var process=Process.Start(new ProcessStartInfo(Executable,"--enroll"){UseShellExecute=true,Verb="runas"})??throw new IOException("PIN reset did not start.");await process.WaitForExitAsync();_token=null;if(process.ExitCode!=0)throw new IOException("PIN reset was cancelled or failed.");}
 public static async Task Authenticate(string pin){var reply=await Send(new{Action="Authenticate",Pin=pin}).ConfigureAwait(false);_token=reply.GetProperty("Token").GetString();}
 public static async Task ChangePin(string pin){await Send(new{Action="SetPin",Pin=pin,Token=_token}).ConfigureAwait(false);_token=null;await Authenticate(pin).ConfigureAwait(false);}
 public static Task CloseEdge(string scope)=>Send(new{Action="CloseEdge",Plan=new{Scope=scope},Token=_token});
 public static Task Run(string action,string id,JsonElement? plan)=>Send(new{Action=action,SessionId=id,Plan=plan,Token=_token});
}
