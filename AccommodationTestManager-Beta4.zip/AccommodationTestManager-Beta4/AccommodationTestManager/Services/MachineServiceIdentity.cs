using System.ComponentModel;
using System.IO;
using System.IO.Pipes;
using System.Runtime.InteropServices;
using Microsoft.Win32.SafeHandles;

namespace AccommodationTestManager.Services;

// Bind the connected pipe to the installed SCM service before sending a PIN/token.
// Do not OpenProcess on the SYSTEM service: normal testing accounts may be denied
// PROCESS_QUERY_LIMITED_INFORMATION even though they can query local service status.
internal static class MachineServiceIdentity
{
    private const uint ScManagerConnect = 0x0001;
    private const uint ServiceQueryConfig = 0x0001, ServiceQueryStatus = 0x0004;
    private const uint OwnProcess = 0x0010, Running = 4;
    internal const string ServiceName = "AtmMachineBroker";

    [StructLayout(LayoutKind.Sequential)]
    private struct Status
    {
        public uint Type, State, ControlsAccepted, Win32ExitCode, ServiceSpecificExitCode,
            CheckPoint, WaitHint, ProcessId, ServiceFlags;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct Config
    {
        public uint Type, StartType, ErrorControl;
        public IntPtr BinaryPath, LoadOrderGroup;
        public uint TagId;
        public IntPtr Dependencies, Account, DisplayName;
    }
    private sealed class ServiceHandle : SafeHandleZeroOrMinusOneIsInvalid
    {
        public ServiceHandle() : base(true) { }
        protected override bool ReleaseHandle() => CloseServiceHandle(handle);
    }
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern ServiceHandle OpenSCManager(string? machine, string? database, uint access);
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    private static extern ServiceHandle OpenService(ServiceHandle manager, string name, uint access);
    [DllImport("advapi32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryServiceStatusEx(ServiceHandle service, int level, out Status status, int size, out int needed);
    [DllImport("advapi32.dll", CharSet=CharSet.Unicode, SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool QueryServiceConfig(ServiceHandle service, IntPtr config, uint size, out uint needed);
    [DllImport("advapi32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool CloseServiceHandle(IntPtr handle);
    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetNamedPipeServerProcessId(SafePipeHandle pipe, out uint pid);
    [DllImport("kernel32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetNamedPipeServerSessionId(SafePipeHandle pipe, out uint session);

    private static IOException Failure(string step)
    {
        int error=Marshal.GetLastWin32Error();
        return new IOException($"Cannot verify machine service ({step}, Windows error {error}). Keep recovery snapshots; administrator service repair may be needed.", new Win32Exception(error));
    }
    internal static void Verify(NamedPipeClientStream pipe, string expectedExecutable)
    {
        if (!GetNamedPipeServerProcessId(pipe.SafePipeHandle, out uint pipePid)) throw Failure("pipe owner");
        using var manager=OpenSCManager(null, null, ScManagerConnect);
        if (manager.IsInvalid) throw Failure("service manager query");
        using var service=OpenService(manager, ServiceName, ServiceQueryConfig | ServiceQueryStatus);
        if (service.IsInvalid) throw Failure("installed service query");
        if (!QueryServiceStatusEx(service, 0, out var status, Marshal.SizeOf<Status>(), out _)) throw Failure("service status");
        bool probed=QueryServiceConfig(service, IntPtr.Zero, 0, out uint needed);
        int error=Marshal.GetLastWin32Error();
        if (probed || error!=122 || needed==0 || needed>65536) throw Failure("service configuration size");
        var memory=Marshal.AllocHGlobal(checked((int)needed));
        string path, account; uint type;
        try
        {
            if (!QueryServiceConfig(service, memory, needed, out _)) throw Failure("service configuration");
            var config=Marshal.PtrToStructure<Config>(memory);
            path=Marshal.PtrToStringUni(config.BinaryPath) ?? "";
            account=Marshal.PtrToStringUni(config.Account) ?? "";
            type=config.Type;
        }
        finally { Marshal.FreeHGlobal(memory); }
        // The pipe must be held open throughout validation. A different service or
        // an impersonator cannot satisfy the running own-process service PID binding.
        Validate(status.State, status.Type, type, status.ProcessId, pipePid, path, account, expectedExecutable);
        if (!GetNamedPipeServerSessionId(pipe.SafePipeHandle, out uint session)) throw Failure("service session");
        if (session!=0) throw new IOException("Machine service must run in session zero.");
        // Recheck after config/session reads; fail closed if service stopped/restarted.
        if (!QueryServiceStatusEx(service, 0, out var current, Marshal.SizeOf<Status>(), out _)) throw Failure("service status recheck");
        if (current.State!=Running || current.Type!=OwnProcess || current.ProcessId!=pipePid)
            throw new IOException("Machine service changed during verification. Retry after service repair.");
    }
    internal static void Validate(uint state, uint statusType, uint configType, uint servicePid, uint pipePid,
        string command, string account, string expectedExecutable)
    {
        if (state!=Running || statusType!=OwnProcess || configType!=OwnProcess || servicePid==0 || servicePid!=pipePid)
            throw new IOException("Unexpected machine service owner or state.");
        if (!string.Equals(account,"LocalSystem",StringComparison.OrdinalIgnoreCase))
            throw new IOException("Unexpected machine service account.");
        // Setup installs exactly one quoted executable, with no arguments. Reject
        // wrappers, extra arguments, environment variables and alternate binaries.
        string binary=command;
        if (binary.Length>=2 && binary[0]=='"' && binary[^1]=='"') binary=binary[1..^1];
        if (binary.Contains('"') || !Path.IsPathFullyQualified(binary) ||
            !string.Equals(Path.GetFullPath(binary),Path.GetFullPath(expectedExecutable),StringComparison.OrdinalIgnoreCase))
            throw new IOException("Unexpected machine service executable.");
    }
}
