using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
namespace AccommodationTestManager.Services;
public interface IExamBrowser
{
 Task OpenAsync(string profile,string url); Task CloseAsync(string profile); nint GetWindow(string profile);
}
// Ownership is the exact GUID-scoped user-data-dir, PID creation time, executable and Windows session.
// Never kills Edge, enumerates browser tabs, reads cookies, or sends keys to arbitrary windows.
public sealed class ExamBrowserService : IExamBrowser
{
 [StructLayout(LayoutKind.Sequential)]private struct UnicodeString{public ushort Length,MaximumLength;public nint Buffer;}
 [DllImport("ntdll.dll")]private static extern int NtQueryInformationProcess(nint process,int information,nint buffer,int size,out int needed);
 [DllImport("shell32.dll",CharSet=CharSet.Unicode,SetLastError=true)]private static extern nint CommandLineToArgvW(string command,out int argc);
 [DllImport("kernel32.dll")]private static extern nint LocalFree(nint memory);
 [UnmanagedFunctionPointer(CallingConvention.Winapi)]
 [return:MarshalAs(UnmanagedType.Bool)]private delegate bool WindowCallback(nint window,nint parameter);
 [DllImport("user32.dll")]
 [return:MarshalAs(UnmanagedType.Bool)]private static extern bool EnumWindows(WindowCallback callback,nint param);
 [DllImport("user32.dll")]private static extern uint GetWindowThreadProcessId(nint hwnd,out uint pid);
 [DllImport("user32.dll")]private static extern bool IsWindowVisible(nint hwnd);
 [DllImport("user32.dll")]private static extern nint GetWindow(nint hwnd,uint command);
 [DllImport("user32.dll",SetLastError=true)]private static extern bool PostMessage(nint hwnd,uint message,nint w,nint l);
 private sealed record Root(int Pid,DateTime Started,string Executable);
 private static string[] Arguments(Process process)
 {
  int needed;NtQueryInformationProcess(process.Handle,60,0,0,out needed);if(needed<=0||needed>131072)throw new IOException("Edge ownership could not be read.");
  nint memory=Marshal.AllocHGlobal(needed);
  try{if(NtQueryInformationProcess(process.Handle,60,memory,needed,out _)!=0)throw new IOException("Edge ownership could not be read.");var u=Marshal.PtrToStructure<UnicodeString>(memory);string command=Marshal.PtrToStringUni(u.Buffer,u.Length/2)??"";nint args=CommandLineToArgvW(command,out int count);if(args==0)return [];try{var result=new string[count];for(int i=0;i<count;i++)result[i]=Marshal.PtrToStringUni(Marshal.ReadIntPtr(args,i*IntPtr.Size))??"";return result;}finally{LocalFree(args);}}
  finally{Marshal.FreeHGlobal(memory);}
 }
 public static bool MatchesProfile(IEnumerable<string> arguments,string profile)
 {
  var args=arguments.ToArray();if(args.Any(a=>a.StartsWith("--type=",StringComparison.OrdinalIgnoreCase)||a.Equals("--type",StringComparison.OrdinalIgnoreCase)))return false;
  var values=args.Where(a=>a.StartsWith("--user-data-dir=",StringComparison.OrdinalIgnoreCase)).Select(a=>a[16..]).ToList();
  for(int i=0;i<args.Length;i++)if(args[i].Equals("--user-data-dir",StringComparison.OrdinalIgnoreCase)){if(i+1>=args.Length||args[i+1].StartsWith("--"))return false;values.Add(args[i+1]);}
  if(values.Count!=1||!Path.IsPathFullyQualified(values[0])||!Path.IsPathFullyQualified(profile))return false;
  try{return Path.GetFullPath(values[0]).TrimEnd(Path.DirectorySeparatorChar).Equals(Path.GetFullPath(profile).TrimEnd(Path.DirectorySeparatorChar),StringComparison.OrdinalIgnoreCase);}catch{return false;}
 }
 private static List<Root> Roots(string profile,bool strict=false)
 {
  var roots=new List<Root>();using var own=Process.GetCurrentProcess();
  foreach(var p in Process.GetProcessesByName("msedge"))using(p)try{if(p.SessionId!=own.SessionId||!MatchesProfile(Arguments(p),profile))continue;string exe=p.MainModule?.FileName??"";if(!Path.GetFileName(exe).Equals("msedge.exe",StringComparison.OrdinalIgnoreCase))throw new IOException("Edge executable could not be verified.");roots.Add(new(p.Id,p.StartTime.ToUniversalTime(),exe));}catch(Exception ex)when(ex is System.ComponentModel.Win32Exception or InvalidOperationException or ArgumentException or IOException){bool exited=false;try{exited=p.HasExited;}catch{}if(strict&&!exited)throw new IOException("Cannot verify whether Edge belongs to this test. Close Edge normally and retry; restoration is paused.",ex);}
  return roots;
 }
 private static bool StillOwned(Root root)
 {try{using var p=Process.GetProcessById(root.Pid);return !p.HasExited&&p.StartTime.ToUniversalTime()==root.Started&&p.MainModule?.FileName==root.Executable;}catch{return false;}}
 private static List<nint> Windows(List<Root> roots)
 {
  var result=new List<nint>();EnumWindows((window,_)=>{GetWindowThreadProcessId(window,out uint pid);if(IsWindowVisible(window)&&GetWindow(window,4)==0&&roots.Any(r=>r.Pid==pid&&StillOwned(r)))result.Add(window);return true;},0);return result;
 }
 public nint GetWindow(string profile)=>Windows(Roots(profile)).FirstOrDefault();
 public async Task OpenAsync(string profile,string url)
 {
  string? edge=new[]{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Microsoft","Edge","Application","msedge.exe"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Microsoft","Edge","Application","msedge.exe")}.FirstOrDefault(File.Exists);
  if(edge is null)throw new FileNotFoundException("Microsoft Edge was not found.");
  var start=new ProcessStartInfo(edge){UseShellExecute=false};foreach(string arg in new[]{"--user-data-dir="+profile,"--no-first-run","--disable-background-mode","--start-fullscreen","--new-window",url})start.ArgumentList.Add(arg);
  using var launched=Process.Start(start)??throw new IOException("Edge could not start.");
  for(int i=0;i<80;i++){if(GetWindow(profile)!=0)return;await Task.Delay(125);}
  throw new IOException("The test Edge window could not be ownership-verified. No other browser was changed; preserve the session and use Resume after checking Edge.");
 }
 public async Task CloseAsync(string profile)
 {
  var roots=Roots(profile,true);var windows=Windows(roots);if(roots.Count==0&&windows.Count==0)return;
  foreach(var window in windows){GetWindowThreadProcessId(window,out uint pid);if(roots.Any(r=>r.Pid==pid&&StillOwned(r)))PostMessage(window,0x10,0,0);}
  for(int i=0;i<80;i++){if(roots.All(r=>!StillOwned(r))){if(Roots(profile,true).Count==0)return;throw new IOException("The test browser restarted. Close its windows normally and retry; restoration has not continued.");}await Task.Delay(125);}
  throw new IOException("The test's Edge instance is still open. Complete any save/download prompt and close that window, then retry. No process was force-killed and machine restoration has not continued.");
 }
}
