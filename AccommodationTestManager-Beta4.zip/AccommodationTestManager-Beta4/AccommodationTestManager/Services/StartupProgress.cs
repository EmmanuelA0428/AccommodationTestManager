namespace AccommodationTestManager.Services;

// Captions reflect actual coordinator milestones, not guessed percentages.
public static class StartupProgress
{
 public static string? CaptionFor(string milestone,string? mode) => milestone switch
 {
  "Session prepared" => "Preparing test files…",
  "Import verified" or "Ready to apply controls" => "Preparing laptop controls…",
  "Applying machine restrictions" => "Applying laptop controls…",
  "Machine controls applied" or "Unenforced mode selected" => "Preparing test application…",
  "Opening test application" => mode == "Word" ? "Opening Word…" : "Opening test application…",
  "Test application opened" => "Checking test readiness…",
  _ => null
 };
}
