using AccommodationTestManager.Models;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
namespace AccommodationTestManager.Services;
public interface ICloudIdentityStore { CloudIdentity? Load(); void Save(CloudIdentity identity); }
// Refresh tokens are protected for this Windows user. Never silently replace a damaged identity.
public sealed class WindowsCloudIdentityStore(string root) : ICloudIdentityStore
{
 private readonly string _path=Path.Combine(root,"CloudSync","identity.dpapi");
 [StructLayout(LayoutKind.Sequential)] private struct Blob {public int Size;public IntPtr Data;}
 [DllImport("crypt32.dll",SetLastError=true,CharSet=CharSet.Unicode)] private static extern bool CryptProtectData(ref Blob input,string? description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
 [DllImport("crypt32.dll",SetLastError=true,CharSet=CharSet.Unicode)] private static extern bool CryptUnprotectData(ref Blob input,IntPtr description,IntPtr entropy,IntPtr reserved,IntPtr prompt,uint flags,out Blob output);
 [DllImport("kernel32.dll")] private static extern IntPtr LocalFree(IntPtr memory);
 private static byte[] Protect(byte[] bytes,bool encrypt)
 {
  if(!OperatingSystem.IsWindows())throw new PlatformNotSupportedException("Windows credential protection is required.");
  Blob input=new(){Size=bytes.Length,Data=Marshal.AllocHGlobal(bytes.Length)};Blob output=default;
  try {Marshal.Copy(bytes,0,input.Data,bytes.Length);bool ok=encrypt?CryptProtectData(ref input,null,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output):CryptUnprotectData(ref input,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,IntPtr.Zero,1,out output);if(!ok)throw new IOException("Cloud identity could not be protected or read; existing identity retained.");var result=new byte[output.Size];Marshal.Copy(output.Data,result,0,result.Length);return result;}
  finally {Marshal.FreeHGlobal(input.Data);if(output.Data!=IntPtr.Zero)LocalFree(output.Data);Array.Clear(bytes);}
 }
 public CloudIdentity? Load()
 {
  if(!File.Exists(_path))return null;
  var bytes=Protect(File.ReadAllBytes(_path),false);
  try {var identity=JsonSerializer.Deserialize<CloudIdentity>(bytes)??throw new InvalidDataException("Cloud identity is incomplete.");if(string.IsNullOrWhiteSpace(identity.Uid)||string.IsNullOrWhiteSpace(identity.RefreshToken))throw new InvalidDataException("Cloud identity is incomplete.");return identity;}
  finally{Array.Clear(bytes);}
 }
 public void Save(CloudIdentity identity)
 {
  byte[] encrypted=Protect(Encoding.UTF8.GetBytes(JsonSerializer.Serialize(identity)),true);Directory.CreateDirectory(Path.GetDirectoryName(_path)!);
  string temp=_path+".tmp";using(var f=new FileStream(temp,FileMode.Create,FileAccess.Write,FileShare.None)){f.Write(encrypted);f.Flush(true);}File.Move(temp,_path,true);
 }
}
