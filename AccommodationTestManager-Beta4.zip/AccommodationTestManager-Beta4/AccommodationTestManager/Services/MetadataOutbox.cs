using AccommodationTestManager.Models;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;

namespace AccommodationTestManager.Services;

// Durable, coalescing metadata queue only. No network, machine controls, or file uploads.
// All writes are independent of session commits; queue failure must never block restoration.
public sealed class MetadataOutbox
{
    private readonly object _gate = new();
    private readonly string _path;
    private MetadataQueueState _state;
    public MetadataOutbox(LocalStorageService storage)
    {
        _path = Path.Combine(storage.Root, "CloudSync", "metadata-outbox.json");
        _state = File.Exists(_path) ? LocalStorageService.ReadJson<MetadataQueueState>(_path) : new();
        if (_state.SchemaVersion != 1 || _state.Revisions is null || _state.Fingerprints is null || _state.Pending is null)
            throw new IOException("Metadata queue needs review. Existing queue was not reset.");
        foreach (var pair in _state.Pending)
        {
            Validate(pair.Value.Data);
            if (pair.Key != pair.Value.Data.SessionId || !_state.Revisions.TryGetValue(pair.Key, out long revision)
                || revision != pair.Value.Revision || revision < 1 || Fingerprint(pair.Value.Data) != pair.Value.Fingerprint
                || !_state.Fingerprints.TryGetValue(pair.Key, out var fingerprint) || fingerprint != pair.Value.Fingerprint)
                throw new IOException("Metadata queue consistency check failed. Existing queue was not reset.");
        }
    }
    public static SessionMetadata Project(LocalStorageService storage, SessionEntry entry, string deviceId)
    {
        storage.EnsureSessionFolder(entry.Folder);
        var s = entry.Session;
        // Historical records from another device must not be reassigned to this laptop.
        if (s.DeviceId != deviceId) throw new IOException("Session does not belong to this enrolled local device.");
        bool available = false;
        foreach (string relative in new[] { s.WorkingRelativePath, s.FinishRelativePath, s.FinalRelativePath })
        {
            if (string.IsNullOrWhiteSpace(relative)) continue;
            if (File.Exists(storage.FileInSession(entry.Folder, relative))) available = true;
        }
        var data = new SessionMetadata(1, s.Id, deviceId, s.Mode, s.Status, s.CreatedUtc,
            s.StartedUtc, s.CompletedUtc ?? s.FinishedUtc, available);
        Validate(data); return data;
    }
    public static void Validate(SessionMetadata value)
    {
        if (value.SchemaVersion != 1 || !Guid.TryParseExact(value.SessionId, "N", out _)
            || !Guid.TryParseExact(value.DeviceId, "N", out _)
            || value.Mode is not ("Word" or "Canvas" or "Posit" or "Custom")
            || value.Status is not ("Preparing" or "Starting" or "Preflight" or "Active" or "AwaitingStaff" or "ExportPending" or "Completing" or "Completed" or "Cancelled" or "RecoveryRequired" or "NeedsReview")
            || value.CreatedUtc == default)
            throw new IOException("Invalid or unsupported anonymous session metadata.");
    }
    private static string Fingerprint(SessionMetadata data) => Convert.ToHexString(SHA256.HashData(JsonSerializer.SerializeToUtf8Bytes(data))).ToLowerInvariant();
    public bool Enqueue(SessionMetadata data)
    {
        Validate(data);
        lock (_gate)
        {
            string fingerprint = Fingerprint(data);
            if (_state.Fingerprints.TryGetValue(data.SessionId, out string? previous) && previous == fingerprint) return false;
            var next = LocalStorageService.Clone(_state);
            if (next.Revisions.Count >= 10000 && !next.Revisions.ContainsKey(data.SessionId)) throw new IOException("Metadata queue limit reached. Local tests are unaffected.");
            long revision = checked(next.Revisions.GetValueOrDefault(data.SessionId) + 1);
            next.Revisions[data.SessionId] = revision; next.Fingerprints[data.SessionId] = fingerprint;
            next.Pending[data.SessionId] = new(revision, fingerprint, data);
            LocalStorageService.WriteJson(_path, next); _state = next; return true;
        }
    }
    public IReadOnlyList<PendingMetadata> Pending()
    { lock (_gate) return _state.Pending.Values.OrderBy(x => x.Data.CreatedUtc).ToArray(); }
    // An acknowledgement for an older upload must not discard a newer queued status.
    // Caller may invoke ONLY after checking the server's successful per-record result.
    public bool Acknowledge(string sessionId, long revision, string fingerprint)
    {
        lock (_gate)
        {
            if (!_state.Pending.TryGetValue(sessionId, out var pending) || pending.Revision != revision || pending.Fingerprint != fingerprint) return false;
            var next = LocalStorageService.Clone(_state); next.Pending.Remove(sessionId);
            LocalStorageService.WriteJson(_path, next); _state = next; return true;
        }
    }
}
