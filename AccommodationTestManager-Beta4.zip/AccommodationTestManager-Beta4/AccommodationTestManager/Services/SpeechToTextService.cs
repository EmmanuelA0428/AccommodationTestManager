using System.Diagnostics;
using System.IO;

namespace AccommodationTestManager.Services;

// Voice Access retains its native toolbar and listening controls.
// Process presence is never presented as microphone/listening status.
public sealed class SpeechToTextService
{
    public string EnsureRunning()
    {
        using Process current = Process.GetCurrentProcess();
        Process[] processes = Process.GetProcessesByName("VoiceAccess");
        try
        {
            foreach (Process process in processes)
            {
                try
                {
                    if (!process.HasExited && process.SessionId == current.SessionId)
                        return "Voice Access is already running in this Windows session. Use its native controls to enable listening.";
                }
                catch (InvalidOperationException) { /* Process exited during inspection. */ }
                catch (System.ComponentModel.Win32Exception) { /* Can't inspect this process. */ }
            }
        }
        finally { foreach (Process process in processes) process.Dispose(); }

        string executable = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),
            "System32", "VoiceAccess.exe");
        if (!File.Exists(executable))
            throw new FileNotFoundException("Voice Access was not found. Check Windows accessibility settings and install its language model before testing.");
        using Process? launched = Process.Start(new ProcessStartInfo(executable) { UseShellExecute = true });
        return "Voice Access launch requested. Use its native controls to enable listening. Launching does not confirm microphone or language-model readiness.";
    }
    // Only the Windows Voice Access executable in this interactive session is eligible.
    // Cleanup is separate from saving/finishing so a failure cannot lose test work.
    public async Task StopInCurrentSessionAsync()
    {
        using var own=Process.GetCurrentProcess();
        string expected=Path.GetFullPath(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Windows),"System32","VoiceAccess.exe"));
        var processes=Process.GetProcessesByName("VoiceAccess");
        try{
            foreach(var p in processes){
                try{
                    if(p.HasExited||p.SessionId!=own.SessionId)continue;
                    string? executable=p.MainModule?.FileName;
                    if(executable is null||!Path.GetFullPath(executable).Equals(expected,StringComparison.OrdinalIgnoreCase))throw new IOException("Voice Access process could not be verified; close it manually.");
                    if(p.CloseMainWindow())await Task.WhenAny(p.WaitForExitAsync(),Task.Delay(2000));
                    if(!p.HasExited){p.Kill(entireProcessTree:false);await p.WaitForExitAsync();}
                }catch(InvalidOperationException){/* Already exited. */}
            }
        }finally{foreach(var p in processes)p.Dispose();}
    }

}
