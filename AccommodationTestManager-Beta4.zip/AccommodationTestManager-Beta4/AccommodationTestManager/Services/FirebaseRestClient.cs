using System.IO;
using AccommodationTestManager.Models;
using System.Globalization;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;
namespace AccommodationTestManager.Services;
public sealed class FirebaseRestClient : IDisposable
{
 private readonly FirebaseClientOptions _options;private readonly ICloudIdentityStore _store;private readonly HttpClient _http;
 private Dictionary<string,string> _labels=[]; private DateTimeOffset _labelsFetched;
 private CloudIdentity? _identity;private string? _token;private DateTimeOffset _expires;
 private string Root=>$"https://firestore.googleapis.com/v1/projects/{_options.ProjectId}/databases/(default)/documents";
 public FirebaseRestClient(FirebaseClientOptions options,ICloudIdentityStore store,HttpMessageHandler? handler=null)
 {
  if(options.ProjectId!="accommodation-test-manager"||string.IsNullOrWhiteSpace(options.ApiKey))throw new ArgumentException("Unexpected Firebase project.");
  _options=options;_store=store;_http=handler is null?new HttpClient():new HttpClient(handler);_http.Timeout=TimeSpan.FromSeconds(12);
 }
 public string Uid=>_identity?.Uid??throw new InvalidOperationException("Cloud identity not ready.");
 public async Task Authenticate(CancellationToken ct)
 {
  if(_token is not null&&_expires>DateTimeOffset.UtcNow.AddMinutes(2))return;
  _identity??=_store.Load();
  using var response=_identity is null?await _http.PostAsJsonAsync($"https://identitytoolkit.googleapis.com/v1/accounts:signUp?key={_options.ApiKey}",new{returnSecureToken=true},ct):await _http.PostAsync($"https://securetoken.googleapis.com/v1/token?key={_options.ApiKey}",new FormUrlEncodedContent(new Dictionary<string,string>{{"grant_type","refresh_token"},{"refresh_token",_identity.RefreshToken}}),ct);
  if(!response.IsSuccessStatusCode)throw new HttpRequestException("Background authentication unavailable; cached identity and local data retained.",null,response.StatusCode);
  using var json=JsonDocument.Parse(await response.Content.ReadAsStringAsync(ct));var r=json.RootElement;bool first=_identity is null;
  string uid=r.GetProperty(first?"localId":"user_id").GetString()!,refresh=r.GetProperty(first?"refreshToken":"refresh_token").GetString()!,token=r.GetProperty(first?"idToken":"id_token").GetString()!;
  if(!first&&uid!=_identity!.Uid)throw new InvalidOperationException("Firebase identity changed unexpectedly.");
  var identity=new CloudIdentity(uid,refresh);_store.Save(identity);_identity=identity;_token=token;_expires=DateTimeOffset.UtcNow.AddSeconds(int.Parse(r.GetProperty(first?"expiresIn":"expires_in").GetString()!,CultureInfo.InvariantCulture));
 }
 private async Task<JsonDocument?> Request(HttpMethod method,string url,object? body,CancellationToken ct,bool missingOk=false)
 {
  using var req=new HttpRequestMessage(method,url);req.Headers.Authorization=new AuthenticationHeaderValue("Bearer",_token);if(body is not null)req.Content=JsonContent.Create(body);
  using var response=await _http.SendAsync(req,HttpCompletionOption.ResponseHeadersRead,ct);
  if(missingOk&&response.StatusCode==HttpStatusCode.NotFound)return null;
  if(!response.IsSuccessStatusCode){if(response.StatusCode==HttpStatusCode.Unauthorized)_token=null;throw new HttpRequestException($"Cloud request failed ({(int)response.StatusCode}); local data retained.",null,response.StatusCode);}
  string text=await response.Content.ReadAsStringAsync(ct);if(text.Length>8_000_000)throw new InvalidDataException("Cloud response exceeds limit.");return JsonDocument.Parse(text);
 }
 public static object S(string value)=>new{stringValue=value};public static object I(long value)=>new{integerValue=value.ToString(CultureInfo.InvariantCulture)};public static object B(bool value)=>new{booleanValue=value};public static object T(DateTimeOffset? value)=>value is null?new{nullValue="NULL_VALUE"}:(object)new{timestampValue=value.Value.ToUniversalTime().ToString("O")};
 private static string Text(JsonElement f,string key)=>f.GetProperty(key).GetProperty("stringValue").GetString()!;
 private static long Number(JsonElement f,string key)=>long.Parse(f.GetProperty(key).GetProperty("integerValue").GetString()!,CultureInfo.InvariantCulture);
 private static DateTimeOffset Time(JsonElement f,string key)=>DateTimeOffset.Parse(f.GetProperty(key).GetProperty("timestampValue").GetString()!,CultureInfo.InvariantCulture);
 private static string Name(JsonDocument d)=>d.RootElement.GetProperty("name").GetString()!;
 private async Task Commit(string relative,Dictionary<string,object> fields,string timestamp,CancellationToken ct,string? precondition=null,bool createOnly=false)
 {
  var write=new Dictionary<string,object>{{"update",new{name=$"projects/{_options.ProjectId}/databases/(default)/documents/{relative}",fields}},{"updateTransforms",new[]{new{fieldPath=timestamp,setToServerValue="REQUEST_TIME"}}}};
  if(precondition is not null)write["currentDocument"]=new{updateTime=precondition};else if(createOnly)write["currentDocument"]=new{exists=false};
  using var result=await Request(HttpMethod.Post,Root+":commit",new{writes=new[]{write}},ct);
 }
 public async Task RegisterDevice(string deviceId,long revision,CancellationToken ct,string? displayName=null)
 {
  using var existing=await Request(HttpMethod.Get,Root+"/devices/"+Uid,null,ct,true);
  string label="Laptop-"+deviceId[..8];
  if(existing is not null){var f=existing.RootElement.GetProperty("fields");if(Text(f,"deviceId")!=deviceId||!f.GetProperty("enabled").GetProperty("booleanValue").GetBoolean())throw new InvalidOperationException("Device identity mismatch or disabled; local testing remains available.");label=Text(f,"label");}
  if(!string.IsNullOrWhiteSpace(displayName))label=System.Text.RegularExpressions.Regex.Replace(displayName.Trim(),"[^A-Za-z0-9_-]","-");if(label.Length>32)label=label[..32];
  await Commit("devices/"+Uid,new(){{"deviceId",S(deviceId)},{"label",S(label)},{"enabled",B(true)},{"appVersion",S(UpdatePolicy.InstalledVersion)},{"appliedConfigRevision",I(revision)}},"lastSeenAt",ct);
 }
 public async Task Upload(PendingMetadata pending,CancellationToken ct)
 {
  MetadataOutbox.Validate(pending.Data);var d=pending.Data;string path="sessions/"+Uid+"_"+d.SessionId;
  using var existing=await Request(HttpMethod.Get,Root+"/"+path,null,ct,true);
  if(existing is not null){var f=existing.RootElement.GetProperty("fields");long revision=Number(f,"revision");if(revision>pending.Revision||revision==pending.Revision&&Text(f,"fingerprint")!=pending.Fingerprint)throw new InvalidOperationException("Session metadata revision conflict; pending data retained.");if(revision==pending.Revision)return;}
  await Commit(path,new(){{"schemaVersion",I(1)},{"sessionId",S(d.SessionId)},{"deviceId",S(d.DeviceId)},{"ownerUid",S(Uid)},{"mode",S(d.Mode)},{"status",S(d.Status)},{"createdAt",T(d.CreatedUtc)},{"startedAt",T(d.StartedUtc)},{"endedAt",T(d.EndedUtc)},{"recoveryReportedAvailable",B(d.RecoveryReportedAvailable)},{"revision",I(pending.Revision)},{"fingerprint",S(pending.Fingerprint)}},"updatedAt",ct,existing?.RootElement.GetProperty("updateTime").GetString());
 }
 private async Task<List<JsonElement>> List(string collection,CancellationToken ct)
 {
  var rows=new List<JsonElement>();string? next=null;
  do{using var doc=await Request(HttpMethod.Get,Root+"/"+collection+"?pageSize=300"+(next is null?"":"&pageToken="+Uri.EscapeDataString(next)),null,ct);var r=doc!.RootElement;if(r.TryGetProperty("documents",out var list))foreach(var item in list.EnumerateArray())rows.Add(item.Clone());if(rows.Count>10000)throw new InvalidDataException("Cloud directory exceeds limit.");next=r.TryGetProperty("nextPageToken",out var token)?token.GetString():null;}while(!string.IsNullOrEmpty(next));return rows;
 }
 private async Task<List<JsonElement>> ChangedSessions(DateTimeOffset since,CancellationToken ct)
 {
  using var result=await Request(HttpMethod.Post,Root+":runQuery",new{structuredQuery=new{from=new[]{new{collectionId="sessions"}},where=new{fieldFilter=new{field=new{fieldPath="updatedAt"},op="GREATER_THAN_OR_EQUAL",value=T(since)}},orderBy=new[]{new{field=new{fieldPath="updatedAt"},direction="ASCENDING"}},limit=10001}},ct);
  var rows=new List<JsonElement>();foreach(var item in result!.RootElement.EnumerateArray())if(item.TryGetProperty("document",out var d))rows.Add(d.Clone());if(rows.Count>10000)throw new InvalidDataException("Too many changed records; existing directory retained.");return rows;
 }
 public async Task<(CloudDefaults? Defaults,List<CloudSessionRow> Rows)> Download(string localDevice,CancellationToken ct,List<CloudSessionRow>? previous=null)
 {
  using var config=await Request(HttpMethod.Get,Root+"/configuration/current",null,ct,true);CloudDefaults? defaults=null;
  if(config is not null){var f=config.RootElement.GetProperty("fields");defaults=new((int)Number(f,"schemaVersion"),Number(f,"revision"),(int)Number(f,"saveIntervalSeconds"),(int)Number(f,"snapshotIntervalSeconds"),(int)Number(f,"maximumRecoveryCopies"),f.GetProperty("defaultTimeLimitMinutes").TryGetProperty("nullValue",out _)?null:(int)Number(f,"defaultTimeLimitMinutes"));CloudDefaultsCache.Validate(defaults);}
  if(true){var devices=await List("devices",ct);_labels=devices.GroupBy(d=>Text(d.GetProperty("fields"),"deviceId")).ToDictionary(g=>g.Key,g=>Text(g.First().GetProperty("fields"),"label"));_labelsFetched=DateTimeOffset.UtcNow;}
  var rows=(previous??[]).ToDictionary(r=>r.DeviceId+"_"+r.SessionId);
  var changed=rows.Count==0?await List("sessions",ct):await ChangedSessions(rows.Values.Max(r=>r.UpdatedAt),ct);
  foreach(var doc in changed)
  {
   var f=doc.GetProperty("fields");string id=Text(f,"sessionId"),device=Text(f,"deviceId"),mode=Text(f,"mode"),status=Text(f,"status");bool available=f.GetProperty("recoveryReportedAvailable").GetProperty("booleanValue").GetBoolean();var created=Time(f,"createdAt");MetadataOutbox.Validate(new(1,id,device,mode,status,created,null,null,available));
   rows[device+"_"+id]=new(id,device,mode,status,available,created,Time(f,"updatedAt")){StartedAt=f.TryGetProperty("startedAt",out var started)&&started.TryGetProperty("timestampValue",out var stamp)?DateTimeOffset.Parse(stamp.GetString()!,System.Globalization.CultureInfo.InvariantCulture):null,EndedAt=f.TryGetProperty("endedAt",out var ended)&&ended.TryGetProperty("timestampValue",out var endStamp)?DateTimeOffset.Parse(endStamp.GetString()!,System.Globalization.CultureInfo.InvariantCulture):null,IsThisLaptop=device==localDevice,Location=_labels.GetValueOrDefault(device,"Laptop-"+device[..8]),Availability=device==localDevice?"This laptop — verify locally":"On another laptop (last reported)"};
  }
  return(defaults,rows.Values.Select(r=>r with{Location=_labels.GetValueOrDefault(r.DeviceId,r.Location)}).OrderByDescending(r=>r.CreatedAt).ToList());
 }
 public async Task<List<SharedStaff>> DownloadStaff(CancellationToken ct){var docs=await List("staff",ct);return docs.Select(doc=>{var f=doc.GetProperty("fields");var value=new SharedStaff(Text(f,"staffId"),Text(f,"name"),f.GetProperty("active").GetProperty("booleanValue").GetBoolean(),Text(f,"operation"),doc.GetProperty("updateTime").GetString());SharedStaffStore.Validate(value.Id,value.Name);return value;}).ToList();}
 public async Task SyncStaff(SharedStaffStore store,bool idle,CancellationToken ct){store.CaptureLocalChanges();var remote=await DownloadStaff(ct);store.SeedIfNeeded(remote);foreach(var item in store.State.Pending.ToArray()){
    var p=item.Value;var existing=remote.FirstOrDefault(x=>x.Id==p.Data.Id);
    // A new laptop's seed must not duplicate an already-published name.
    if(existing is null&&p.ExpectedVersion is null){var same=remote.FirstOrDefault(x=>string.Equals(x.Name.Trim(),p.Data.Name.Trim(),StringComparison.OrdinalIgnoreCase));if(same is not null){store.Acknowledge(item.Key,p.Data.Operation);continue;}}
    if(p.ExpectedVersion is null&&existing is not null&&existing.Name==p.Data.Name&&existing.Active==p.Data.Active){store.Acknowledge(item.Key,p.Data.Operation);continue;}
    if(existing?.Operation==p.Data.Operation){store.ConfirmPublished(item.Key,p.Data.Operation,existing.Version);continue;}
    if(existing?.Version!=p.ExpectedVersion){store.MarkConflict();throw new IOException("Staff update conflict. Local changes are retained; refresh/review before retrying.");}
    await Commit("staff/"+p.Data.Id,new(){{"staffId",S(p.Data.Id)},{"name",S(p.Data.Name)},{"active",B(p.Data.Active)},{"operation",S(p.Data.Operation)}},"updatedAt",ct,p.ExpectedVersion,createOnly:existing is null);
    remote=await DownloadStaff(ct);var published=remote.FirstOrDefault(x=>x.Id==p.Data.Id);if(published?.Operation!=p.Data.Operation){store.MarkConflict();throw new IOException("Staff changed on another laptop. Queued changes are retained.");}store.ConfirmPublished(item.Key,p.Data.Operation,published.Version);
   }remote=await DownloadStaff(ct);store.Store(remote,idle);if(idle){store.PrepareReleaseRoster(remote);if(store.PendingCount>0&&!store.State.Conflict)await SyncStaff(store,idle,ct);}}
 public void Dispose()=>_http.Dispose();
}
