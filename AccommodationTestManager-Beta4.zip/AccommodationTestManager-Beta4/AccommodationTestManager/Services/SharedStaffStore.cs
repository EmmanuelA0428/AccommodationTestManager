using System.IO;
using AccommodationTestManager.Models;
namespace AccommodationTestManager.Services;
public sealed record SharedStaff(string Id,string Name,bool Active,string Operation,string? Version=null);
public sealed record StaffWrite(SharedStaff Data,string? ExpectedVersion);
public sealed class StaffSyncState
{
 public List<SharedStaff> Cache {get;set;}=[];
 public Dictionary<string,StaffWrite> Pending {get;set;}=[];
 public List<StaffMember>? LocalSnapshot {get;set;}
 public bool Conflict {get;set;}
 public bool Seeded {get;set;}
}
// The last-observed local roster is persisted with the outbox. A settings save followed
// by an outbox I/O failure is rediscovered after restart, not silently forgotten.
public sealed class SharedStaffStore
{
 private readonly string _path;private readonly SettingsService _settings;private bool _applying;
 public StaffSyncState State {get;private set;}
 public string? LastError {get;private set;}
 public int PendingCount=>State.Pending.Count;
 private static string Key(IEnumerable<StaffMember> members)=>string.Join("\n",members.OrderBy(x=>x.Id).Select(x=>$"{x.Id}|{x.Name}|{x.Active}"));
 public bool NeedsApply=>State.Cache.Count>0&&Key(_settings.Current.StaffMembers)!=Key(State.Cache.Select(x=>new StaffMember{Id=x.Id,Name=x.Name,Active=x.Active}));
 public SharedStaffStore(LocalStorageService storage,SettingsService settings)
 {
  _path=Path.Combine(storage.Root,"CloudSync","staff-sync.json");_settings=settings;
  State=File.Exists(_path)?LocalStorageService.ReadJson<StaffSyncState>(_path):new();
  if(State.LocalSnapshot is null){var initial=Copy();initial.LocalSnapshot=LocalStorageService.Clone(settings.Current.StaffMembers);Commit(initial);}
  settings.Saved+=Observe;Observe();
 }
 private StaffSyncState Copy()=>LocalStorageService.Clone(State);
 private void Commit(StaffSyncState next){LocalStorageService.WriteJson(_path,next);State=next;}
 private void Observe(){if(_applying)return;try{CaptureLocalChanges();}catch(Exception ex){LastError=ex.Message;}}
 public void CaptureLocalChanges()
 {
  if(_applying)return;
  var next=Copy();var known=next.LocalSnapshot??[];
  foreach(var member in _settings.Current.StaffMembers){var old=known.FirstOrDefault(x=>x.Id==member.Id);if(old is null||old.Name!=member.Name||old.Active!=member.Active)Queue(next,member);}
  // Removing a name deactivates its cloud record; historical attribution is retained.
  foreach(var old in known.Where(x=>_settings.Current.StaffMembers.All(m=>m.Id!=x.Id)))Queue(next,new StaffMember{Id=old.Id,Name=old.Name,Active=false});
  next.LocalSnapshot=LocalStorageService.Clone(_settings.Current.StaffMembers);Commit(next);LastError=null;
 }
 private static void Queue(StaffSyncState state,StaffMember m){Validate(m.Id,m.Name);string? expected=state.Pending.TryGetValue(m.Id,out var prior)?prior.ExpectedVersion:state.Cache.FirstOrDefault(x=>x.Id==m.Id)?.Version;state.Pending[m.Id]=new(new(m.Id,m.Name.Trim(),m.Active,Guid.NewGuid().ToString("N")),expected);}
 public void SeedIfNeeded(List<SharedStaff> remote){var next=Copy();if(!next.Seeded&&remote.Count==0&&next.Pending.Count==0)foreach(var m in _settings.Current.StaffMembers)Queue(next,m);next.Seeded=true;Commit(next);}
 public void MarkConflict(){var next=Copy();next.Conflict=true;Commit(next);}
 public void UseSharedVersions(){var next=Copy();next.Pending.Clear();next.Conflict=false;next.LocalSnapshot=LocalStorageService.Clone(_settings.Current.StaffMembers);Commit(next);}
 public void ConfirmPublished(string id,string operation,string? version){if(!State.Pending.TryGetValue(id,out var pending))return;if(pending.Data.Operation==operation){Acknowledge(id,operation);return;}var next=Copy();next.Pending[id]=pending with{ExpectedVersion=version};Commit(next);}
 public void Acknowledge(string id,string operation){if(State.Pending.TryGetValue(id,out var p)&&p.Data.Operation==operation){var next=Copy();next.Pending.Remove(id);Commit(next);}}
 public void Store(List<SharedStaff> remote,bool idle)
 {
  foreach(var row in remote)Validate(row.Id,row.Name);
  if(remote.Count>100||remote.GroupBy(x=>x.Id).Any(g=>g.Count()>1)||remote.Where(x=>x.Active).GroupBy(x=>x.Name.Trim(),StringComparer.OrdinalIgnoreCase).Any(g=>g.Count()>1)||remote.Count>0&&!remote.Any(x=>x.Active))throw new IOException("Shared staff list needs review; at least one active staff member is required.");
  var next=Copy();next.Cache=remote;Commit(next);if(idle)ApplyPending();
 }
 public void ApplyPending()
 {
  if(State.Cache.Count==0||State.Pending.Count>0||!State.Cache.Any(x=>x.Active))return;
  var members=State.Cache.Select(x=>new StaffMember{Id=x.Id,Name=x.Name,Active=x.Active}).OrderBy(x=>x.Name).ToList();
  if(Key(_settings.Current.StaffMembers)==Key(members))return;
  _applying=true;
  try{var nextSettings=LocalStorageService.Clone(_settings.Current);nextSettings.StaffMembers=members;_settings.Update(nextSettings);var next=Copy();next.LocalSnapshot=LocalStorageService.Clone(members);Commit(next);LastError=null;}
  catch(Exception ex){LastError=ex.Message;throw;}
  finally{_applying=false;}
 }
 public static void Validate(string id,string name){if(!Guid.TryParseExact(id,"N",out _)||string.IsNullOrWhiteSpace(name)||name.Length>100||name.Any(char.IsControl))throw new IOException("Invalid shared staff record.");}
}
