using AccommodationTestManager.Models;
using System.IO;
namespace AccommodationTestManager.Services;
// Cloud metadata never changes device identity, credentials, machine controls, or an active session.
public sealed class CloudDefaultsCache
{
 private readonly string _path;
 public CloudCache Cache {get;private set;}=new();
 public CloudDefaults? Applied {get;private set;}
 public CloudDefaults? Pending {get;private set;}
 public CloudDefaultsCache(LocalStorageService storage)
 {
  _path=Path.Combine(storage.Root,"CloudSync","directory-cache.json");
  if(File.Exists(_path)) { Cache=LocalStorageService.ReadJson<CloudCache>(_path); if(Cache.Defaults is not null)Validate(Cache.Defaults); Applied=Cache.Defaults; }
 }
 public static void Validate(CloudDefaults d)
 {
  if(d.SchemaVersion!=1||d.Revision<1||d.SaveIntervalSeconds is <10 or >3600||d.SnapshotIntervalSeconds<d.SaveIntervalSeconds||d.SnapshotIntervalSeconds>86400||d.MaximumRecoveryCopies is <1 or >100||d.DefaultTimeLimitMinutes is <1 or >1440)throw new InvalidDataException("Unsupported cloud settings; local settings retained.");
 }
 public void Store(CloudDefaults? defaults,List<CloudSessionRow> rows,DateTimeOffset now,bool idle)
 {
  if(defaults is not null) { Validate(defaults); if(Cache.Defaults is not null && (defaults.Revision<Cache.Defaults.Revision||defaults.Revision==Cache.Defaults.Revision&&defaults!=Cache.Defaults))throw new InvalidDataException("Cloud settings revision conflict; cached settings retained."); }
  var next=new CloudCache {Defaults=defaults??Cache.Defaults,Sessions=rows,LastSyncedUtc=now};
  LocalStorageService.WriteJson(_path,next); Cache=next;
  if(idle){Applied=next.Defaults;Pending=null;}else if(next.Defaults!=Applied)Pending=next.Defaults;
 }
 public void ActivatePending(bool idle){if(idle&&Pending is not null){Applied=Pending;Pending=null;}}
 public AppSettings ApplyTo(AppSettings source)
 {
  var result=LocalStorageService.Clone(source);var d=Applied;if(d is null)return result;
  result.SaveIntervalSeconds=d.SaveIntervalSeconds;result.SnapshotIntervalSeconds=d.SnapshotIntervalSeconds;result.MaximumRecoveryCopies=d.MaximumRecoveryCopies;result.DefaultTimeLimitMinutes=d.DefaultTimeLimitMinutes;return result;
 }
}
