using System;
using System.Runtime.InteropServices;

namespace AccommodationTestManager.Services;

// Word exposes FullScreen on a document window's View, not on Application.
internal static class WordWindowPresentation
{
    public static void ShowNormalMaximized(dynamic application, dynamic document)
    {
        object? window = null;
        object? view = null;
        try
        {
            application.Visible = true;
            document.Activate();
            window = document.ActiveWindow;
            view = ((dynamic)window).View;
            ((dynamic)view).FullScreen = false;
            ((dynamic)window).WindowState = 1; // wdWindowStateMaximize
        }
        finally
        {
            Release(view);
            Release(window);
        }
    }

    private static void Release(object? value)
    {
        if (OperatingSystem.IsWindows() && value is not null && Marshal.IsComObject(value))
            Marshal.ReleaseComObject(value);
    }
}
