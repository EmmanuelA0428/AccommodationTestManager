using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
namespace AccommodationTestManager.Views;
public partial class RecordsWindow:Window
{
 private readonly string _staff;private bool _busy,_loading;private Window? _details;
 private string _sort="Created";private ListSortDirection _direction=ListSortDirection.Descending;
 private List<Row> _rows=[];private SessionEntry? _detailEntry;
 private sealed record Row(string Title,string Laptop,string Mode,string Status,DateTimeOffset Created,DateTimeOffset? Completed,SessionEntry? Local,string DeviceId){public string When=>Created.ToLocalTime().ToString("g");public string CompletedWhen=>Completed?.ToLocalTime().ToString("g")??"—";public string Access=>Laptop;}
 private SessionEntry? Selected=>_detailEntry??(SessionGrid.SelectedItem as Row)?.Local;
 public RecordsWindow(string staff){_staff=staff;InitializeComponent();if(App.Host.CloudSync is not null)App.Host.CloudSync.Changed+=SyncChanged;Closed+=(_,_)=>{if(App.Host.CloudSync is not null)App.Host.CloudSync.Changed-=SyncChanged;};Loaded+=(_,_)=>Reload();}
 private void SyncChanged()=>Dispatcher.BeginInvoke(new Action(Reload));
 private void Reload(){try{_loading=true;var local=App.Host.Storage.ListSessions().Where(x=>!PilotRecordPolicy.IsArchived(x.Session.CreatedUtc,x.Session.CompletedUtc??x.Session.FinishedUtc,x.Session.Status)).ToList();var seen=local.Select(x=>x.Session.DeviceId+"_"+x.Session.Id).ToHashSet();_rows=local.Select(x=>new Row(x.Session.TestName,x.Session.DeviceId==App.Host.Settings.Current.DeviceId?App.Host.Settings.Current.LaptopName:x.Session.LaptopName,x.Session.Mode,x.Session.CancellationRequested&&x.Session.Status!="Cancelled"?"Cancelled — restoration needed":x.Session.Status,x.Session.StartedUtc??x.Session.CreatedUtc,x.Session.CompletedUtc??(x.Session.Status=="Cancelled"?x.Session.FinishedUtc:null),x,x.Session.DeviceId)).ToList();foreach(var remote in App.Host.CloudSync?.Defaults.Cache.Sessions??[]){if(!seen.Contains(remote.DeviceId+"_"+remote.SessionId)&&!PilotRecordPolicy.IsArchived(remote.CreatedAt,remote.EndedAt,remote.Status))_rows.Add(new("Session "+remote.SessionId[..8],remote.Location,remote.Mode,remote.Status,remote.StartedAt??remote.CreatedAt,remote.Status is "Completed" or "Cancelled"?remote.EndedAt:null,null,remote.DeviceId));}SyncStatusText.Text=App.Host.CloudSync?.Status??App.Host.MetadataSyncStatus;ApplyFilter();}catch(Exception e){DetailText.Text=e.Message;}finally{_loading=false;}}
 private void ApplyFilter(){if(SessionGrid is null)return;string query=SearchBox?.Text.Trim()??"";var list=_rows.Where(x=>RecordViewPolicy.IncludeDevice(x.DeviceId,App.Host.Settings.Current.DeviceId,ThisLaptopOnly?.IsChecked==true)&&(query.Length==0||$"{x.Title} {x.Laptop} {x.Mode} {x.Status} {x.When} {x.CompletedWhen}".Contains(query,StringComparison.OrdinalIgnoreCase))).ToList();SessionGrid.ItemsSource=list;var view=System.Windows.Data.CollectionViewSource.GetDefaultView(list);view.SortDescriptions.Add(new(_sort,_direction));view.SortDescriptions.Add(new("Title",ListSortDirection.Ascending));foreach(var c in SessionGrid.Columns){c.SortDirection=c.SortMemberPath==_sort?_direction:null;c.HeaderStyle=SortHeaderStyle(c.SortMemberPath==_sort);}}
 private Style SortHeaderStyle(bool active){var headerType=typeof(System.Windows.Controls.Primitives.DataGridColumnHeader);var style=new Style(headerType,TryFindResource(headerType) as Style);style.Setters.Add(new Setter(FrameworkElement.ToolTipProperty,active?"Sorted column — click to reverse ascending / descending order":"Click to sort ascending; click again for descending"));return style;}
 private void Grid_Sorting(object sender,DataGridSortingEventArgs e){e.Handled=true;_direction=_sort==e.Column.SortMemberPath&&_direction==ListSortDirection.Ascending?ListSortDirection.Descending:ListSortDirection.Ascending;_sort=e.Column.SortMemberPath;_loading=true;try{ApplyFilter();}finally{_loading=false;}}
 private void DeviceFilter_Changed(object sender,RoutedEventArgs e){_loading=true;try{ApplyFilter();}finally{_loading=false;}}
 private void Search_Changed(object sender,TextChangedEventArgs e){_loading=true;try{ApplyFilter();}finally{_loading=false;}}
 private async void Refresh_Click(object sender,RoutedEventArgs e){if(_busy)return;Reload();if(App.Host.CloudSync is not null)await App.Host.CloudSync.SyncAsync();Reload();}
 private void Selection_Changed(object sender,SelectionChangedEventArgs e){if(_loading||_busy||SessionGrid.SelectedItem is not Row row)return;_details?.Close();_detailEntry=row.Local;var panel=new StackPanel{Margin=new Thickness(20)};_details=new Window{Owner=this,Title="Test details",Width=480,SizeToContent=SizeToContent.Height,WindowStartupLocation=WindowStartupLocation.CenterOwner,Content=panel};panel.Children.Add(new TextBlock{Text=$"{row.Title}\n{row.Laptop} · {row.When}\n{row.Mode} · {row.Status}",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,14)});if(row.Local is null){panel.Children.Add(new TextBlock{Text="Open this test in its original Windows testing account on its original laptop. Files are not synced.",TextWrapping=TextWrapping.Wrap});}else{var s=row.Local.Session;void Add(string name,RoutedEventHandler click){var b=new Button{Content=name,MinHeight=40,Margin=new Thickness(0,0,0,6)};b.Click+=click;panel.Children.Add(b);}Add("Open test location",OpenFolder_Click);if(s.Status is not ("Completed" or "Cancelled")&&!s.CancellationRequested&&App.Host.Sessions.Current is null)Add("Recover Test",Recover_Click);if(s.Status is "Completed" or "Cancelled"&&(!string.IsNullOrWhiteSpace(s.WorkingRelativePath)||!string.IsNullOrWhiteSpace(s.FinalRelativePath)))Add("Open Test",OpenTest_Click);if(s.Status=="Completed"&&!string.IsNullOrWhiteSpace(s.FinalRelativePath))Add("Export Test",ReExport_Click);if(s.Status is not ("Completed" or "Cancelled"))Add(s.CancellationRequested?"Retry restoration":"Cancel Test",Cancel_Click);if(s.DeviceId==App.Host.Settings.Current.DeviceId&&(s.Status is "Completed" or "Cancelled"))Add("Delete Test",Delete_Click);if(s.Status=="NeedsReview"){var warning=new TextBlock{Text="Session metadata needs advanced repair before normal recovery.",TextWrapping=TextWrapping.Wrap};panel.Children.Add(warning);var tools=new StackPanel();var restore=new Button{Content="Restore metadata backup",MinHeight=40};restore.Click+=RestoreBackup_Click;tools.Children.Add(restore);panel.Children.Add(new Expander{Header="Advanced recovery",Content=tools});}}_details.Closing+=(_,args)=>{if(_busy&&!App.Host.IsUpdateShutdown)args.Cancel=true;};_details.ShowDialog();_detailEntry=null;}
 private async void Recover_Click(object sender,RoutedEventArgs e){if(Selected is not SessionEntry entry||_busy)return;_busy=true;try{await App.Host.Sessions.AdoptAsync(entry,_staff);_busy=false;_details?.Close();DialogResult=true;}catch(Exception ex){ShowError(ex.Message);}finally{_busy=false;}}
 private async void Cancel_Click(object sender,RoutedEventArgs e){if(Selected is not SessionEntry entry||_busy)return;string staff=_staff;if(MessageBox.Show(_details??this,"Cancel this test? Saved local work is kept and laptop settings restored. Save/submit website work first if needed.","Cancel test",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;_busy=true;try{bool activeHere=App.Host.Sessions.Current?.Id==entry.Session.Id;await App.Host.Sessions.CancelStoredAsync(entry,staff,true);if(activeHere)try{await new SpeechToTextService().StopInCurrentSessionAsync();}catch(Exception ex){MessageBox.Show(_details??this,"The test was cancelled, but Voice Access did not close. Close it manually.\n\n"+ex.Message,"Voice Access",MessageBoxButton.OK,MessageBoxImage.Warning);}_busy=false;_details?.Close();DetailText.Text="Test cancelled. Saved files kept.";}catch(Exception ex){ShowError(ex.Message);}finally{_busy=false;Reload();}}
 private async void Delete_Click(object sender,RoutedEventArgs e)
 {
  if(Selected is not SessionEntry entry||_busy)return;
  if(MessageBox.Show(_details??this,"Permanently delete this test and its saved working files, checkpoints and recovery copies from this laptop? This cannot be undone. Copies already exported elsewhere are not removed.","Delete test permanently",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
  _busy=true;
  try{
   string state=App.Host.Restrictions.Status(entry.Session.Id);
   App.Host.TestDeletions.DeleteLocal(entry,App.Host.Settings.Current.DeviceId,App.Host.Sessions.Current is not null||App.Host.Sessions.IsBusy,state);
   if(App.Host.CloudSync is not null)await App.Host.CloudSync.SyncAsync();
   bool pending=App.Host.TestDeletions.Ready(App.Host.Settings.Current.DeviceId).Any(x=>x.SessionId==entry.Session.Id);
   _busy=false;_details?.Close();DetailText.Text=pending?"Local files deleted. Shared record removal is queued until cloud sync succeeds.":"Test and its local files deleted; shared record removal synced.";
  }catch(Exception ex){ShowError(ex.Message);}finally{_busy=false;Reload();}
 }
 private void OpenTest_Click(object sender,RoutedEventArgs e){try{if(Selected is not SessionEntry entry)return;string relative=!string.IsNullOrWhiteSpace(entry.Session.FinalRelativePath)?entry.Session.FinalRelativePath:entry.Session.WorkingRelativePath;string file=App.Host.Storage.FileInSession(entry.Folder,relative);if(!File.Exists(file))throw new IOException("The saved test file is missing. Open test location to check the folder.");if(!new[]{".doc",".docx",".pdf",".txt",".rtf"}.Contains(Path.GetExtension(file).ToLowerInvariant()))throw new IOException("Open this file through staff recovery.");Process.Start(new ProcessStartInfo(file){UseShellExecute=true});}catch(Exception ex){ShowError(ex.Message);}}
    private async void ReExport_Click(object sender,RoutedEventArgs e)
    {
        if(Selected is not SessionEntry entry||_busy)return;
        var dialog=new SaveFileDialog{Title="Export another verified copy",FileName=$"CompletedExam-{entry.Session.Id[..8]}{Path.GetExtension(entry.Session.FinalRelativePath)}",Filter=$"Completed document|*{Path.GetExtension(entry.Session.FinalRelativePath)}",OverwritePrompt=true};
        if(dialog.ShowDialog(this)!=true)return;
        _busy=true;
        try
        {
            string final=App.Host.Storage.FileInSession(entry.Folder,entry.Session.FinalRelativePath);
            if(LocalStorageService.HashFile(final)!=entry.Session.FinalSha256)throw new IOException("Final hash changed; staff review required.");
            if(File.Exists(dialog.FileName))throw new IOException("Choose a new filename. Existing files are not overwritten.");
            if(Path.GetFullPath(dialog.FileName).StartsWith(Path.GetFullPath(App.Host.Storage.Root)+Path.DirectorySeparatorChar,StringComparison.OrdinalIgnoreCase))throw new IOException("Export outside app storage.");
            string hash=await Task.Run(()=>LocalStorageService.CopyVerified(final,dialog.FileName));
            var record=LocalStorageService.ReadJson<TestSession>(Path.Combine(entry.Folder,"session.json"));
            record.Events.Add(new(Guid.NewGuid().ToString("N"),DateTimeOffset.UtcNow,"Additional export verified",_staff,dialog.FileName+" | "+hash));
            LocalStorageService.WriteJson(Path.Combine(entry.Folder,"session.json"),record);
            DetailText.Text="Additional export verified. Original receipt retained. Safely eject the drive in Windows.";
        }
        catch(Exception ex){ShowError(ex.Message);}
        finally{_busy=false;}
    }

 private void ShowError(string message){DetailText.Text=message;MessageBox.Show(_details is {IsVisible:true}?_details:this,message,"Action did not complete",MessageBoxButton.OK,MessageBoxImage.Warning);}
 private void OpenFolder_Click(object sender,RoutedEventArgs e){try{if(Selected is not SessionEntry entry)return;App.Host.Storage.EnsureSessionFolder(entry.Folder);if(!Directory.Exists(entry.Folder))throw new IOException("The test folder is missing on this laptop.");Process.Start(new ProcessStartInfo(entry.Folder){UseShellExecute=true});}catch(Exception ex){ShowError(ex.Message);}}
 private void RestoreBackup_Click(object sender,RoutedEventArgs e){if(_busy||Selected is not SessionEntry entry)return;if(MessageBox.Show(_details??this,"Restore metadata backup? Existing metadata is preserved. Review the recovered test before resuming.","Advanced recovery",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;try{App.Host.Storage.RestoreMetadataBackup(entry,_staff);_details?.Close();Reload();}catch(Exception ex){ShowError(ex.Message);}}
 protected override void OnClosing(CancelEventArgs e){if(_busy&&!App.Host.IsUpdateShutdown)e.Cancel=true;base.OnClosing(e);}
}
