using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;
namespace AccommodationTestManager.Views;
// Click-through overlays only: never reads/modifies exam content, captures keys, or changes Windows settings.
public sealed class VisualSupportWindow:Window
{
 [StructLayout(LayoutKind.Sequential)]private struct Point{public int X,Y;}
 [DllImport("user32.dll")]private static extern bool GetCursorPos(out Point point);
 [DllImport("user32.dll",EntryPoint="GetWindowLongPtrW")]private static extern nint GetWindowLongPtr(nint h,int n);
 [DllImport("user32.dll",EntryPoint="SetWindowLongPtrW")]private static extern nint SetWindowLongPtr(nint h,int n,nint v);
 [DllImport("user32.dll")]private static extern bool SetWindowPos(nint h,nint after,int x,int y,int cx,int cy,uint flags);
 private readonly Canvas _canvas=new(){IsHitTestVisible=false};private readonly Rectangle _line=new(){Height=3,Fill=Brushes.DarkSlateBlue,Opacity=.8};
 private readonly DispatcherTimer _timer=new(){Interval=TimeSpan.FromMilliseconds(80)};
 private bool _guide,_tint;public bool Guide {get=>_guide;set{_guide=value;RefreshAppearance();}}public bool Tint {get=>_tint;set{_tint=value;RefreshAppearance();}}public double GuideOffset {get;set;}=8;
 private void RefreshAppearance(){Background=Tint?new SolidColorBrush(Color.FromArgb(28,255,229,145)):Brushes.Transparent;_line.Visibility=Guide?Visibility.Visible:Visibility.Collapsed;}
 public VisualSupportWindow()
 {
  Title="Session visual supports";WindowStyle=WindowStyle.None;ResizeMode=ResizeMode.NoResize;ShowInTaskbar=false;ShowActivated=false;AllowsTransparency=true;Background=Brushes.Transparent;IsHitTestVisible=false;Focusable=false;Topmost=true;
  _canvas.Children.Add(_line);Content=_canvas;SourceInitialized+=(_,_)=>{nint h=new WindowInteropHelper(this).Handle;SetWindowLongPtr(h,-20,(nint)((long)GetWindowLongPtr(h,-20)|0x20|0x80000|0x8000000|0x80));};_timer.Tick+=Tick;_timer.Start();Closed+=(_,_)=>_timer.Stop();
 }
 public void UpdateBounds(nint target)
 {
  if(target==0||!GetWindowRect(target,out var r))return;
  var transform=PresentationSource.FromVisual(this)?.CompositionTarget?.TransformFromDevice??Matrix.Identity;var top=transform.Transform(new System.Windows.Point(r.Left,r.Top));var bottom=transform.Transform(new System.Windows.Point(r.Right,r.Bottom));Left=top.X;Top=top.Y;Width=Math.Max(1,bottom.X-top.X);Height=Math.Max(1,bottom.Y-top.Y);
  _line.Width=Width;RefreshAppearance();
  nint h=new WindowInteropHelper(this).Handle;SetWindowPos(h,-1,0,0,0,0,0x13);
 }
 [StructLayout(LayoutKind.Sequential)]private struct Rect{public int Left,Top,Right,Bottom;}
 [DllImport("user32.dll")]private static extern bool GetWindowRect(nint window,out Rect rect);
 private void Tick(object? sender,EventArgs e){if(!Guide||!GetCursorPos(out var p))return;var transform=PresentationSource.FromVisual(this)?.CompositionTarget?.TransformFromDevice??Matrix.Identity;var at=transform.Transform(new System.Windows.Point(p.X,p.Y));Canvas.SetTop(_line,Math.Clamp(at.Y-Top+GuideOffset,0,Math.Max(0,Height-3)));}
}
