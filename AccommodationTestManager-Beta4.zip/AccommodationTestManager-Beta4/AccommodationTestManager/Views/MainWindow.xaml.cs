using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using AccommodationTestManager.Views.Setup;
using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace AccommodationTestManager.Views;
public partial class MainWindow : Window
{
    private readonly TestSetupDraft _draft = new();
    private readonly string[] _steps = ["Student", "Test", "Supports", "Review"];
    private readonly HashSet<int> _completed = [];
    private readonly UserControl[] _pages;
    private readonly Button[] _navigation;
    private int _step;
    private bool _operation;
    private bool _startingOperation;
    private string? _sessionStaff, _sessionAuthId;
    private DateTimeOffset _sessionAuthUntil;
    private string _pinVersion = "";
    private string CurrentPinVersion()=>App.Host.Settings.Current.StaffPinSalt+":"+App.Host.Settings.Current.StaffPinHash;
    private void ClearSessionAuthorization(){_sessionStaff=null;_sessionAuthId=null;_sessionAuthUntil=default;}
    public void AuthorizeCurrentSession(string staff){_sessionStaff=staff;_sessionAuthId=Sessions.Current?.Id;_sessionAuthUntil=DateTimeOffset.UtcNow.AddMinutes(25);_pinVersion=CurrentPinVersion();}
    private string? SessionStaff(string title)
    {
        if(_sessionAuthId==Sessions.Current?.Id&&_sessionStaff is not null&&DateTimeOffset.UtcNow<_sessionAuthUntil&&_pinVersion==CurrentPinVersion())return _sessionStaff;
        ClearSessionAuthorization();var staff=StaffDialogs.Authorize(this,App.Host.Settings,title,Sessions.Current?.StartedBy);
        if(staff is not null)AuthorizeCurrentSession(staff);return staff;
    }
    private bool _handoffQueued;
    private string? _authorizedHandoffId;
    private AwaitingStaffWindow? _handoffWindow;
    private SetupReadiness _readiness=SetupReadiness.Evaluate(0,false);
    private FeatureTestWindow? _featureWindow;
    private StudentTestWindow? _studentWindow;
    private readonly TestWindowFocusService _focus;
    private VisualSupportWindow? _visualSupports;
    private string? _supportSession;private bool _guideEnabled,_tintEnabled;
    public void SuspendForStaffAuthorization()=>_focus.SuspendForStaff();
    public void OpenStaffControls(string staff){AuthorizeCurrentSession(staff);_focus.SuspendForStaff();Show();WindowState=WindowState.Normal;Activate();}
    public void ReturnToStudent(){ClearSessionAuthorization();_focus.StaffMode=false;Hide();ShowStudent();}
    public void ToggleGuide(bool enabled){InitializeVisualChoices();_guideEnabled=enabled;if(_visualSupports is not null)_visualSupports.Guide=enabled;}
    public void ToggleTint(bool enabled){InitializeVisualChoices();_tintEnabled=enabled;if(_visualSupports is not null)_visualSupports.Tint=enabled;}
    private void InitializeVisualChoices(){var s=Sessions.Current;if(_supportSession==s?.Id)return;_visualSupports?.Close();_visualSupports=null;_supportSession=s?.Id;_guideEnabled=false;_tintEnabled=false;}
    private SessionService Sessions => App.Host.Sessions;
    public MainWindow()
    {
        InitializeComponent();
        Microsoft.Win32.SystemEvents.SessionSwitch+=WindowsSessionChanged;
        Closed+=(_,_)=>Microsoft.Win32.SystemEvents.SessionSwitch-=WindowsSessionChanged;
        var syncTimer=new System.Windows.Threading.DispatcherTimer{Interval=TimeSpan.FromSeconds(2)};
        syncTimer.Tick+=(_,_)=>UpdateSyncIndicator();syncTimer.Start();Closed+=(_,_)=>syncTimer.Stop();
        Loaded+=(_,_)=>{App.Host.Settings.Saved+=StaffSettingsChanged;UpdateSyncIndicator();};Closed+=(_,_)=>App.Host.Settings.Saved-=StaffSettingsChanged;

        _focus=new(Sessions.GetTestWindowAsync,()=>Sessions.Current?.Status=="Active"&&!Sessions.IsBusy&&(Sessions.Current.Mode=="Word"||Sessions.IsOnline));
        _focus.ShowVisualSupports=target=>{var session=Sessions.Current;if(session is null)return;InitializeVisualChoices();if(_visualSupports is null&&(_guideEnabled||_tintEnabled)){_visualSupports=new(){Guide=_guideEnabled,Tint=_tintEnabled};}if(_visualSupports is not null){if(!_visualSupports.IsVisible)_visualSupports.Show();_visualSupports.UpdateBounds(target);}};
        _focus.HideVisualSupports=()=>_visualSupports?.Hide();
        _focus.IsStudentWindow=h=>_studentWindow is {IsVisible:true}&&new System.Windows.Interop.WindowInteropHelper(_studentWindow).Handle==h;
        _focus.KeepControlsAbove=()=>{if(_studentWindow is {IsVisible:true})TestWindowFocusService.RaiseControls(new System.Windows.Interop.WindowInteropHelper(_studentWindow).Handle);};
        Closed+=(_,_)=>{_focus.Dispose();_visualSupports?.Close();};
        _draft.StaffChoices = App.Host.Settings.Current.StaffNames;
        _draft.ApplicationChoices=App.Host.Settings.Current.ApprovedApplications;
        _draft.AllowlistChoices=App.Host.Allowlists.LoadAll().Select(x=>x.Id).ToArray();
        Sessions.ConfirmRemoveStorage=()=>Task.FromResult(MessageBox.Show(this,"Remove USB storage drives before starting.","Before machine restrictions",MessageBoxButton.OKCancel,MessageBoxImage.Warning)==MessageBoxResult.OK);
        _draft.UseTimeLimit = false;
        _draft.DurationText = (App.Host.Settings.Effective.DefaultTimeLimitMinutes ?? 90).ToString();
        _pages = [new StudentStepView(), new TestStepView(), new SupportsStepView(), new ReviewStepView()];
        _navigation = [StudentNav, TestNav, SupportsNav, ReviewNav];
        foreach (UserControl page in _pages) page.DataContext = _draft;

        _draft.PropertyChanged += DraftChanged;
        Sessions.Changed += SessionChanged;
        Refresh();
    }
    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        Rect work = SystemParameters.WorkArea;
        Width = Math.Min(1040, work.Width - 48); Height = Math.Min(680, work.Height - 48);
        Left = work.Left + (work.Width - Width) / 2; Top = work.Top + (work.Height - Height) / 2; AdaptLayout();
        RecheckSetupReadiness();Refresh();QueueStaffHandoff();
        _ = CheckStartupUpdateAsync();
        EnsureStudentControls();
        if(App.Host.CloudSync is not null)
            App.Host.CloudSync.Changed+=()=>Dispatcher.BeginInvoke(new Action(()=>{GlobalConfigStatus.Text=App.Host.GlobalConfig.Status+"\n"+App.Host.CloudSync.Status;Refresh();}));
        if(App.Host.GlobalConfig is not null)
        {
            App.Host.GlobalConfig.Changed=()=>Dispatcher.BeginInvoke(new Action(()=> { GlobalConfigStatus.Text=(App.Host.Settings.Current.GlobalConfigEnabled?App.Host.GlobalConfig.Status:"Global configuration disabled; local settings active.")+"\n"+App.Host.MetadataSyncStatus;Refresh(); }));
            GlobalConfigStatus.Text=App.Host.Settings.Current.GlobalConfigEnabled?App.Host.GlobalConfig.Status:"Global configuration disabled; local settings active.";
            if(App.Host.Settings.Current.GlobalConfigEnabled)await App.Host.GlobalConfig.RefreshAsync();
        }
    }
    private async Task CheckStartupUpdateAsync()
    {
        using var updates=new UpdateService(App.Host.Storage,Sessions,App.Host.Restrictions);
        using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(8));
        try
        {
            var available=await updates.CheckAsync(timeout.Token);
            if(IsLoaded){UpdateAvailableButton.Visibility=available is null?Visibility.Collapsed:Visibility.Visible;UpdateAvailableButton.ToolTip=available is null?null:"Install "+available.Version;StartupUpdateStatus.Text=available is null?"No newer compatible release found.":"Update available: "+available.Version+" · Open Settings → Updates to download.";}
        }
        catch(Exception){if(IsLoaded)StartupUpdateStatus.Text="Update check unavailable · retry in Settings → Updates. Testing remains available.";}
    }
    private void UpdateAvailable_Click(object sender,RoutedEventArgs e)
    {
        if(_operation||Sessions.IsBusy)return;
        var staff=StaffDialogs.Authorize(this,App.Host.Settings,"Install update");if(staff is null)return;
        new SettingsWindow(staff,true){Owner=this}.ShowDialog();_ = CheckStartupUpdateAsync();
    }
    private void EnsureStudentControls()
    {
        InitializeVisualChoices();
        if(Sessions.Current?.Status=="Active"||Sessions.Current?.Status=="Preflight"&&(Sessions.Current.SettingsSnapshot.ManualPreflightChecks||Sessions.IsOnline))ShowStudent();
        else if (_studentWindow is { IsVisible: true } && Sessions.Current?.Status is null or "AwaitingStaff" or "ExportPending" or "Completing" or "Completed" or "Cancelled")
        { _studentWindow.AllowStaffClose = true; _studentWindow.Close(); }
    }
    private void RecheckSetupReadiness()
    {
        try { _readiness=SetupReadiness.Evaluate(App.Host.Storage.ListSessions(true).Count,App.Host.Restrictions.PendingIds().Count>0||App.Host.Restrictions.NeedsLegacyReview()); }
        catch(Exception ex){_readiness=SetupReadiness.Evaluate(0,false,ex.Message);}
    }
    private void Window_SizeChanged(object sender, SizeChangedEventArgs e) { if (IsLoaded) AdaptLayout(); }
    private void AdaptLayout()
    {
        NextButton.Content = _step == 3 ? "Start test" : ActualWidth < 600 ? "Next →" : $"Continue to {_steps[_step + 1]} →";
        bool wide = ActualWidth >= 1000, narrow = ActualWidth < 760;
        NavigationColumn.Width = new GridLength(narrow ? 0 : 160); NavigationPanel.Visibility = narrow ? Visibility.Collapsed : Visibility.Visible;
        SummaryColumn.Width = new GridLength(wide ? 224 : 0); SummaryPanel.Visibility = wide ? Visibility.Visible : Visibility.Collapsed;
        CompactSummary.Visibility = wide ? Visibility.Collapsed : Visibility.Visible;
    }
    private void DraftChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName == nameof(TestSetupDraft.Preset))
            _draft.CustomUrl = _draft.Preset == "Canvas" ? App.Host.Settings.Effective.CanvasUrl : _draft.Preset == "Posit" ? App.Host.Settings.Effective.PositUrl : "";
        int affected = e.PropertyName switch
        {
            nameof(TestSetupDraft.StudentName) or nameof(TestSetupDraft.TestName) or nameof(TestSetupDraft.StaffName) => 0,
            nameof(TestSetupDraft.Preset) or nameof(TestSetupDraft.DocumentPath) or nameof(TestSetupDraft.DurationText) or nameof(TestSetupDraft.UseTimeLimit) or nameof(TestSetupDraft.CustomUrl) => 1,
            nameof(TestSetupDraft.TextToSpeech) or nameof(TestSetupDraft.SpeechToText) or nameof(TestSetupDraft.ReadingGuide) or nameof(TestSetupDraft.ScreenTint) or nameof(TestSetupDraft.LargeControls) => 2, _ => 3
        };
        _completed.RemoveWhere(step => step >= affected); Refresh();
    }
    private void Refresh()
    {
        ((TestStepView)_pages[1]).Refresh();  StepHost.Content = _pages[_step];
        StepCounter.Text = $"Step {_step+1} of 4 · {_steps[_step]}";
        BackButton.IsEnabled = !_operation && _step>0 && Sessions.Current is null;
        NextButton.IsEnabled = _readiness.CanContinue(_step,_operation||Sessions.IsBusy,Sessions.Current is not null);
        SetupBlockBanner.Visibility=_readiness.Blocked&&Sessions.Current is null?Visibility.Visible:Visibility.Collapsed;
        SetupBlockText.Text=_readiness.Reason;
        SetupRecoveryButton.Visibility=_readiness.UnfinishedCount>0?Visibility.Visible:Visibility.Collapsed;
        SetupMachineButton.Visibility=_readiness.MachinePending?Visibility.Visible:Visibility.Collapsed;
        NextButton.ToolTip=_step==3&&_readiness.Blocked?_readiness.Reason:"Continue through setup; required fields are checked when you click.";
        for (int i=0;i<_navigation.Length;i++)
        { _navigation[i].Content=$"{i+1}. {_steps[i]}"+(i==_step?" · Current":_completed.Contains(i)?" ✓":""); _navigation[i].IsEnabled=!_operation&&(i<=_step||_completed.Contains(i)); }
        SummaryStudent.Text=Filled(_draft.StudentName); SummaryTest.Text=Filled(_draft.TestName);
        SummaryMode.Text=_draft.Preset;
        SummaryDocument.Text=_draft.Preset=="Word"?string.IsNullOrWhiteSpace(_draft.DocumentPath)?"Not selected":Path.GetFileName(_draft.DocumentPath):_draft.CustomUrl;
        SummarySupports.Text=string.Join(", ",new[]{_draft.TextToSpeech?"Text-to-speech":"",_draft.SpeechToText?"Speech-to-text":"",_draft.ReadingGuide?"Reading guide":"",_draft.ScreenTint?"Screen tint":"",_draft.LargeControls?"Larger controls":""}.Where(x=>x.Length>0));
        string summary=$"Staff: {Filled(_draft.StaffName)}\nLaptop: {App.Host.Settings.Current.LaptopName}\nStudent: {SummaryStudent.Text}\nTest: {SummaryTest.Text}\nMode: {SummaryMode.Text}\nDocument/site: {SummaryDocument.Text}\nSupports: {SummarySupports.Text}";
        CompactSummaryText.Text=summary; ((ReviewStepView)_pages[3]).ReviewText.Text=summary;
        RefreshSession(); if(IsLoaded)AdaptLayout();
    }
    private static string Filled(string value)=>string.IsNullOrWhiteSpace(value)?"Not entered":value.Trim();
    private string? Validate(int step)
    {
        if(step==0 && (string.IsNullOrWhiteSpace(_draft.StudentName)||string.IsNullOrWhiteSpace(_draft.TestName)||!App.Host.Settings.Current.StaffNames.Contains(_draft.StaffName)))return "Enter student/test names and select staff.";
        if(step==1)
        {
            if(_draft.UseTimeLimit && (!int.TryParse(_draft.DurationText,out int value)||value<1||value>1440))return "Time limit must be 1–1440 minutes, or turn it off.";
            if(_draft.Preset=="Word" && (!File.Exists(_draft.DocumentPath)||Path.GetExtension(_draft.DocumentPath).ToLowerInvariant() is not (".doc" or ".docx")))return "Choose an existing Word document.";
            bool online=_draft.Preset is "Canvas" or "Posit"||_draft.Preset=="Custom"&&_draft.CustomKind=="Website";
            if(online)
            {
                string site=_draft.Preset=="Canvas"?App.Host.Settings.Effective.CanvasUrl:_draft.Preset=="Posit"?App.Host.Settings.Effective.PositUrl:_draft.CustomUrl;
                string id=_draft.Preset=="Canvas"?"canvas":_draft.Preset=="Posit"?"posit":_draft.AllowlistId;
                try{if(!AllowlistService.AllowsStart(App.Host.Allowlists.Load(id),site))return "Starting page is outside its allowlist; configure in Settings.";}catch(Exception ex){return ex.Message;}
            }
            if(_draft.Preset=="Custom"&&_draft.CustomKind=="Desktop"&&_draft.SelectedApplication is null)return "Choose an approved desktop app (add it in Settings).";
        }
        return null;
    }
    private async void Next_Click(object sender,RoutedEventArgs e)
    {
        if(_operation||Sessions.IsBusy)return;
        App.Host.GlobalConfig?.ActivatePending();
        if(Sessions.Current is not null){Refresh();return;}
        if(_step==3){RecheckSetupReadiness();if(_readiness.Blocked){Refresh();ValidationText.Text=_readiness.Reason;return;}}
        for(int i=0;i<=_step;i++)if(Validate(i) is string error){_step=i;Refresh();ValidationText.Text=error;return;}
        if(_step<3){_completed.Add(_step);_step++;ValidationText.Text="";Refresh();return;}
        if(_featureWindow is {IsVisible:true} || _studentWindow is {IsVisible:true}) { MessageBox.Show(this,"Close feature-testing/preview windows before starting a session."); return; }
        string? staff=StaffDialogs.Authorize(this,App.Host.Settings,"Authorize Start Test",_draft.StaffName);if(staff is null)return;
        _draft.StaffName=staff;
        await Operation(async()=> { _startingOperation=true;try{if(!await CloseEdgeForStartAsync())return;await Sessions.StartAsync(_draft);_focus.StaffMode=false;EnsureStudentControls();if(Sessions.Current?.Status=="Active")ReturnToStudent();}finally{_startingOperation=false;} },"Preparing test…");
    }
    private async Task<bool> CloseEdgeForStartAsync()
    {
        bool online=_draft.Preset is "Canvas" or "Posit" || _draft.Preset=="Custom"&&_draft.CustomKind=="Website";
        if(!online||!App.Host.Settings.Current.RequireMachineRestrictions)return true;
        using var current=Process.GetCurrentProcess();
        async Task<bool> ConfirmForceAsync(bool all)
        {
            string message=all
                ? "Edge is running in another Windows session. Close Edge for ALL users and start? Unsaved browser work and downloads in any session may be lost."
                : "Edge did not fully exit. Force-close Edge in this Windows session? Unsaved browser work and downloads may be lost.";
            if(MessageBox.Show(this,message,"Close Edge",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return false;
            await MachineBrokerClient.CloseEdge(all?"all":"current");return true;
        }
        var initial=Process.GetProcessesByName("msedge");
        try{
            if(initial.Length==0)return true;
            if(initial.Any(p=>p.SessionId!=current.SessionId))return await ConfirmForceAsync(true);
        }finally{foreach(var p in initial)p.Dispose();}
        if(MessageBox.Show(this,"Save your browser work, then close Edge to start the test?","Close Edge and start",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return false;
        var requested=new HashSet<nint>();var deadline=DateTime.UtcNow.AddSeconds(10);
        do{
            var processes=Process.GetProcessesByName("msedge");
            try{
                if(processes.Length==0)return true;
                if(processes.Any(p=>p.SessionId!=current.SessionId))return await ConfirmForceAsync(true);
                foreach(var p in processes){if(p.HasExited)continue;nint window=p.MainWindowHandle;if(window!=0&&requested.Add(window))p.CloseMainWindow();}
            }finally{foreach(var p in processes)p.Dispose();}
            await Task.Delay(250);
        }while(DateTime.UtcNow<deadline);
        return await ConfirmForceAsync(false);
    }
    private void RecheckStatus_Click(object sender,RoutedEventArgs e){RecheckSetupReadiness();Refresh();}
    private void Back_Click(object sender,RoutedEventArgs e){_step=Math.Max(0,_step-1);ValidationText.Text="";Refresh();}
    private void Step_Click(object sender,RoutedEventArgs e){_step=int.Parse((string)((Button)sender).Tag);ValidationText.Text="";Refresh();}
    private async Task Operation(Func<Task> action,string caption="Please wait…")
    {
        if(_operation)return;_operation=true;BusyCaption.Text=caption;BusyOverlay.Visibility=Visibility.Visible;Refresh();await Dispatcher.InvokeAsync(()=>{},System.Windows.Threading.DispatcherPriority.Render);
        try{await action();SessionActionText.Text="";}
        catch(Exception ex){ClearSessionAuthorization();SessionActionText.Text=ex.Message;ValidationText.Text=ex.Message;MessageBox.Show(this,ex.Message,"Action did not complete",MessageBoxButton.OK,MessageBoxImage.Warning);}
        finally{_operation=false;BusyOverlay.Visibility=Visibility.Collapsed;RecheckSetupReadiness();Refresh();}
    }
    private void SessionChanged(object? sender,string message)
    {
        if(_startingOperation && StartupProgress.CaptionFor(message, Sessions.Current?.Mode) is string caption)
            BusyCaption.Text=caption;
        if(Sessions.Current?.Status!="AwaitingStaff")_authorizedHandoffId=null;
        if(_sessionAuthId!=Sessions.Current?.Id||Sessions.Current?.Status is "Completed" or "Cancelled")ClearSessionAuthorization();
        RefreshSession();QueueStaffHandoff();
        Dispatcher.BeginInvoke(new Action(EnsureStudentControls));
    }
    private void QueueStaffHandoff()
    {
        if(!IsLoaded||_handoffQueued||_handoffWindow is not null||Sessions.Current?.Status!="AwaitingStaff"||_authorizedHandoffId==Sessions.Current.Id)return;
        _handoffQueued=true;
        Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,new Action(async()=>
        {
            _handoffQueued=false;
            if(Sessions.Current?.Status!="AwaitingStaff"||_authorizedHandoffId==Sessions.Current.Id)return;
            Show();WindowState=WindowState.Normal;Activate();
            _handoffWindow=new AwaitingStaffWindow{Owner=this};
            string? staff=null;
            try{_handoffWindow.ShowDialog();staff=_handoffWindow.AuthorizedStaff;}finally{_handoffWindow=null;}
            if(staff is null)return;
            _authorizedHandoffId=Sessions.Current?.Id;
            try{await Sessions.RecordStaffHandoffAsync(staff);AuthorizeCurrentSession(staff);}catch(Exception ex){_authorizedHandoffId=null;MessageBox.Show(this,ex.Message,"Handoff not recorded");QueueStaffHandoff();}
            if(_studentWindow is {IsVisible:true}){_studentWindow.AllowStaffClose=true;_studentWindow.Close();}
            RefreshSession();Activate();
        }));
    }
    private void Diagnostics_Click(object sender,RoutedEventArgs e)=>new DiagnosticsWindow(Sessions.Current?.Id){Owner=this}.ShowDialog();
    private void RefreshSession()
    {
        var s=Sessions.Current;SetupFooter.Visibility=s is null?Visibility.Visible:Visibility.Collapsed;BodyGrid.Visibility=s is null?Visibility.Visible:Visibility.Collapsed;SessionPanel.Visibility=s is null||s.Status=="AwaitingStaff"&&_authorizedHandoffId!=s.Id?Visibility.Collapsed:Visibility.Visible;
        if(s is null)return;
        CurrentSessionText.Text=$"{s.TestName} · {s.StudentName}\nStaff: {s.StartedBy} · Laptop: {s.LaptopName}\nMode: {s.Mode}\nStatus: {s.Status}\nSave: {s.LastSaveHealth}";
        bool available=!_operation;
        ResumeSessionButton.IsEnabled=available&&s.Status is "Active" or "AwaitingStaff" or "Starting" or "Preflight" or "RecoveryRequired";
        ConfirmPreflightButton.Visibility=s.Status=="Preflight"&&s.SettingsSnapshot.ManualPreflightChecks?Visibility.Visible:Visibility.Collapsed;ConfirmPreflightButton.IsEnabled=available;
        ExportSessionButton.IsEnabled=available&&s.Status is "AwaitingStaff" or "ExportPending" or "Completing";
        ExportSessionButton.Content=s.Mode=="Word"||s.Mode=="Custom"&&s.CustomKind=="Desktop"?"Export & Complete":"Verify & Complete";
        CancelPreparationButton.Content=s.CancellationRequested?"Retry restoration":"Cancel Test";
        CancelPreparationButton.Visibility=s.Status is not ("Completed" or "Cancelled")?Visibility.Visible:Visibility.Collapsed;CancelPreparationButton.IsEnabled=available;
        RestoreWorkingButton.IsEnabled=available&&s.Mode=="Word"&&s.Status is "Active" or "AwaitingStaff" or "Starting" or "Preflight" or "RecoveryRequired";
        ShowStudentButton.IsEnabled=available&&s.Status=="Active";
        SessionHistory.Text=string.Join("\n",s.Events.TakeLast(40).Select(x=>$"{x.AtUtc.ToLocalTime():g} · {x.Action} · {x.Staff}"));
    }
    private void ShowStudent()
    {
        if(_studentWindow is {IsVisible:true}){if(_studentWindow.WindowState==WindowState.Minimized)_studentWindow.WindowState=WindowState.Normal;_studentWindow.Activate();return;}
        // A live toolbar must not disappear when the staff window is minimized.
        _studentWindow=new StudentTestWindow(preview:false);_studentWindow.Show();_studentWindow.Activate();
    }
    private void ShowStudent_Click(object sender,RoutedEventArgs e){if(Sessions.Current?.Status=="Active")ReturnToStudent();else ShowStudent();}
    private async void ResumeSession_Click(object sender,RoutedEventArgs e)
    {
        string? staff=SessionStaff("Resume test");if(staff is null)return;
        await Operation(async()=>{await Sessions.ResumeAsync(staff);_focus.StaffMode=false;if(Sessions.Current?.Status=="Active")ReturnToStudent();});
    }
    private async void RestoreWorking_Click(object sender,RoutedEventArgs e)
    {
        string? staff=StaffDialogs.Authorize(this,App.Host.Settings,"Restore a verified recovery copy");if(staff is null)return;
        if(MessageBox.Show(this,"Restore the newest remaining recovery copy that matches its recorded hash? Existing working files are preserved. Save/close any disconnected Word windows first. Review the restored document before continuing.","Recover working copy",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        await Operation(async()=>await Sessions.RecoverLatestWorkingCopyAsync(staff));
    }
    private async void ExportSession_Click(object sender,RoutedEventArgs e)
    {
        if(_operation||Sessions.Current is null)return;
        string? staff=SessionStaff("Export & complete");if(staff is null)return;
        await Operation(async()=>
        {
            var s=Sessions.Current!;
            if(Sessions.IsOnline)
            {
                if(MessageBox.Show(this,"Have you personally verified that this test was saved/submitted successfully in the website? The app will request normal closure of this test’s own Edge instance before restoring controls. Complete any save/download prompts; unrelated browsers will not be closed.","Staff submission verification",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
                await Sessions.CompleteAsync(staff,true);
            }
            else
            {
                if(s.Status!="Completing")
                {
                    await Sessions.OpenExportAccessAsync(staff);
                    if(s.Mode=="Custom"&&s.Status=="AwaitingStaff")
                    {
                        if(MessageBox.Show(this,"Have you saved and closed the custom application? Automatic save verification is not available. Select the completed file next.","Staff verification",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
                        var source=new OpenFileDialog{Title="Choose staff-verified completed file",Filter="All files|*.*"};
                        if(source.ShowDialog(this)!=true)return;
                        await Sessions.PrepareCustomFinalAsync(source.FileName,staff);
                    }
                    else if(s.Mode=="Word")await Sessions.PrepareFinalAsync(staff);
                    s=Sessions.Current!;
                    string extension=Path.GetExtension(s.FinalRelativePath);
                    var picker=new SaveFileDialog{Title="Export completed exam — original never overwritten",FileName=$"CompletedExam-{s.Id[..8]}{extension}",Filter=$"Completed document|*{extension}",DefaultExt=extension,AddExtension=true,OverwritePrompt=true};
                    string? sourceDir=Path.GetDirectoryName(s.SourcePath);string preferred=App.Host.Settings.Current.DefaultExportDirectory;string? removable=FindExportDrive();
                    if(removable is not null)picker.InitialDirectory=removable;
                    else if(!string.IsNullOrWhiteSpace(preferred)&&Directory.Exists(preferred))picker.InitialDirectory=preferred;
                    else if(sourceDir is not null&&Directory.Exists(sourceDir))picker.InitialDirectory=sourceDir;
                    if(picker.ShowDialog(this)!=true)return;
                    await Sessions.ExportAsync(picker.FileName,staff);
                }
                await Sessions.CompleteAsync(staff);
                MessageBox.Show(this,"Exported and completed. Saved copies kept. Safely eject your drive before removing it.","Completed");
            }
            if(_studentWindow is {IsVisible:true}){_studentWindow.AllowStaffClose=true;_studentWindow.Close();}
            RecheckSetupReadiness();
            ResetDraft();
        });
    }
    private static Dictionary<string,DriveType> ReadyDrives()
    {
        try{return DriveInfo.GetDrives().Where(d=>d.IsReady).ToDictionary(d=>d.RootDirectory.FullName,d=>d.DriveType,StringComparer.OrdinalIgnoreCase);}
        catch{return new(StringComparer.OrdinalIgnoreCase);}
    }
    private static string? FindExportDrive()
    {
        // Never require USB removal/reinsertion or block export on a drive prompt.
        // When the destination is ambiguous, the normal save picker handles it.
        var drives=ReadyDrives().Where(d=>d.Value==DriveType.Removable).Select(d=>d.Key).ToArray();
        return drives.Length==1?drives[0]:null;
    }
    private async void CancelPreparation_Click(object sender,RoutedEventArgs e)
    {
        string? staff=SessionStaff("Cancel test");if(staff is null||Sessions.Current is null||Sessions.Folder is null)return;
        if(MessageBox.Show(this,"Cancel this test? Saved local work is kept and laptop settings restored. Submit website work first if needed.","Cancel test",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        await Operation(async()=>{await Sessions.CancelStoredAsync(new(Sessions.Folder!,Sessions.Current!),staff,true);try{await new SpeechToTextService().StopInCurrentSessionAsync();}catch(Exception ex){MessageBox.Show(this,"The test was cancelled, but Voice Access did not close. Close it manually.\n\n"+ex.Message,"Voice Access",MessageBoxButton.OK,MessageBoxImage.Warning);}ResetDraft();RecheckSetupReadiness();});
    }
    private void OpenSessionFolder_Click(object sender,RoutedEventArgs e)
    {if(Sessions.Folder is string folder)Process.Start(new ProcessStartInfo(folder){UseShellExecute=true});}
    private void Records_Click(object sender,RoutedEventArgs e)
    {
        if(_operation||Sessions.IsBusy)return;
        string? staff=StaffDialogs.Authorize(this,App.Host.Settings,"View all tests / local recovery");if(staff is null)return;
        var records=new RecordsWindow(staff){Owner=this};if(records.ShowDialog()==true&&Sessions.Current is not null)AuthorizeCurrentSession(staff);
        RecheckSetupReadiness();Refresh();
    }
    private void Settings_Click(object sender,RoutedEventArgs e)
    {
        if(_operation||Sessions.IsBusy)return;
        string? staff=StaffDialogs.Authorize(this,App.Host.Settings,"Settings / recovery");if(staff is null)return;
        try{new SettingsWindow(staff){Owner=this}.ShowDialog();
            _draft.StaffChoices=App.Host.Settings.Current.StaffNames;_draft.ApplicationChoices=App.Host.Settings.Current.ApprovedApplications;_draft.AllowlistChoices=App.Host.Allowlists.LoadAll().Select(x=>x.Id).ToArray();
            foreach(var page in _pages){page.DataContext=null;page.DataContext=_draft;}RecheckSetupReadiness();Refresh();
        }catch(Exception ex){MessageBox.Show(this,ex.Message,"Settings unavailable");}
    }
    private async void ConfirmPreflight_Click(object sender,RoutedEventArgs e)
    {
        string? staff=StaffDialogs.Authorize(this,App.Host.Settings,"Confirm live controls",Sessions.Current?.StartedBy);if(staff is null)return;
        BrowserPolicyReceipt? receipt=null;
        if(Sessions.IsOnline){var verify=new BrowserPreflightWindow{Owner=this};if(verify.ShowDialog()!=true)return;receipt=verify.Receipt;}
        else if(MessageBox.Show(this,"Verify required network connections are unavailable (unless the custom app explicitly needs network), reinserted USB storage cannot be accessed, and the intended file/app is open. This is not OS app/data lockdown. Have these live checks passed?","Staff preflight",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        await Operation(async()=>{if(receipt is not null)await Sessions.RecordBrowserEvidenceAsync(receipt,staff);await Sessions.ConfirmPreflightAsync(staff);ReturnToStudent();});
    }
    private void FeatureTesting_Click(object sender,RoutedEventArgs e)
    {
        if(Sessions.Current is not null||_operation){MessageBox.Show(this,"Finish the current session before independent feature tests.");return;}
        if(_featureWindow is {IsVisible:true}){_featureWindow.Activate();return;}_featureWindow=new(){Owner=this};_featureWindow.Show();
    }
    private void ToggleTheme_Click(object sender,RoutedEventArgs e)
    {
        try
        {
            var updated=LocalStorageService.Clone(App.Host.Settings.Current);
            bool dark=((System.Windows.Media.SolidColorBrush)Application.Current.Resources["AppCanvasBrush"]).Color.R<100;
            updated.Theme=dark?"Light":"Dark";App.Host.Settings.Update(updated);App.Host.Theme.Apply();
        }
        catch(Exception ex){MessageBox.Show(this,ex.Message,"Appearance could not be saved");}
    }
    private void StaffSettingsChanged(){if(Sessions.Current is not null)return;_draft.StaffChoices=App.Host.Settings.Current.StaffNames;foreach(var page in _pages){page.DataContext=null;page.DataContext=_draft;}}
    private void UpdateSyncIndicator(){var sync=App.Host.CloudSync;bool synced=sync?.IsSynced==true;SyncDot.Fill=synced?System.Windows.Media.Brushes.ForestGreen:System.Windows.Media.Brushes.Firebrick;SyncLabel.Text=sync?.IsSyncing==true?"Syncing…":synced?"Synced":"Not synced";SyncIndicator.ToolTip=$"{sync?.Status??App.Host.MetadataSyncStatus}\nLast synced: {sync?.Defaults.Cache.LastSyncedUtc?.ToLocalTime().ToString("g")??"never"}\nPending updates: {(App.Host.MetadataQueue?.Pending().Count??0)+(sync?.Staff?.PendingCount??0)}\nClick to sync this laptop.";}
    private async void SyncNow_Click(object sender,RoutedEventArgs e){try{var sync=App.Host.CloudSync;if(sync is not null){if(sync.Staff?.State.Conflict==true){var answer=MessageBox.Show(this,"Staff edits conflict. Discard queued staff edits and use the shared list? No keeps local edits.","Staff sync conflict",MessageBoxButton.YesNoCancel,MessageBoxImage.Warning);if(answer==MessageBoxResult.Cancel)return;if(answer==MessageBoxResult.Yes){await sync.UseSharedStaffAsync();UpdateSyncIndicator();return;}}await sync.SyncAsync();}UpdateSyncIndicator();}catch(Exception ex){MessageBox.Show(this,ex.Message,"Sync needs review",MessageBoxButton.OK,MessageBoxImage.Warning);}}
    private void StudentPreview_Click(object sender,RoutedEventArgs e)
    {
        if(Sessions.Current is not null){ShowStudent();return;}
        if(_studentWindow is {IsVisible:true}){if(_studentWindow.WindowState==WindowState.Minimized)_studentWindow.WindowState=WindowState.Normal;_studentWindow.Activate();return;}_studentWindow=new StudentTestWindow(preview:true){Owner=this};_studentWindow.Show();
    }
    protected override void OnClosing(CancelEventArgs e)
    {
        if(App.Host.IsUpdateShutdown){base.OnClosing(e);return;}
        if(_operation||Sessions.IsBusy){e.Cancel=true;MessageBox.Show(this,"Wait for the current save/action to finish.");}
        else if(Sessions.Current is not null)
        {
            if(StaffDialogs.Authorize(this,App.Host.Settings,"Close app with unfinished session") is null)e.Cancel=true;
            else if(MessageBox.Show(this,"Leave this session unfinished for recovery next launch? Word is not discarded or intentionally closed. Save it manually if you leave it open.","Preserve unfinished session",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)e.Cancel=true;
        }
        if(!e.Cancel)
        {
            if(_studentWindow is {IsVisible:true}){_studentWindow.AllowStaffClose=true;_studentWindow.Close();if(_studentWindow.IsVisible)e.Cancel=true;}
            if(!e.Cancel&&_featureWindow is {IsVisible:true}){_featureWindow.Close();if(_featureWindow.IsVisible)e.Cancel=true;}
        }
        base.OnClosing(e);
    }
    private void WindowsSessionChanged(object sender,Microsoft.Win32.SessionSwitchEventArgs e){Dispatcher.BeginInvoke(new Action(ClearSessionAuthorization));}
    private void ResetDraft(){_draft.StudentName="";_draft.TestName="";_draft.DocumentPath="";_draft.UseTimeLimit=false;_draft.TextToSpeech=true;_draft.SpeechToText=true;_draft.ReadingGuide=false;_draft.ScreenTint=false;_draft.LargeControls=false;_step=0;_completed.Clear();}
    protected override void OnClosed(EventArgs e){ClearSessionAuthorization();_draft.PropertyChanged-=DraftChanged;Sessions.Changed-=SessionChanged;base.OnClosed(e);}
}
