namespace AccommodationTestManager.Models;

// Explicit cloud projection. Never serialize TestSession to a remote endpoint.
public sealed record SessionMetadata(int SchemaVersion, string SessionId, string DeviceId,
    string Mode, string Status, DateTimeOffset CreatedUtc, DateTimeOffset? StartedUtc,
    DateTimeOffset? EndedUtc, bool RecoveryReportedAvailable);
public sealed record PendingMetadata(long Revision, string Fingerprint, SessionMetadata Data);
public sealed class MetadataQueueState
{
    public int SchemaVersion { get; set; } = 1;
    public Dictionary<string, long> Revisions { get; set; } = [];
    public Dictionary<string, string> Fingerprints { get; set; } = [];
    public Dictionary<string, PendingMetadata> Pending { get; set; } = [];
}
