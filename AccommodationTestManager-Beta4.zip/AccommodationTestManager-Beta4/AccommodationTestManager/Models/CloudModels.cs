namespace AccommodationTestManager.Models;
public sealed record FirebaseClientOptions(string ProjectId, string ApiKey, string AppId);
public sealed record CloudIdentity(string Uid, string RefreshToken);
public sealed record CloudDefaults(int SchemaVersion, long Revision, int SaveIntervalSeconds,
 int SnapshotIntervalSeconds, int MaximumRecoveryCopies, int? DefaultTimeLimitMinutes);
public sealed record CloudSessionRow(string SessionId, string DeviceId, string Mode, string Status,
 bool RecoveryReportedAvailable, DateTimeOffset CreatedAt, DateTimeOffset UpdatedAt)
{
 public DateTimeOffset? StartedAt {get;init;}
 public DateTimeOffset? EndedAt {get;init;}
 public bool IsThisLaptop {get;init;}
 public string Location {get;init;}="";
 public string Availability {get;init;}="";
}
public sealed class CloudCache
{
 public CloudDefaults? Defaults {get;set;}
 public List<CloudSessionRow> Sessions {get;set;}=[];
 public DateTimeOffset? LastSyncedUtc {get;set;}
}
