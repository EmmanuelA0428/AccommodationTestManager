# Beta 2 Hotfix 1 validation handoff

## Completed in this Linux development environment

- .NET SDK 10.0.401 cross-target build `net10.0-windows`, EnableWindowsTargeting: **0 warnings, 0 errors**.
- Release publish `win-x64`, framework-dependent: successful, includes Windows .exe, configuration and active helper.
- **64 synthetic regression checks** passed. Real linked session coordinator, filesystem copies/hash receipts, atomic metadata, settings/staff migration, allowlist rules and recovery logic. Word COM, timer scheduling and machine helper substituted by explicit test doubles. Synthetic .docx files contain plain text, not genuine Word files.
- Checked failed Finish/new saved edits, failed/tampered export, blocked premature completion, metadata damage/backup restore, start/restart, staff rename/deactivate history, allowlist limits/lookalikes, preflight gating, export-access resume block, restore failure remaining Completing and retry, custom staff-verified final import/export.
- **23 mocked network-helper regression checks** passed using extracted REAL helper network function definitions and mocked Get/Enable/Disable-NetAdapter, sleep and snapshot writes. Reproduced the 19-interface reported inventory with synthetic GUIDs. Tested Wi-Fi Direct disappearance, legacy pseudo interfaces, missing physical/unknown adapters, physical-first best-effort recovery, disabled/unchanged adapters and intent-before-disable journaling. No actual Windows network changes performed.
- Four active PowerShell scripts parsed with PowerShell 7.6.6. No Windows changes performed.
- 13 XAML files XML-parsed; named StaticResource and common event-handler references checked. No missing references in that audit.
- WordAutomationService and TextToSpeechService byte-identical to Beta 1 baseline.
- Bundled JSON files parsed, published helper byte comparison, package excludes bin/obj/.vs/runtime data.
- Shared browser observed initial Posit sign-in redirect to login.rstudio.cloud/saml/sso then HWS institutional SSO. No password entered, no authenticated project tested.

## NOT validated here

Native WPF rendering/contrast/DPI/high-contrast, Windows PowerShell 5.1 execution, Windows UAC authorization under the standard shared account, registry policy effectiveness/managed conflicts, USB hot-plug denial/restore, physical/virtual network adapters, Office COM saves and modal dialogs, real removable-media reliability, effective Edge policy statuses, authenticated Canvas exam/Posit project resource dependencies, institutional or in-site AI settings, restart/crash recovery on actual Windows.

Source code and successful compilation do not establish these behaviors. Run root TEST-CHECKLIST with IT on one dedicated Windows 11 synthetic-test laptop. No claim of secure production exam readiness.

## Implementation scope limitations

No AppLocker/WDAC, protected exam-data broker, secure staff identity, browser/app freeze after Finish, complete AI prevention, automatic online submission verification, automatic deletion, online configuration or portal. Shared-account runtime documents/profiles/configuration remain readable/writable by that account. Local UI PIN attribution is not an OS security boundary. Manual staff preflight confirms scoped effective controls only.
