# Beta 2 — dedicated Windows synthetic acceptance checklist

Use fake student names/answers, a spare laptop, a known-good backup, separate admin credentials and nearby IT support. Test one mode at a time. Do NOT use real exams until outstanding app/data/AI security requirements are resolved.

## Install / visual / settings
- [ ] Extract new folder, old app closed; previous source/runtime backup retained.
- [ ] Install published x64 app + .NET 10 Desktop Runtime; run WPF as standard testing account, helper authorized separately.
- [ ] Register/reuse laptop name and stable device ID; restart preserves configuration.
- [ ] Light, Dark, System: Student/Staff/Test labels, text fields, combobox open dropdown/selection, settings tabs, grids, PIN field, disabled states, focus outlines readable.
- [ ] 100/125/150/200% scaling and smallest laptop resolution: setup boxes retained, scrollbar does not clip fields, keyboard navigation works, dialogs not off-screen.
- [ ] Preview icons fit two rows; tooltips/accessible names; no expand; timer absent by default and present only for timed tests.
- [ ] Add/rename/deactivate staff; historical session retains name + ID. Cancel settings leaves unchanged. Save persists restart; invalid intervals/URLs rejected.
- [ ] Create/import large allowlist; duplicates normalized; query/embedded-wildcard/global-allow/traversal inputs rejected. Settings changes disallowed during session.
- [ ] Gear contains theme/reload/recovery; feature testing and preview remain main-header controls.

## Word end-to-end
- [ ] Start without installed required helper blocks. Cancel UAC does not hand off; unfinished preparation visible.
- [ ] Import synthetic exam from flash drive; source bytes remain unchanged; remove ALL drives before apply.
- [ ] Snapshot records previously enabled/disabled adapters and original USB values. Word opens local working copy.
- [ ] Preflight blocks handoff until explicit staff checks; network genuinely unavailable on Wi-Fi/Ethernet/dock. USB replug inaccessible. Headset/microphone/input devices still work.
- [ ] Type answers, wait save/snapshot intervals; working and newest recovery copy open correctly in Word. Staff sees save failures if Word/modal dialog/disk conditions interfere.
- [ ] Finish produces verified checkpoint and safely closes owned Word document; no unsaved-edit discard. Window close / PIN Cancel does not release session.
- [ ] Resume through staff authorization + fresh preflight; timer remaining preserved if used.
- [ ] Finish again → Export; separate helper authorization opens original USB access; choose any destination/new filename. Export opens in Word and matches latest answers.
- [ ] Existing destination/original overwrite refused; disconnected/full drive or tampered export blocks completion. Local working/checkpoint/final/recovery retained.
- [ ] After verified export, original control state restored—not unconditional Wi-Fi/USB enable. Completed record contains staff/device/export receipts; safe eject only after completion.

## Canvas / Posit / Custom Website
- [ ] Close ALL Edge processes normally before apply. Check Edge version, management/MDM/GPO conflicts.
- [ ] Dedicated session Edge profile opens configured start URL; URLBlocklist/Allowlist show mandatory/OK at edge://policy, not ignored/error.
- [ ] Unapproved top-level URLs fail; unrelated applications are NOT blocked by this beta (document outstanding requirement).
- [ ] Canvas institutional SSO, actual quiz/assignment, embedded documents/tools and submission work.
- [ ] Posit institutional SSO passes login.rstudio.cloud and HWS SecureAuth; authenticated project launch/editor/packages/resource redirects tested, required hosts added. List is NOT complete until this passes.
- [ ] Supported Edge sidebar/Copilot/Compose restrictions effective; broad Microsoft/Office URLs and path specificity audited.
- [ ] In-site Posit/Canvas/custom AI capability reviewed separately; do NOT assume Edge policies disable it.
- [ ] USB replug denied; permitted network remains. Staff explicitly confirms preflight.
- [ ] Website Save/Submit independently verified BEFORE Finish and staff completion. Finish DOES NOT freeze/close site. Close Edge normally, restore policies, confirm original browser state.
- [ ] Custom Website start outside chosen list rejected; legitimate listed site and dependencies tested.

## Custom Desktop
- [ ] Approve actual installed executable in Settings; optional local document copied separately.
- [ ] Test offline and explicitly network-required variants; no automatic app-lockdown claim.
- [ ] App saves manually; student Finish does NOT fabricate autosave. Staff saves/closes, selects finished file, verifies imported/exported result.
- [ ] Non-Word extension offered correctly by export/re-export dialogs.

## Recovery / failure (IT present)
- [ ] Close app through staff flow while unfinished; next launch detects prior session and pending control snapshot.
- [ ] Simulated process crash preserves controls + exam files. Reopen → adopt → resume/preflight, never silently start new test.
- [ ] Missing/corrupt metadata shows NeedsReview; staff backup restore preserves old/damaged files.
- [ ] Recovery restores NEW working file, retains previous file, refuses a hash-mismatched snapshot.
- [ ] Failed Edge restore (Edge still running) leaves unfinished Completing; close normally and retry.
- [ ] Settings emergency restore preserves exam and pauses session; cannot resume with ExportAccess still open.
- [ ] Out-of-app Emergency-Restore.ps1 works with app unavailable. Recorded original values restored; failure stops for IT.
- [ ] Adapters originally disabled remain disabled; policies originally existing retain value/type/list. Domain-policy conflict does not get silently overwritten at restore.
- [ ] Do not delete snapshots, uninstall or enable next student until restoration reviewed.

## Release blockers beyond this package
- [ ] IT-reviewed OS app lockdown and tamper resistance.
- [ ] Staff-only protection/broker for other students' documents, cookies/profiles/configuration; secure staff authorization.
- [ ] Provider-side AI controls / approved exam platform settings.
- [ ] Reviewed retention/export/cleanup and offline recovery policy.
- [ ] Signed deployment/update process + authenticated configuration model (Beta 3 online work).
