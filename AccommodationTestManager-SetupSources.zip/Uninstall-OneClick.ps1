# Protected uninstall operation; leaves all runtime sessions/config and snapshots.
[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$InstallFolder)
$ErrorActionPreference='Stop'
$id=[Security.Principal.WindowsIdentity]::GetCurrent();$principal=New-Object Security.Principal.WindowsPrincipal($id)
if(-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator approval required.'}
$expected=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2'
if([IO.Path]::GetFullPath($InstallFolder)-ne [IO.Path]::GetFullPath($expected)){throw 'Unexpected uninstall location.'}
function Assert-NoReparse([string]$Path){
 $current=[IO.Path]::GetFullPath($Path)
 while($current){if(Test-Path -LiteralPath $current){if((Get-Item -LiteralPath $current -Force).Attributes-band [IO.FileAttributes]::ReparsePoint){throw ('Reparse-point path rejected: '+$current)}};$parent=[IO.Path]::GetDirectoryName($current);if($parent-eq $current){break};$current=$parent}
}
Assert-NoReparse $InstallFolder
if(@(Get-Process AccommodationTestManager -ErrorAction SilentlyContinue).Count-gt 0){throw 'Close the app normally before uninstalling; preserve unfinished work.'}
$state='C:\ProgramData\AccommodationTestingBeta2\RestrictionState';Assert-NoReparse $state
if(Test-Path -LiteralPath $state){foreach($file in Get-ChildItem -LiteralPath $state -Filter '*.json' -File){Assert-NoReparse $file.FullName;$record=Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8|ConvertFrom-Json;if($record.Status-ne 'Restored'){throw 'Restore unresolved machine restrictions before uninstalling. Snapshots preserved.'}}}
$manifest=Get-Content -LiteralPath (Join-Path $InstallFolder 'setup-installed-files.json') -Raw -Encoding UTF8|ConvertFrom-Json
if($manifest.Product-ne 'AccommodationTestManagerBeta2'){throw 'Invalid installation manifest.'}
# Validate the ENTIRE manifest before deleting any file. Unknown files are retained.
$paths=@(foreach($relative in @($manifest.Files)){
 if([IO.Path]::IsPathRooted($relative)){throw 'Invalid absolute uninstall entry.'}
 $path=[IO.Path]::GetFullPath((Join-Path $InstallFolder $relative))
 if(-not $path.StartsWith([IO.Path]::GetFullPath($InstallFolder).TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Uninstall traversal rejected.'}
 Assert-NoReparse $path;$path
})
foreach($path in $paths){if(Test-Path -LiteralPath $path -PathType Leaf){Remove-Item -LiteralPath $path -Force}}
Remove-Item -LiteralPath (Join-Path $InstallFolder 'setup-installed-files.json') -Force
foreach($folder in Get-ChildItem -LiteralPath $InstallFolder -Directory -Recurse|Sort-Object {$_.FullName.Length} -Descending){if(@(Get-ChildItem -LiteralPath $folder.FullName -Force).Count-eq 0){Remove-Item -LiteralPath $folder.FullName -Force}}
Write-Output 'Installed application files removed. Local sessions/settings and ProgramData recovery snapshots were NOT deleted.'
