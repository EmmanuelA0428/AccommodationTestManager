# Deferred GitHub work

Not executed. Do this only when the owner is ready to connect GitHub.

1. Upload the source ZIP and matching SHA-256 sidecar to the existing repository; place build-beta3.yml under .github/workflows.
2. Review the staged GlobalConfiguration files, then publish their contents under global-config-beta3/. No runtime data or credentials.
3. Manually run the validation-only workflow. It performs isolated Windows registry tests, UI tests, installer/PIN/uninstaller tests and creates an artifact. It does NOT create a release.
4. Review all results and perform dummy-data device acceptance (real Word, UAC, Edge version/profile, actual policy export, Canvas/Posit dependencies).
5. Only after acceptance, separately approve publication of a Beta 3 prerelease and verified installer hash. Final download filename is AccommodationTestManager-Setup-Beta3.exe; tag is v1.0.0-beta.3.1. Check the release naming expected by UpdateService before publishing.
6. Test public config fallback/cache and Beta 3 updater against actual released assets. Old Beta 2 updater does not migrate channels; first Beta 3 uses standalone setup.

The installer is unsigned unless code signing is added; do not disable Windows protections to distribute it.
