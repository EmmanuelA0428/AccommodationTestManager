using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using System.Net.Http;
static class CloudSyncTests
{
 sealed class MemoryIdentity : ICloudIdentityStore {public CloudIdentity? Saved;public CloudIdentity? Load()=>Saved;public void Save(CloudIdentity value)=>Saved=value;}
 sealed class Offline : HttpMessageHandler {protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage r,CancellationToken c)=>throw new HttpRequestException("Offline");}
 sealed class Emulator : DelegatingHandler
 {
  public Emulator():base(new HttpClientHandler()){}
  protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage r,CancellationToken c)
  {
   var u=r.RequestUri!;
   r.RequestUri=new Uri((u.Host.Contains("identitytoolkit")||u.Host.Contains("securetoken")?"http://127.0.0.1:9098/"+u.Host:"http://127.0.0.1:8087")+u.PathAndQuery.Replace("projects/accommodation-test-manager/","projects/demo-atm-sync/"));
   if(r.Content is not null){string body=await r.Content.ReadAsStringAsync(c);string type=r.Content.Headers.ContentType?.MediaType??"application/json";r.Content=new StringContent(body.Replace("projects/accommodation-test-manager/","projects/demo-atm-sync/"),System.Text.Encoding.UTF8,type);}
   return await base.SendAsync(r,c);
  }
 }
 static FirebaseClientOptions Options=>new("accommodation-test-manager","emulator-test-key","test");
 public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
 {
  var storage=new LocalStorageService(Path.Combine(root,"CloudChecks"));var cache=new CloudDefaultsCache(storage);var d=new CloudDefaults(1,1,60,180,5,null);
  cache.Store(d,[],DateTimeOffset.UtcNow,true);check(cache.Applied==d,"cloud defaults activate when idle");
  var d2=d with{Revision=2,SaveIntervalSeconds=30};cache.Store(d2,[],DateTimeOffset.UtcNow,false);check(cache.Applied==d&&cache.Pending==d2,"active session defers newer cloud defaults");cache.ActivatePending(false);check(cache.Applied==d,"active session keeps original defaults");cache.ActivatePending(true);check(cache.Applied==d2,"deferred defaults activate after session ends");
  cache=new CloudDefaultsCache(storage);check(cache.Applied==d2,"validated cloud defaults survive offline restart");
  await throws(()=>{cache.Store(d,[],DateTimeOffset.UtcNow,true);return Task.CompletedTask;},"configuration rollback rejected");
  await throws(()=>{cache.Store(d2 with{MaximumRecoveryCopies=2},[],DateTimeOffset.UtcNow,true);return Task.CompletedTask;},"same-revision configuration mutation rejected");
  await throws(()=>{cache.Store(d2 with{Revision=3,SaveIntervalSeconds=0},[],DateTimeOffset.UtcNow,true);return Task.CompletedTask;},"invalid downloaded defaults retain valid cache");
  var local=new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),StaffPinHash="private",DefaultExportDirectory="local",RequireMachineRestrictions=true};var effective=cache.ApplyTo(local);check(effective.DeviceId==local.DeviceId&&effective.StaffPinHash=="private"&&effective.DefaultExportDirectory=="local"&&effective.RequireMachineRestrictions,"cloud overlay cannot replace identity, PIN, paths or machine restrictions");check(local.SaveIntervalSeconds==60&&effective.SaveIntervalSeconds==30,"cloud overlay leaves local fallback unchanged");
  var outbox=new MetadataOutbox(storage);var metadata=new SessionMetadata(1,Guid.NewGuid().ToString("N"),local.DeviceId,"Word","Active",DateTimeOffset.UtcNow,null,null,true);outbox.Enqueue(metadata);var identity=new MemoryIdentity{Saved=new("existing","retained-refresh")};
  using(var sync=new CloudSyncService(new(Options,identity,new Offline()),outbox,cache,local.DeviceId,()=>true)){await sync.SyncAsync();check(outbox.Pending().Count==1&&sync.Status.Contains("Out of sync"),"offline authentication retains queue and shows out-of-sync status");}
  check(identity.Saved?.Uid=="existing","network failure never replaces existing cloud identity");check(new MetadataOutbox(storage).Pending().Count==1,"offline queued session survives restart");
  if(Environment.GetEnvironmentVariable("ATM_CLOUD_EMULATOR_TESTS")!="1")return;
  var a=new MemoryIdentity();var b=new MemoryIdentity();string deviceA=Guid.NewGuid().ToString("N"),deviceB=Guid.NewGuid().ToString("N");
  using var clientA=new FirebaseRestClient(Options,a,new Emulator());using var clientB=new FirebaseRestClient(Options,b,new Emulator());await clientA.Authenticate(default);await clientB.Authenticate(default);check(clientA.Uid!=clientB.Uid,"two clients automatically receive separate anonymous identities");await clientA.RegisterDevice(deviceA,0,default);await clientB.RegisterDevice(deviceB,0,default);check(true,"clients automatically register against real emulator rules");
  var aStore=new LocalStorageService(Path.Combine(root,"ClientA"));var queue=new MetadataOutbox(aStore);queue.Enqueue(metadata with{DeviceId=deviceA});var pending=queue.Pending().Single();await clientA.Upload(pending,default);await clientA.Upload(pending,default);check(true,"REST upload and identical retry succeed against access rules");var shared=await clientB.Download(deviceB,default);check(shared.Rows.Any(r=>r.SessionId==metadata.SessionId&&r.DeviceId==deviceA&&r.Availability.Contains("another")),"second client sees first client's metadata and original laptop location");
  queue.Acknowledge(pending.Data.SessionId,pending.Revision,pending.Fingerprint);queue.Enqueue(pending.Data with{Status="Cancelled"});var cancelled=queue.Pending().Single();await clientA.Upload(cancelled,default);await throws(()=>clientA.Upload(pending,default),"newer server revision prevents stale upload acknowledgement");
  using(var restarted=new FirebaseRestClient(Options,a,new Emulator())){await restarted.Authenticate(default);check(restarted.Uid==clientA.Uid,"saved identity refreshes after restart without enrollment");await restarted.Upload(cancelled,default);}
  var previousRows=shared.Rows;shared=await clientB.Download(deviceB,default,previousRows);check(shared.Rows.Single(r=>r.SessionId==metadata.SessionId).Status=="Cancelled","incremental state reaches second client without duplicate records");
 }
}
