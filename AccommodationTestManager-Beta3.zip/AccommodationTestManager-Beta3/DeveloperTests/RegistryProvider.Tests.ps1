[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
if(-not [Environment]::Is64BitProcess -or $env:OS-ne 'Windows_NT'){throw 'Run isolated registry tests in 64-bit Windows PowerShell.'}
$source=Join-Path (Split-Path -Parent $PSScriptRoot) 'AccommodationTestManager/Scripts/Beta2Restrictions.ps1'
$t=$null;$e=$null;$ast=[System.Management.Automation.Language.Parser]::ParseFile($source,[ref]$t,[ref]$e);if($e.Count){throw $e[0]}
$wanted=@('Set-Value','Snapshot-Value','Snapshot-List','Restore-Value','Clear-ListValues','Set-List','Restore-List','Verify-RecordedRegistry','Preservation-Inventory','Assert-Preservation')
$defs=$ast.FindAll({param($n)$n-is [System.Management.Automation.Language.FunctionDefinitionAst] -and $n.Name-in $wanted},$true)
if($defs.Count-ne $wanted.Count){throw 'Missing safe registry functions.'}
foreach($d in $defs){. ([scriptblock]::Create($d.Extent.Text))}
$root='HKCU:\Software\ATM-IsolatedRegistryTests\'+[guid]::NewGuid().ToString('N');$Edge=$root+'\Edge';$Usb=$root+'\Service';$checks=0
function Check($ok,[string]$name){if(-not $ok){throw ('FAILED: '+$name)};$script:checks++;Write-Output ('PASS: '+$name)}
function Fails([scriptblock]$work,[string]$name){$failed=$false;try{& $work}catch{$failed=$true};Check $failed $name}
try {
 Set-Value $Edge 'UnrelatedPolicy' 'retain' 'String';Set-Value ($Edge+'\OtherPolicyChild') 'Keep' 99
 Set-Value $Usb 'ImagePath' '%SystemRoot%\System32\drivers\Synthetic.sys' 'ExpandString';Set-Value $Usb 'Type' 1
 Set-Value $Usb 'Binary' ([byte[]]@(0,1,255)) 'Binary';Set-Value $Usb 'Multi' ([string[]]@('one','two')) 'MultiString';Set-Value $Usb 'Start' 3
 $value=Snapshot-Value $Usb 'Start';$value.Expected=@{Path=$Usb;Name='Start';Present=$true;Kind='DWord';Value=4}
 Set-List 'URLAllowlist' @('https://.canvas.example.org','https://.sso.example.org','https://msauth.net');Set-List 'URLBlocklist' @('*')
 $list=Snapshot-List 'URLAllowlist';$block=Snapshot-List 'URLBlocklist'
 $state=@{SchemaVersion=3;Registry=@($value);Lists=@($list,$block);Preservation=@()};$state.Preservation=@(Preservation-Inventory $state)
 Set-Value $Edge 'BrowserSignin' 0;Set-Value $Edge 'SyncDisabled' 1;Set-Value $Edge 'ComposeInlineEnabled' 0
 Check ((Get-Item $Edge).GetValueNames()-contains 'BrowserSignin') 'first scalar survives later writes'
 Check ((Get-Item $Edge).GetValueNames()-contains 'SyncDisabled') 'second scalar survives final AI write'
 Check ((Get-Item ($Edge+'\URLAllowlist')).GetValueNames().Count-eq 3) 'all numbered allowlist entries survive'
 Check ((Get-Item ($Edge+'\URLBlocklist')).GetValue('1')-eq '*') 'block-all policy survives parent scalar writes'
 Check ((Get-Item $Edge).GetValue('UnrelatedPolicy')-eq 'retain') 'unrelated Edge property survives'
 Check ((Get-Item ($Edge+'\OtherPolicyChild')).GetValue('Keep')-eq 99) 'unrelated Edge subkey survives'
 Set-Value $Usb 'Start' 4
 Check ((Get-Item $Usb).GetValue('Type')-eq 1) 'service Type survives Start write'
 Check ((Snapshot-Value $Usb 'ImagePath').Value-eq '%SystemRoot%\System32\drivers\Synthetic.sys') 'unexpanded service ImagePath survives'
 Check ((Snapshot-Value $Usb 'Binary').Kind-eq 'Binary') 'binary registry type preserved'
 Check ((Snapshot-Value $Usb 'Multi').Kind-eq 'MultiString') 'multi-string registry type preserved'
 # Baseline inventory includes newly-added unrelated scalar policies: restore test baseline after seeding them.
 $edgeControl=Snapshot-Value $Edge 'BrowserSignin';$edgeControl.Expected=Snapshot-Value $Edge 'BrowserSignin';$state.Registry+=,$edgeControl
 $state.Preservation=@(Preservation-Inventory $state);Assert-Preservation $state
 $state=$state|ConvertTo-Json -Depth 30|ConvertFrom-Json;Assert-Preservation $state;Check $true 'inventory survives JSON persistence'
 Restore-Value $value;Check ((Get-Item $Usb).GetValue('Start')-eq 3) 'selected Start restores without deleting service data'
 Set-List 'URLAllowlist' @('https://.new.example.org','https://.auth.example.org');$list.Expected=Snapshot-List 'URLAllowlist'
 Restore-List $list;Check ((Get-Item ($Edge+'\URLAllowlist')).GetValueNames().Count-eq 3) 'all original allowlist entries restored'
 Check ((Get-Item $Edge).GetValue('UnrelatedPolicy')-eq 'retain') 'restoration preserves unrelated parent values'
 Set-Value ($Edge+'\EmptyUnrelated') 'Temporary' 1;Remove-ItemProperty ($Edge+'\EmptyUnrelated') 'Temporary'
 $emptyState=@{Registry=$state.Registry;Lists=$state.Lists;Preservation=@()};$emptyState.Preservation=@(Preservation-Inventory $emptyState)
 Remove-Item -LiteralPath ($Edge+'\EmptyUnrelated');Fails {Assert-Preservation $emptyState} 'removed empty unrelated subkey detected'
 Set-Value $Usb 'Unexpected' 'outside' 'String';Fails {Assert-Preservation $state} 'unrelated external change detected, not overwritten'
 # Aggregate check catches a policy erased AFTER its own immediate readback succeeded.
 $scalar=Snapshot-Value $Usb 'Start';$scalar.Expected=Snapshot-Value $Usb 'Start';$proof=@{Registry=@($scalar);Lists=@()}
 Remove-ItemProperty $Usb 'Start';Fails {Verify-RecordedRegistry $proof} 'aggregate verification catches missing earlier scalar'
 Write-Output ('ALL '+$checks+' REAL REGISTRY PROVIDER CHECKS PASSED — isolated HKCU test branch only; no Edge/system policy or service touched.')
}finally{if(Test-Path $root){Remove-Item -LiteralPath $root -Recurse -Force}}
