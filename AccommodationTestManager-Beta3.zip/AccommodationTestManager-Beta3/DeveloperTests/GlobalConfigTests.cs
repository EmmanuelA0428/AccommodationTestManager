using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using System.Net;
using System.Text;
using System.Text.Json;
using System.Security.Cryptography;
public sealed class ConfigHttp:HttpMessageHandler
{
 public Dictionary<string,byte[]> Files=new();public bool Offline;
 protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken token)
 {if(Offline)throw new HttpRequestException("Synthetic offline");string path=request.RequestUri!.AbsolutePath.Split("/global-config-beta3/")[1];return Task.FromResult(Files.TryGetValue(path,out var b)?new HttpResponseMessage(HttpStatusCode.OK){Content=new ByteArrayContent(b)}:new HttpResponseMessage(HttpStatusCode.NotFound));}
 public void Seed(int version=1,int seconds=60)
 {
  Files.Clear();var refs=new List<GlobalListReference>();
  foreach(string id in new[]{"canvas","posit"})
  {
   var list=new AllowlistConfiguration{Id=id,UrlPatterns=["https://"+id+".example.org"]};byte[] bytes=JsonSerializer.SerializeToUtf8Bytes(list);Files["allowlists/"+id+".json"]=bytes;refs.Add(new(){Id=id,Sha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant()});
  }
  Files["manifest.json"]=JsonSerializer.SerializeToUtf8Bytes(new GlobalManifest{Version=version,CanvasUrl="https://canvas.example.org/",PositUrl="https://posit.example.org/",SaveIntervalSeconds=seconds,SnapshotIntervalSeconds=Math.Max(180,seconds),Allowlists=refs});
 }
}
public static class GlobalConfigTests
{
 public static async Task Run(string root,Action<bool,string> check)
 {
  var storage=new LocalStorageService(Path.Combine(root,"Global"));var handler=new ConfigHttp();handler.Seed();
  var local=new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),StaffPinHash="DO NOT PUBLISH",LaptopName="LOCAL",CanvasUrl="https://local.example.org/"};
  using var service=new GlobalConfigService(storage,handler);await service.RefreshAsync();var v1=service.ApplyTo(local);
  check(v1.GlobalConfigVersion==1&&v1.CanvasUrl=="https://canvas.example.org/","global version and starting page applied");
  check(v1.StaffPinHash==local.StaffPinHash&&v1.DeviceId==local.DeviceId&&v1.LaptopName==local.LaptopName&&v1.RequireMachineRestrictions,"remote config cannot change local identity/PIN/control requirements");
  check(local.GlobalConfigVersion==0&&local.CanvasUrl=="https://local.example.org/","global overlay never overwrites local settings");
  handler.Offline=true;await service.RefreshAsync();check(service.ApplyTo(local).GlobalConfigVersion==1&&service.Status.Contains("refresh unavailable"),"offline refresh retains last-known-good");handler.Offline=false;
  using(var cached=new GlobalConfigService(storage,new ConfigHttp{Offline=true})){cached.LoadCache();check(cached.ApplyTo(local).GlobalConfigVersion==1,"cached policy available immediately after restart offline");}
  handler.Seed(2,120);service.CanActivate=()=>false;await service.RefreshAsync();check(service.ApplyTo(local).GlobalConfigVersion==1&&v1.SaveIntervalSeconds==60,"active test policy unchanged while new version caches");service.CanActivate=()=>true;service.ActivatePending();check(service.ApplyTo(local).GlobalConfigVersion==2,"pending policy activates only between sessions");
  handler.Seed(1);await service.RefreshAsync();check(service.ApplyTo(local).GlobalConfigVersion==2&&service.Status.Contains("rollback"),"older global version rejected");
  handler.Seed(2,130);await service.RefreshAsync();check(service.ApplyTo(local).SaveIntervalSeconds==120,"same-version changed manifest rejected");
  handler.Seed(3);handler.Files["allowlists/canvas.json"]=Encoding.UTF8.GetBytes("{}");await service.RefreshAsync();check(service.ApplyTo(local).GlobalConfigVersion==2&&service.Status.Contains("checksum"),"partial/mismatched multi-file update retains prior bundle");
  handler.Seed(3);handler.Files["manifest.json"]=Encoding.UTF8.GetBytes(Encoding.UTF8.GetString(handler.Files["manifest.json"])[..^1]+",\"StaffPinHash\":\"bad\"}");await service.RefreshAsync();check(service.ApplyTo(local).GlobalConfigVersion==2,"unknown/private global fields rejected");
  handler.Seed(3,1);await service.RefreshAsync();check(service.ApplyTo(local).GlobalConfigVersion==2,"invalid save interval rejected atomically");
  local.GlobalConfigEnabled=false;check(service.ApplyTo(local).GlobalConfigVersion==0&&service.Lists(false) is null,"staff opt-out restores local policy");local.GlobalConfigEnabled=true;
  File.WriteAllText(Path.Combine(storage.Root,"Configuration","global-cache-beta3.json"),"{broken");using(var broken=new GlobalConfigService(storage,new ConfigHttp{Offline=true})){broken.LoadCache();check(broken.ApplyTo(local).GlobalConfigVersion==0&&broken.Status.Contains("invalid"),"corrupt cache falls back to local config without resetting identity");}
 }
}
