using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using System.Text.Json;
public static class BrowserEvidenceTests
{
 public static async Task Run(string root,Action<bool,string> check,Func<Func<Task>,string,Task> throws)
 {
  var exact=new AllowlistConfiguration{Id="exact",UrlPatterns=AllowlistService.Normalize(["https://canvas.hws.edu"])};
  check(AllowlistService.AllowsStart(exact,"https://canvas.hws.edu/courses/1"),"exact host allows intended Canvas paths");
  check(!AllowlistService.AllowsStart(exact,"https://evil.canvas.hws.edu/")&&!AllowlistService.AllowsStart(exact,"https://www.microsoft.com/"),"exact host rejects unreviewed subdomain and Microsoft site");
  var auth=AllowlistService.Normalize(["https://*.msauth.net"]);check(AllowlistService.Normalize(auth).SequenceEqual(auth),"normalization is idempotent for explicit authentication subdomains");
  check(AllowlistService.ToEdgeFilter(auth[0])=="https://msauth.net","explicit subdomain rule maps to documented Edge syntax");
  var session=new TestSession{Mode="Canvas",AllowedUrls=["https://.canvas.hws.edu"],BrowserAiPolicies=["HubsSidebarEnabled","Microsoft365CopilotChatIconEnabled","ComposeInlineEnabled"],PreflightStartedUtc=DateTimeOffset.UtcNow.AddSeconds(-1)};
  Dictionary<string,Dictionary<string,object>> Policies()=>BrowserPolicyEvidence.Required(session).ToDictionary(x=>x.Key,x=>new Dictionary<string,object>{{"value",x.Value},{"level","mandatory"},{"scope","machine"},{"source","platform"}});
  byte[] Bytes(Dictionary<string,Dictionary<string,object>> values)=>JsonSerializer.SerializeToUtf8Bytes(new{policyValues=new{chrome=new{policies=values}}});
  var valid=Policies();var receipt=BrowserPolicyEvidence.Validate(Bytes(valid),session,DateTimeOffset.UtcNow);check(receipt.Sha256.Length==64,"effective export produces receipt without raw metadata persistence");
  await throws(()=>{var v=Policies();v.Remove("URLBlocklist");BrowserPolicyEvidence.Validate(Bytes(v),session,DateTimeOffset.UtcNow);return Task.CompletedTask;},"Compose-only report cannot pass preflight");
  await throws(()=>{var v=Policies();v["URLAllowlist"]["value"]=new[]{"*"};BrowserPolicyEvidence.Validate(Bytes(v),session,DateTimeOffset.UtcNow);return Task.CompletedTask;},"broader effective allowlist blocks handoff");
  foreach(string flag in new[]{"ignored","error","warning","future","deprecated","restartRequired"})await throws(()=>{var v=Policies();v["URLBlocklist"][flag]=true;BrowserPolicyEvidence.Validate(Bytes(v),session,DateTimeOffset.UtcNow);return Task.CompletedTask;},"unaccepted policy blocks handoff: "+flag);
  await throws(()=>{var v=Policies();v["URLBlocklist"]["level"]="recommended";BrowserPolicyEvidence.Validate(Bytes(v),session,DateTimeOffset.UtcNow);return Task.CompletedTask;},"recommended-only policy blocks handoff");
  await throws(()=>{BrowserPolicyEvidence.Validate(Bytes(Policies()),session,DateTimeOffset.UtcNow.AddHours(-1));return Task.CompletedTask;},"stale policy export blocks handoff");
  await throws(()=>{BrowserPolicyEvidence.Validate("{}"u8.ToArray(),session,DateTimeOffset.UtcNow);return Task.CompletedTask;},"unknown export schema fails closed");
  var storage=new LocalStorageService(Path.Combine(root,"BrowserGate"));var settings=new SettingsService(storage);LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),RequireMachineRestrictions=true});settings.Load();settings.Register("Synthetic browser","FAKE",["Staff"],"654321");
  string id=Guid.NewGuid().ToString("N");session.Id=id;session.Status="Preflight";session.RestrictionsApplied=true;session.SettingsSnapshot=LocalStorageService.Clone(settings.Current);session.SettingsSnapshot.StaffPinHash="";session.SettingsSnapshot.StaffPinSalt="";
  string folder=storage.NewSessionFolder(id);LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),session);folder=storage.MoveArea(folder,"Active");var helper=new RestrictionService();helper.States[id]="Applied";
  using var service=new SessionService(storage,settings,null,helper);await service.AdoptAsync(new(folder,session),"Staff");
  await throws(()=>service.ConfirmPreflightAsync("Staff"),"online coordinator refuses bare Yes without browser evidence");
  await service.RecordBrowserEvidenceAsync(receipt,"Staff");await service.ConfirmPreflightAsync("Staff");check(service.Current!.Status=="Active","accepted policy receipt plus staff live attestation permits handoff");
  check(service.Current.Events.Any(x=>x.Action.Contains("Browser policies verified")),"browser verification records staff attribution");
 }
}
