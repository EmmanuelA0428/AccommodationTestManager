param([string]$Folder=$PSScriptRoot)
$ErrorActionPreference='Stop'
$path=Join-Path $Folder 'manifest.json'
$m=Get-Content $path -Raw|ConvertFrom-Json
foreach($list in $m.Allowlists){$list.Sha256=(Get-FileHash (Join-Path $Folder ("allowlists/"+$list.Id+".json"))).Hash.ToLowerInvariant()}
$m.Version=[int]$m.Version+1
[IO.File]::WriteAllText($path,($m|ConvertTo-Json -Depth 10),(New-Object Text.UTF8Encoding($false)))
Write-Host "Updated global version $($m.Version). Commit manifest and changed lists together."
