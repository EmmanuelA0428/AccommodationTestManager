using AccommodationTestManager.Models;
using System.IO;
using System.Text.RegularExpressions;

namespace AccommodationTestManager.Services;
public sealed class AllowlistService(LocalStorageService storage)
{
    public Func<List<AllowlistConfiguration>?>? GlobalLists {get;set;}
    public string Folder => Path.Combine(storage.Root,"Configuration","Allowlists-Beta3");
    public void Initialize()
    {
        Directory.CreateDirectory(Folder);
        foreach(string file in Directory.GetFiles(Path.Combine(AppContext.BaseDirectory,"Configuration","Allowlists-Beta3"),"*.json"))
        {string target=Path.Combine(Folder,Path.GetFileName(file));if(!File.Exists(target))File.Copy(file,target);}
    }
    public List<AllowlistConfiguration> LoadAllLocal()=>Directory.GetFiles(Folder,"*.json").Select(LocalStorageService.ReadJson<AllowlistConfiguration>).OrderBy(x=>x.Id).ToList();
    public List<AllowlistConfiguration> LoadAll()=>(GlobalLists?.Invoke()??[]).Concat(Directory.GetFiles(Folder,"*.json").Select(LocalStorageService.ReadJson<AllowlistConfiguration>)).GroupBy(x=>x.Id).Select(x=>x.First()).OrderBy(x=>x.Id).ToList();
    public AllowlistConfiguration Load(string id)
    {
        ValidateId(id);var value=GlobalLists?.Invoke()?.FirstOrDefault(x=>x.Id==id)??LocalStorageService.ReadJson<AllowlistConfiguration>(Path.Combine(Folder,id+".json"));Validate(value);return value;
    }
    public void Save(AllowlistConfiguration value)
    {Validate(value);LocalStorageService.WriteJson(Path.Combine(Folder,value.Id+".json"),value);}
    public static void ValidateId(string id)
    {if(!Regex.IsMatch(id,@"^[a-z0-9][a-z0-9-]{0,39}$"))throw new InvalidOperationException("List ID must use lowercase letters, digits and hyphens, at most 40 characters.");}
    public static List<string> Normalize(IEnumerable<string> lines)
    {
        var result=new List<string>();
        foreach(string raw in lines)
        {
            string value=raw.Trim().Trim('"','\'',',').Trim();if(value.Length==0)continue;
            if(!value.Contains("://"))value="https://"+value;
            if(!value.StartsWith("https://",StringComparison.OrdinalIgnoreCase))throw new InvalidOperationException("Only HTTPS Edge host/path filters are permitted.");
            string rest=value[8..];bool subdomains=rest.StartsWith("*.");
            if(subdomains)rest=rest[2..];else if(rest.StartsWith('.'))rest=rest[1..];
            if(rest.EndsWith("/*",StringComparison.Ordinal))rest=rest[..^1];
            if(rest.Contains('*')||rest.Contains('[')||rest.Contains('<')||!Uri.TryCreate("https://"+rest,UriKind.Absolute,out var uri)||uri.UserInfo.Length>0||uri.Query.Length>0||uri.Fragment.Length>0||uri.Host.Length==0||uri.HostNameType!=UriHostNameType.Dns)
                throw new InvalidOperationException("Use HTTPS exact hosts, or explicit *.host for reviewed authentication subdomains; optional path prefixes; no credentials/queries/fragments.");
            string port=uri.IsDefaultPort?"":":"+uri.Port;
            // Leading dot is Edge's exact-host syntax; a plain host includes subdomains.
            result.Add("https://"+(subdomains?"*.":".")+uri.Host.ToLowerInvariant()+port+uri.AbsolutePath.TrimEnd('/'));
        }
        return result.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }
    public static string ToEdgeFilter(string pattern)=>pattern.Replace("https://*.","https://",StringComparison.Ordinal);
    public static Uri PatternUri(string pattern,out bool exact)
    {string rest=pattern[8..];exact=!rest.StartsWith("*.");if(rest.StartsWith("*."))rest=rest[2..];else if(rest.StartsWith('.'))rest=rest[1..];return new Uri("https://"+rest);}
    public static void Validate(AllowlistConfiguration value)
    {
        ValidateId(value.Id);if(value.Version<1)throw new InvalidOperationException("Allowlist version must be positive.");
        if(value.UrlPatterns is null||value.UrlPatterns.Count>999)throw new InvalidOperationException("At most 999 entries: one Edge exception is reserved for staff policy inspection.");
        value.UrlPatterns=Normalize(value.UrlPatterns);
    }
    public static bool AllowsStart(AllowlistConfiguration list,string url)
    {
        if(!Uri.TryCreate(url,UriKind.Absolute,out var target)||target.Scheme!="https")return false;
        return list.UrlPatterns.Any(pattern=>
        {
            var rule=PatternUri(pattern,out bool exact);string host=rule.Host;
            return (target.Host.Equals(host,StringComparison.OrdinalIgnoreCase)||!exact&&target.Host.EndsWith("."+host,StringComparison.OrdinalIgnoreCase))&&target.AbsolutePath.StartsWith(rule.AbsolutePath,StringComparison.Ordinal)&&target.Port==rule.Port;
        });
    }
}
