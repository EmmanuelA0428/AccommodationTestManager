using AccommodationTestManager.Models;
namespace AccommodationTestManager.Services;
public sealed class CloudSyncService : IDisposable
{
 private readonly FirebaseRestClient _client;private readonly MetadataOutbox _outbox;private readonly string _device;
 private readonly SemaphoreSlim _gate=new(1,1);private readonly CancellationTokenSource _stop=new();private readonly Func<bool> _idle;
 public CloudDefaultsCache Defaults {get;}
 public event Action? Changed;
 public string Status {get;private set;}="Cloud not yet checked; cached settings and local tests available.";
 public CloudSyncService(FirebaseRestClient client,MetadataOutbox outbox,CloudDefaultsCache defaults,string device,Func<bool> idle){_client=client;_outbox=outbox;Defaults=defaults;_device=device;_idle=idle;}
 public async Task SyncAsync()
 {
  if(!await _gate.WaitAsync(0))return;
  try
  {
   Defaults.ActivatePending(_idle());Status="Syncing anonymous session metadata and settings…";Changed?.Invoke();
   await _client.Authenticate(_stop.Token);await _client.RegisterDevice(_device,Defaults.Applied?.Revision??0,_stop.Token);
   foreach(var pending in _outbox.Pending()){await _client.Upload(pending,_stop.Token);_outbox.Acknowledge(pending.Data.SessionId,pending.Revision,pending.Fingerprint);}
   var result=await _client.Download(_device,_stop.Token,Defaults.Cache.Sessions);Defaults.Store(result.Defaults,result.Rows,DateTimeOffset.UtcNow,_idle());
   Status=$"Synced {Defaults.Cache.LastSyncedUtc:HH:mm} UTC · settings v{Defaults.Applied?.Revision??0}"+(Defaults.Pending is not null?$" · v{Defaults.Pending.Revision} waits until this test ends":"")+$" · {_outbox.Pending().Count} queued. No files uploaded. This laptop: Laptop-{_device[..8]}.";
  }
  catch(OperationCanceledException){Status="Sync deferred (offline or timeout); local data and pending uploads retained.";}
  catch(Exception){Status=$"Out of sync / review needed · {_outbox.Pending().Count} queued · last success {Defaults.Cache.LastSyncedUtc?.ToString("u")??"never"}. Local tests remain available.";}
  finally{_gate.Release();Changed?.Invoke();}
 }
 public void Dispose(){_stop.Cancel();_client.Dispose();}
}
