using AccommodationTestManager.Models;
using System.Diagnostics;
using System.ComponentModel;
using System.Text;
using System.IO;
using System.Security.Principal;
using System.Text.Json;

namespace AccommodationTestManager.Services;
public sealed class RestrictionService
{
    public string StateRoot=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData),"AccommodationTestingBeta2","RestrictionState");
    private string Helper=>Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"AccommodationTestManagerBeta2","Scripts","Beta2Restrictions.ps1");
    public bool IsInstalled
    { get { try{return File.Exists(Helper)&&Directory.Exists(StateRoot)&&File.ReadAllText(Helper).Contains("HelperRevision='beta3-safe-registry-1'",StringComparison.Ordinal);}catch{return false;} } }
    public string CapabilitySummary()
    {
        using var os=Microsoft.Win32.Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows NT\CurrentVersion");
        return $"Windows edition: {os?.GetValue("EditionID")} · build {os?.GetValue("CurrentBuild")}\nProtected helper installed: {IsInstalled}\nImplemented: adapter isolation, USB storage policy, Edge policy configuration/restore.\nNOT implemented: application lockdown, protected student-data broker, all-AI prevention. Live device/browser checks remain mandatory.";
    }
    public List<string> PendingIds()
    {
        if(!Directory.Exists(StateRoot))return [];
        return Directory.GetFiles(StateRoot,"*.json").Where(p=>!p.EndsWith(".report.json",StringComparison.OrdinalIgnoreCase)).Where(p=>Status(Path.GetFileNameWithoutExtension(p))!="Restored").Select(Path.GetFileNameWithoutExtension).OfType<string>().ToList();
    }
    public string Status(string id)
    {
        if(!Guid.TryParseExact(id,"N",out _))throw new InvalidOperationException("Invalid session ID.");
        string file=Path.Combine(StateRoot,id+".json");if(!File.Exists(file))return "Missing";
        using var document=JsonDocument.Parse(File.ReadAllText(file));return document.RootElement.GetProperty("Status").GetString()??"Unknown";
    }
    public string EdgeProcessSummary()
    {
        using var current=Process.GetCurrentProcess();var lines=new List<string>();
        foreach(var process in Process.GetProcessesByName("msedge"))using(process){try{lines.Add($"PID {process.Id} · Windows session {process.SessionId}"+(process.SessionId==current.SessionId?" (this testing session)":" (another signed-in session)"));}catch{lines.Add("Edge process ownership unavailable");}}
        return string.Join("\n",lines);
    }
    public string[] AiPolicyPlan()
    {
        string? exe=new[]{Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFilesX86),"Microsoft","Edge","Application","msedge.exe"),Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles),"Microsoft","Edge","Application","msedge.exe")}.FirstOrDefault(File.Exists);
        if(exe is null||!int.TryParse(FileVersionInfo.GetVersionInfo(exe).ProductVersion?.Split('.')[0],out int major)||major<139)throw new IOException("Edge 139 or newer is required for this beta's Windows AI policy plan. Update Edge through its normal supported update path.");
        var policies=new List<string>{"HubsSidebarEnabled","Microsoft365CopilotChatIconEnabled","ComposeInlineEnabled"};
        if(major>=148)policies.AddRange(["AllowBrowsingWithCopilot","CopilotNewTabPageEnabled"]);
        return policies.ToArray();
    }
    public bool NeedsLegacyReview()
    {
        if(!Directory.Exists(StateRoot))return false;
        var files=Directory.GetFiles(StateRoot,"*.json").Where(p=>!p.EndsWith(".report.json",StringComparison.OrdinalIgnoreCase));var hashes=new List<string>();
        foreach(string path in files.OrderBy(Path.GetFileName,StringComparer.OrdinalIgnoreCase))
        {using var doc=JsonDocument.Parse(File.ReadAllText(path));if(!doc.RootElement.TryGetProperty("SchemaVersion",out var schema)||schema.GetInt32()<3)hashes.Add(Path.GetFileName(path)+":"+LocalStorageService.HashFile(path).ToUpperInvariant());}
        if(hashes.Count==0)return false;string receipt=Path.Combine(StateRoot,"legacy-review.report.json");if(!File.Exists(receipt))return true;
        using var review=JsonDocument.Parse(File.ReadAllText(receipt));return !review.RootElement.GetProperty("IndependentReviewConfirmed").GetBoolean()||review.RootElement.GetProperty("Fingerprint").GetString()!=string.Join(";",hashes);
    }
    public async Task LegacyActionAsync(string action){if(action is not ("Assess" or "RestoreLegacyRecorded" or "ApproveReview"))throw new IOException("Invalid review action.");await RunHelper(action,new string('0',32));}
    public void Precheck(TestSession session)
    {
        if(!IsInstalled)throw new IOException("Install the Beta 3 corrected helper before machine actions. The legacy Beta 2 helper must never be invoked by this app.");
        if(NeedsLegacyReview())throw new IOException("Legacy registry assessment required. Use Settings → Recovery → Assess legacy machine state. No new controls were applied.");
        bool online=session.Mode is "Canvas" or "Posit"||session.Mode=="Custom"&&session.CustomKind=="Website";
        if(online){string processes=EdgeProcessSummary();if(processes.Length>0)throw new IOException("Edge is still running before administrator authorization. Close/save browser work; check Startup boost/background mode or another signed-in account. No process was killed.\n"+processes);if(session.SettingsSnapshot.DisableBrowserAI)session.BrowserAiPolicies=AiPolicyPlan();}
    }
    public async Task ApplyAsync(TestSession session)
    {
        Precheck(session);
        if(!IsInstalled)throw new InvalidOperationException("Install Beta 3 in protected Program Files before machine restriction tests. No restrictions were attempted.");
        if(new WindowsPrincipal(WindowsIdentity.GetCurrent()).IsInRole(WindowsBuiltInRole.Administrator))throw new InvalidOperationException("Run the WPF app as the standard testing account; authorize the helper with a separate administrator account.");
        if(session.SettingsSnapshot.EnableApplicationLockdown)throw new InvalidOperationException("Application lockdown is not implemented; required control cannot be verified. Startup blocked.");
        bool online=session.Mode is "Canvas" or "Posit"||session.Mode=="Custom"&&session.CustomKind=="Website";
        bool networkRequired=session.Mode=="Custom"&&session.CustomKind=="Desktop"&&session.SettingsSnapshot.ApprovedApplications.FirstOrDefault(x=>x.Id==session.ApplicationId)?.NetworkRequired==true;
        string request=Path.Combine(Path.GetTempPath(),"ATM-Beta2-"+Guid.NewGuid().ToString("N")+".json");
        try
        {
            LocalStorageService.WriteJson(request,new{Mode=online?"Online":session.Mode=="Word"?"Word":"Desktop",IsolateNetwork=!online&&!networkRequired,Allowlist=session.AllowedUrls,DisableBrowserAI=session.SettingsSnapshot.DisableBrowserAI,AiPolicies=session.BrowserAiPolicies,BlockedAIUrls=session.SettingsSnapshot.DisableBrowserAI?session.SettingsSnapshot.BlockedAIUrls:[],ApplicationLockdown=session.SettingsSnapshot.EnableApplicationLockdown});
            await RunHelper("Apply",session.Id,request);
            if(Status(session.Id)!="Applied")throw new IOException("Machine restriction apply was not confirmed.");
        }
        finally{File.Delete(request);}
    }
    public async Task ExportAccessAsync(string id){if(Status(id)=="ExportAccess")return;await RunHelper("ExportAccess",id);if(Status(id)!="ExportAccess")throw new IOException("USB export access was not restored.");}
    public async Task RestoreAsync(string id){if(Status(id)=="Restored")return;await RunHelper("Restore",id);if(Status(id)!="Restored")throw new IOException("Previous machine state was not restored.");}
    public string Diagnostics(string? id=null)
    {
        var text=new StringBuilder("Machine diagnostics — local/read-only; no exam answers or credentials.\n");
        text.AppendLine("Legacy review required: "+NeedsLegacyReview());
        text.AppendLine("App version: "+UpdatePolicy.InstalledVersion).AppendLine("Protected helper installed: "+IsInstalled);
        try { text.AppendLine("Edge process count (may include background/other sessions): "+Process.GetProcessesByName("msedge").Length); } catch(Exception ex){text.AppendLine("Process check unavailable: "+ex.Message);}
        try
        {
            if(!Directory.Exists(StateRoot)){text.AppendLine("Protected state folder is missing.");return text.ToString();}
            if(id is not null&&!Guid.TryParseExact(id,"N",out _))throw new IOException("Invalid session ID.");
            var files=Directory.GetFiles(StateRoot,"*.json").Where(p=>id is null||Path.GetFileName(p).StartsWith(id+".",StringComparison.OrdinalIgnoreCase)).OrderByDescending(File.GetLastWriteTimeUtc).Take(12);
            foreach(string file in files)
            {
                text.AppendLine("\n"+Path.GetFileName(file));
                try
                {
                    if(new FileInfo(file).Length>1024*1024)throw new IOException("Diagnostic file exceeds size limit.");
                    using var data=JsonDocument.Parse(File.ReadAllText(file));
                    foreach(string key in new[]{"SessionId","Action","Stage","Success","Status","Detail","Message","UpdatedUtc","LegacySnapshotCount","ServiceIssues","IndependentReviewConfirmed"})
                        if(data.RootElement.TryGetProperty(key,out var v))text.AppendLine(key+": "+v.ToString());
                }catch(Exception ex){text.AppendLine("Could not read report: "+ex.Message);}
            }
            text.AppendLine("\nA report is not a restoration receipt. Do not delete snapshots to clear a failure.");
        }catch(Exception ex){text.AppendLine("Diagnostics unavailable: "+ex.Message);}
        return text.ToString();
    }
    private async Task RunHelper(string action,string id,string? request=null)
    {
        if(!IsInstalled)throw new IOException("Protected helper is missing.");
        var info=new ProcessStartInfo(Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.System),"WindowsPowerShell","v1.0","powershell.exe")){UseShellExecute=true,Verb="runas",WindowStyle=ProcessWindowStyle.Hidden};
        foreach(string arg in new[]{"-NoProfile","-WindowStyle","Hidden","-ExecutionPolicy","Bypass","-File",Helper,"-Action",action,"-SessionId",id})info.ArgumentList.Add(arg);
        if(request is not null){info.ArgumentList.Add("-RequestPath");info.ArgumentList.Add(request);}
        var attemptStarted=DateTimeOffset.UtcNow;
        Process started;
        try { started=Process.Start(info)??throw new IOException("Admin helper did not start."); }
        catch(Win32Exception ex) { throw new IOException(ex.NativeErrorCode==1223?"Windows administrator authorization was cancelled. No helper action started.":"Windows could not start the installed helper (error "+ex.NativeErrorCode+"). Open View diagnostics.",ex); }
        using Process process=started;await process.WaitForExitAsync();
        if(process.ExitCode!=0)
        {
            string detail="";
            string report=Path.Combine(StateRoot,id+"."+action+".report.json");
            try
            {
                string snapshot=Path.Combine(StateRoot,id+".json");
                if(File.Exists(report)){using var recorded=JsonDocument.Parse(File.ReadAllText(report));if(!recorded.RootElement.GetProperty("Success").GetBoolean()&&recorded.RootElement.GetProperty("UpdatedUtc").GetDateTimeOffset()>=attemptStarted.AddSeconds(-2))detail=recorded.RootElement.GetProperty("Stage").GetString()+": "+recorded.RootElement.GetProperty("Message").GetString();}
                if(detail.Length==0&&File.Exists(snapshot)){using var data=JsonDocument.Parse(File.ReadAllText(snapshot));if(data.RootElement.TryGetProperty("Detail",out var value))detail=value.GetString()??"";}
            }
            catch(Exception ex) when(ex is IOException or UnauthorizedAccessException or JsonException){detail="Snapshot could not be read; preserve it for IT review.";}
            throw new IOException("Machine action did not complete (helper exit code "+process.ExitCode+"). Preserve the session/snapshot. Open View diagnostics; use Emergency Restore only for unresolved machine state."+(detail.Length>0?"\n\nRecorded detail: "+detail:"\nNo diagnostic report was available. The helper may have been blocked before its script ran."));
        }
    }
}
