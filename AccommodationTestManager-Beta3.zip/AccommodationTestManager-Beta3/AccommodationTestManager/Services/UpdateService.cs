using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace AccommodationTestManager.Services;

public sealed record AvailableUpdate(string Version,string FileName,Uri Download,Uri Checksum,Uri ReleasePage,long Size,string? Digest);

public static class UpdatePolicy
{
    public const string Repository="EmmanuelA0428/AccommodationTestManager";
    public const string InstalledVersion="1.0.0-beta.3.1";
    public static Version ReleaseVersion(string tag)
    {
        var m=Regex.Match(tag,@"^v?(\d+)\.(\d+)\.(\d+)-beta\.(\d+)\.(\d+)$");
        if(!m.Success||m.Groups[4].Value!="3")throw new InvalidDataException("Unrecognized Beta 3 release version.");
        return new Version(int.Parse(m.Groups[1].Value),int.Parse(m.Groups[2].Value),int.Parse(m.Groups[3].Value),int.Parse(m.Groups[5].Value));
    }
    public static void ValidateAssetUri(Uri uri)
    {
        if(uri.Scheme!="https"||!uri.IsDefaultPort||uri.Host!="github.com"||uri.UserInfo.Length!=0||uri.Query.Length!=0||uri.Fragment.Length!=0||!uri.AbsolutePath.StartsWith("/"+Repository+"/releases/download/",StringComparison.Ordinal))
            throw new InvalidDataException("Updates must come from this project's HTTPS GitHub release assets.");
    }
    public static string ParseChecksum(string content,string name)
    {
        var lines=content.Trim().Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries);
        if(lines.Length!=1)throw new InvalidDataException("Invalid update checksum file.");
        var parts=lines[0].Split((char[]?)null,StringSplitOptions.RemoveEmptyEntries);
        if(parts.Length!=2||!Regex.IsMatch(parts[0],"^[a-fA-F0-9]{64}$")||parts[1].TrimStart('*')!=name)throw new InvalidDataException("Update checksum must name this installer exactly.");
        return parts[0].ToLowerInvariant();
    }
}

public sealed class UpdateService : IDisposable
{
    private readonly HttpClient _http=new(){Timeout=TimeSpan.FromMinutes(5),MaxResponseContentBufferSize=1024*1024};
    private readonly LocalStorageService _storage;
    private readonly SessionService _sessions;
    private readonly RestrictionService _restrictions;
    public UpdateService(LocalStorageService storage,SessionService sessions,RestrictionService restrictions)
    {
        _storage=storage;_sessions=sessions;_restrictions=restrictions;
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("AccommodationTestManager/"+UpdatePolicy.InstalledVersion);
        _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/vnd.github+json"));
    }
    public void AssertCanInstall()
    {
        if(_sessions.IsBusy||_sessions.Current is not null||_storage.ListSessions(true).Count!=0)
            throw new InvalidOperationException("Finish/export or resolve all unfinished sessions before installing an update. Files will not be reset.");
        if(_restrictions.PendingIds().Count!=0)throw new InvalidOperationException("Restore all unresolved machine controls before updating.");
    }
    public async Task<AvailableUpdate?> CheckAsync()
    {
        using var request=new HttpRequestMessage(HttpMethod.Get,"https://api.github.com/repos/"+UpdatePolicy.Repository+"/releases?per_page=30");
        using var response=await _http.SendAsync(request);response.EnsureSuccessStatusCode();
        using var json=JsonDocument.Parse(await response.Content.ReadAsStringAsync());
        var candidates=new List<(Version Sort,AvailableUpdate Update)>();
        foreach(var release in json.RootElement.EnumerateArray())
        {
            if(release.GetProperty("draft").GetBoolean())continue;
            string tag=release.GetProperty("tag_name").GetString()??"";Version version;
            try{version=UpdatePolicy.ReleaseVersion(tag);}catch{continue;}
            if(version<=UpdatePolicy.ReleaseVersion(UpdatePolicy.InstalledVersion))continue;
            var assets=release.GetProperty("assets").EnumerateArray().ToArray();
            var installers=assets.Where(a=>Regex.IsMatch(a.GetProperty("name").GetString()??"",@"^AccommodationTestManager-Setup-[A-Za-z0-9.-]+\.exe$")).ToArray();
            if(installers.Length!=1)continue;
            var installer=installers[0];string name=installer.GetProperty("name").GetString()!;
            var sums=assets.Where(a=>a.GetProperty("name").GetString()==name+".sha256").ToArray();if(sums.Length!=1)continue;
            long size=installer.GetProperty("size").GetInt64();if(size<1||size>300L*1024*1024)continue;
            var url=new Uri(installer.GetProperty("browser_download_url").GetString()!);var checksum=new Uri(sums[0].GetProperty("browser_download_url").GetString()!);
            UpdatePolicy.ValidateAssetUri(url);UpdatePolicy.ValidateAssetUri(checksum);
            if(!url.AbsolutePath.StartsWith("/"+UpdatePolicy.Repository+"/releases/download/"+tag+"/",StringComparison.Ordinal))throw new InvalidDataException("Release/asset tag mismatch.");
            string? digest=installer.TryGetProperty("digest",out var d)?d.GetString():null;
            candidates.Add((version,new(tag,name,url,checksum,new Uri("https://github.com/"+UpdatePolicy.Repository+"/releases/tag/"+tag),size,digest)));
        }
        return candidates.OrderByDescending(x=>x.Sort).Select(x=>x.Update).FirstOrDefault();
    }
    public async Task<string> DownloadAsync(AvailableUpdate update)
    {
        AssertCanInstall();UpdatePolicy.ValidateAssetUri(update.Download);UpdatePolicy.ValidateAssetUri(update.Checksum);
        using var sumResponse=await _http.GetAsync(update.Checksum,HttpCompletionOption.ResponseHeadersRead);sumResponse.EnsureSuccessStatusCode();
        using var sumStream=await sumResponse.Content.ReadAsStreamAsync();
        byte[] sumBytes=new byte[4097];int count=0,read;
        while(count<sumBytes.Length&&(read=await sumStream.ReadAsync(sumBytes.AsMemory(count)))>0)count+=read;
        if(count==sumBytes.Length)throw new InvalidDataException("Checksum response too large.");
        string expected=UpdatePolicy.ParseChecksum(System.Text.Encoding.UTF8.GetString(sumBytes,0,count).TrimStart('\uFEFF'),update.FileName);
        if(update.Digest is not null&&update.Digest!="sha256:"+expected)throw new InvalidDataException("GitHub asset digest and checksum disagree.");
        string folder=Path.Combine(_storage.Root,"Updates",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(folder);
        string file=Path.Combine(folder,update.FileName);string partial=file+".partial";
        try
        {
            using var response=await _http.GetAsync(update.Download,HttpCompletionOption.ResponseHeadersRead);response.EnsureSuccessStatusCode();
            using var input=await response.Content.ReadAsStreamAsync();
            using(var output=new FileStream(partial,FileMode.CreateNew,FileAccess.Write,FileShare.None,65536,true))
            {
                byte[] buffer=new byte[65536];long total=0;
                while((read=await input.ReadAsync(buffer))>0){total+=read;if(total>update.Size||total>300L*1024*1024)throw new IOException("Installer download exceeded its expected size.");await output.WriteAsync(buffer.AsMemory(0,read));}
                if(total!=update.Size)throw new IOException("Incomplete installer download.");await output.FlushAsync();output.Flush(true);
            }
            using(var data=new FileStream(partial,FileMode.Open,FileAccess.Read,FileShare.Read))
                if(Convert.ToHexString(await SHA256.HashDataAsync(data)).ToLowerInvariant()!=expected)throw new IOException("Installer checksum did not match; nothing will be launched.");
            AssertCanInstall();File.Move(partial,file);
            // Preserve Internet origin so the updater does not bypass Windows reputation checks.
            File.WriteAllText(file+":Zone.Identifier","[ZoneTransfer]\r\nZoneId=3\r\nHostUrl="+update.Download.AbsoluteUri+"\r\nReferrerUrl="+update.ReleasePage.AbsoluteUri+"\r\n");
            _verified[file]=expected;return file;
        }
        catch {try{File.Delete(partial);File.Delete(file);}catch{}throw;}
    }
    public Process Launch(string path,AvailableUpdate update)
    {
        AssertCanInstall();
        string full=Path.GetFullPath(path);string root=Path.GetFullPath(Path.Combine(_storage.Root,"Updates"))+Path.DirectorySeparatorChar;
        if(!full.StartsWith(root,StringComparison.OrdinalIgnoreCase)||Path.GetFileName(full)!=update.FileName)throw new IOException("Unexpected installer path.");
        for(DirectoryInfo? d=new DirectoryInfo(Path.GetDirectoryName(full)!);d is not null;d=d.Parent)if((d.Attributes&FileAttributes.ReparsePoint)!=0)throw new IOException("Update path must not contain links.");
        if((File.GetAttributes(full)&FileAttributes.ReparsePoint)!=0)throw new IOException("Installer must not be a link.");
        using var locked=new FileStream(full,FileMode.Open,FileAccess.Read,FileShare.Read);
        string hash=Convert.ToHexString(SHA256.HashData(locked)).ToLowerInvariant();
        // The expected hash was verified at download time and is retained only in this process.
        if(!_verified.TryGetValue(full,out string? expected)||hash!=expected)throw new IOException("Downloaded installer changed. Check/download again.");
        return Process.Start(new ProcessStartInfo(full){UseShellExecute=true})??throw new IOException("Installer did not start.");
    }
    private readonly Dictionary<string,string> _verified=new(StringComparer.OrdinalIgnoreCase);
    public void Dispose()=>_http.Dispose();
}
