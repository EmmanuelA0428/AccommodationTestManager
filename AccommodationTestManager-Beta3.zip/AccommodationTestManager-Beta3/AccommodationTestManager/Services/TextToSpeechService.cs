﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;

namespace AccommodationTestManager.Services;

public sealed class TextToSpeechService : IDisposable
{
    // SAPI flags: asynchronous, replace old speech, plain text.
    private const int SpeechFlags = 1 | 2 | 16;
    private const int SpeechRunning = 2;

    private readonly Dispatcher _dispatcher;
    private readonly DispatcherTimer _windowTracker;
    private readonly HashSet<string> _approvedProcesses;
    private readonly int _maximumSelectionLength;
    private readonly int _ownProcessId = Environment.ProcessId;

    private dynamic? _voice;
    private IntPtr _lastApprovedWindow;

    private bool _isPaused;
    private bool _capturing;
    private bool _disposed;

    private int _rate;
    private int _volume = 80;

    public event EventHandler<string>? StatusChanged;

    public bool IsAvailable => _voice is not null;
    public bool IsPaused => _isPaused;

    public string? InitializationError { get; private set; }

    // ------------------------------------------------------------
    // Initialization
    // ------------------------------------------------------------

    public TextToSpeechService(
        IEnumerable<string> approvedProcesses,
        int maximumSelectionLength = 10000)
    {
        _dispatcher = Application.Current?.Dispatcher
            ?? throw new InvalidOperationException(
                "Create this service after the WPF application starts.");

        _dispatcher.VerifyAccess();

        _approvedProcesses = new HashSet<string>(
            StringComparer.OrdinalIgnoreCase);

        foreach (string name in approvedProcesses)
            _approvedProcesses.Add(NormalizeProcessName(name));

        _maximumSelectionLength = Math.Max(
            1, maximumSelectionLength);

        try
        {
            Type sapiType = Type.GetTypeFromProgID("SAPI.SpVoice")
                ?? throw new InvalidOperationException(
                    "Windows SAPI.SpVoice was not found.");

            _voice = Activator.CreateInstance(sapiType)
                ?? throw new InvalidOperationException(
                    "The Windows speech engine could not be created.");

            _voice.Rate = _rate;
            _voice.Volume = _volume;
        }
        catch (Exception ex)
        {
            InitializationError = ex.Message;
            ReleaseVoice();
        }

        _windowTracker = new DispatcherTimer
        {
            Interval = TimeSpan.FromMilliseconds(200)
        };

        _windowTracker.Tick += TrackForegroundWindow;
        _windowTracker.Start();
    }

    public int Rate
    {
        get => _rate;
        set
        {
            CheckAccess();
            int newRate = Math.Clamp(value, -10, 10);

            if (TryVoiceAction(() => _voice!.Rate = newRate))
                _rate = newRate;
        }
    }

    public int Volume
    {
        get => _volume;
        set
        {
            CheckAccess();
            int newVolume = Math.Clamp(value, 0, 100);

            if (TryVoiceAction(() => _voice!.Volume = newVolume))
                _volume = newVolume;
        }
    }

    public void SetApprovedProcesses(
        IEnumerable<string> processNames)
    {
        CheckAccess();

        _approvedProcesses.Clear();

        foreach (string name in processNames)
            _approvedProcesses.Add(NormalizeProcessName(name));

        _lastApprovedWindow = IntPtr.Zero;
    }

    // ------------------------------------------------------------
    // Read selected text
    // ------------------------------------------------------------

    public async Task<bool> SpeakSelectedTextAsync()
    {
        CheckAccess();

        if (!CheckVoice())
            return false;

        if (_capturing)
        {
            Report("Already getting selected text.");
            return false;
        }

        IntPtr target = _lastApprovedWindow;

        if (target == IntPtr.Zero ||
            !IsWindow(target) ||
            !IsApprovedWindow(target))
        {
            Report(
                "Select text in the approved Word or Edge window, " +
                "then click Read.");
            return false;
        }

        _capturing = true;
        uint? capturedSequence = null;

        try
        {
            Report("Getting selected text…");

            // Bring the remembered test window back to the foreground.
            SetForegroundWindow(target);

            await Task.Delay(150);
            CheckAccess();

            // Verify actual focus, not just the API return value.
            if (GetForegroundWindow() != target ||
                !IsApprovedWindow(target))
            {
                Report("The test window could not be activated.");
                return false;
            }

            // Existing physical modifier keys can alter Ctrl+C.
            if (AnyModifierKeyDown())
            {
                Report(
                    "Release Ctrl, Shift, Alt, and Windows keys, " +
                    "then try again.");
                return false;
            }

            uint previousSequence = GetClipboardSequenceNumber();

            SendCopyCommand();

            var capture = await WaitForCopiedTextAsync(
                previousSequence, target);

            CheckAccess();

            if (_disposed)
                return false;

            if (capture is null)
            {
                Report(
                    "No new text was copied. Select text and try again.");
                return false;
            }

            capturedSequence = capture.Value.Sequence;

            string text = capture.Value.Text
                .Replace("\a", string.Empty)
                .Trim();

            // Clear only if the clipboard still contains this capture.
            ClearCapturedClipboard(capture.Value.Sequence);

            if (text.Length == 0)
            {
                Report("The selection contains no readable text.");
                return false;
            }

            if (text.Length > _maximumSelectionLength)
            {
                Report(
                    $"Select no more than " +
                    $"{_maximumSelectionLength:N0} characters.");
                return false;
            }

            return SpeakText(text, "Reading selected text.");
        }
        catch (ObjectDisposedException)
        {
            return false;
        }
        catch (Exception ex)
        {
            Report($"Read selection failed: {ex.Message}");
            return false;
        }
        finally
        {
            if (capturedSequence.HasValue && !_disposed)
                ClearCapturedClipboard(capturedSequence.Value);

            _capturing = false;
        }
    }

    // Bypasses selection capture to test the speech engine itself.
    public bool SpeakTestPhrase()
    {
        CheckAccess();

        return SpeakText(
            "Hello. This is a test of the accommodation speech system.",
            "Reading the test phrase.");
    }

    private bool SpeakText(string text, string status)
    {
        return TryVoiceAction(() =>
        {
            // Resume the actual engine before replacing paused speech.
            ResumeEngineIfPaused();

            _voice!.Speak(text, SpeechFlags);
            Report(status);
        });
    }

    // ------------------------------------------------------------
    // Pause, resume, and stop
    // ------------------------------------------------------------

    public bool Pause()
    {
        CheckAccess();

        return TryVoiceAction(() =>
        {
            if (_isPaused)
            {
                Report("Speech is already paused.");
                return;
            }

            int runningState = (int)_voice!.Status.RunningState;

            // Do not accumulate a pause while the engine is idle.
            if (runningState != SpeechRunning)
            {
                Report("No speech is currently playing.");
                return;
            }

            _voice.Pause();
            _isPaused = true;

            Report("Speech paused.");
        });
    }

    public bool Resume()
    {
        CheckAccess();

        return TryVoiceAction(() =>
        {
            if (!_isPaused)
            {
                Report("Speech is not paused.");
                return;
            }

            ResumeEngineIfPaused();
            Report("Speech resumed.");
        });
    }

    public bool TogglePause()
    {
        CheckAccess();
        return _isPaused ? Resume() : Pause();
    }

    public bool Stop()
    {
        CheckAccess();

        return TryVoiceAction(() =>
        {
            ResumeEngineIfPaused();

            // Purge the queue without introducing another pause.
            _voice!.Speak(string.Empty, SpeechFlags);

            Report("Speech stopped.");
        });
    }

    private void ResumeEngineIfPaused()
    {
        if (!_isPaused)
            return;

        _voice!.Resume();

        // Change our flag only after the engine successfully resumes.
        _isPaused = false;
    }

    private bool CheckVoice()
    {
        if (_voice is not null)
            return true;

        Report(
            InitializationError
            ?? "Windows text-to-speech is unavailable.");

        return false;
    }

    private bool TryVoiceAction(Action action)
    {
        if (!CheckVoice())
            return false;

        try
        {
            action();
            return true;
        }
        catch (Exception ex)
        {
            Report(
                $"Speech operation failed: {ex.Message} " +
                $"(0x{ex.HResult:X8})");

            return false;
        }
    }

    // ------------------------------------------------------------
    // Approved-window tracking
    // ------------------------------------------------------------

    private void TrackForegroundWindow(object? sender, EventArgs e)
    {
        if (_disposed || _capturing)
            return;

        IntPtr window = GetForegroundWindow();

        if (window == IntPtr.Zero)
            return;

        GetWindowThreadProcessId(window, out uint processId);

        // Preserve the remembered test window when our toolbar activates.
        if (processId == (uint)_ownProcessId)
            return;

        // An unrelated external application invalidates the old target.
        _lastApprovedWindow = IsApprovedWindow(window)
            ? window
            : IntPtr.Zero;
    }

    private bool IsApprovedWindow(IntPtr window)
    {
        try
        {
            GetWindowThreadProcessId(window, out uint processId);

            if (processId == 0)
                return false;

            using Process process = Process.GetProcessById(
                checked((int)processId));

            return _approvedProcesses.Contains(
                NormalizeProcessName(process.ProcessName));
        }
        catch (ArgumentException)
        {
            // The process may have exited since the window was observed.
            return false;
        }
        catch (System.ComponentModel.Win32Exception)
        {
            return false;
        }
    }

    private static string NormalizeProcessName(string name)
    {
        return Path.GetFileNameWithoutExtension(name.Trim());
    }

    // ------------------------------------------------------------
    // Clipboard capture
    // ------------------------------------------------------------

    private async Task<(string Text, uint Sequence)?>
        WaitForCopiedTextAsync(uint previousSequence, IntPtr target)
    {
        var timeout = Stopwatch.StartNew();

        while (timeout.Elapsed < TimeSpan.FromSeconds(2))
        {
            await Task.Delay(75);

            if (_disposed)
                return null;

            // Stop if focus changes while copying is in progress.
            if (GetForegroundWindow() != target)
                return null;

            uint sequence = GetClipboardSequenceNumber();

            if (sequence == previousSequence)
                continue;

            try
            {
                if (!Clipboard.ContainsText())
                    continue;

                string text = Clipboard.GetText();

                // Ensure it did not change during the read.
                if (GetClipboardSequenceNumber() != sequence)
                    continue;

                return (text, sequence);
            }
            catch (COMException)
            {
                // Another process may briefly hold the clipboard.
                // Retry until the timeout expires.
            }
        }

        return null;
    }

    private void ClearCapturedClipboard(uint sequence)
    {
        try
        {
            if (GetClipboardSequenceNumber() == sequence)
                Clipboard.Clear();
        }
        catch (COMException)
        {
            Report(
                "Warning: the clipboard could not be cleared. " +
                "Selected text may remain there.");
        }
    }

    private static bool AnyModifierKeyDown()
    {
        return IsKeyDown(0x10)   // Shift
            || IsKeyDown(0x11)   // Ctrl
            || IsKeyDown(0x12)   // Alt
            || IsKeyDown(0x5B)   // Left Windows
            || IsKeyDown(0x5C);  // Right Windows
    }

    private static bool IsKeyDown(int virtualKey)
    {
        return (GetAsyncKeyState(virtualKey) & 0x8000) != 0;
    }

    private static void SendCopyCommand()
    {
        INPUT[] inputs =
        [
            KeyboardInput(0x11, false), // Ctrl down
            KeyboardInput(0x43, false), // C down
            KeyboardInput(0x43, true),  // C up
            KeyboardInput(0x11, true)   // Ctrl up
        ];

        uint sent = SendInput(
            (uint)inputs.Length,
            inputs,
            Marshal.SizeOf<INPUT>());

        if (sent == (uint)inputs.Length)
            return;

        int error = Marshal.GetLastWin32Error();

        // Best-effort release if Windows accepted only part of the input.
        INPUT[] releases =
        [
            KeyboardInput(0x43, true),
            KeyboardInput(0x11, true)
        ];

        SendInput(
            (uint)releases.Length,
            releases,
            Marshal.SizeOf<INPUT>());

        throw new InvalidOperationException(
            $"Ctrl+C could not be sent completely. " +
            $"Windows error: {error}. " +
            $"Keep both this app and Word/Edge non-elevated.");
    }

    private static INPUT KeyboardInput(ushort key, bool keyUp)
    {
        return new INPUT
        {
            Type = 1,
            Data = new InputUnion
            {
                Keyboard = new KEYBDINPUT
                {
                    VirtualKey = key,
                    Flags = keyUp ? 0x0002u : 0u
                }
            }
        };
    }

    // ------------------------------------------------------------
    // Status and cleanup
    // ------------------------------------------------------------

    private void Report(string message)
    {
        // Never include selected test text in status messages.
        StatusChanged?.Invoke(this, message);
    }

    private void CheckAccess()
    {
        _dispatcher.VerifyAccess();
        ObjectDisposedException.ThrowIf(_disposed, this);
    }

    public void Dispose()
    {
        _dispatcher.VerifyAccess();

        if (_disposed)
            return;

        _disposed = true;

        _windowTracker.Stop();
        _windowTracker.Tick -= TrackForegroundWindow;

        if (_voice is not null)
        {
            try
            {
                ResumeEngineIfPaused();
                _voice.Speak(string.Empty, SpeechFlags);
            }
            catch (Exception ex)
            {
                Debug.WriteLine(
                    $"Speech shutdown failed: {ex.Message}");
            }
        }

        ReleaseVoice();
        GC.SuppressFinalize(this);
    }

    private void ReleaseVoice()
    {
        if (_voice is null)
            return;

        object voiceObject = _voice;
        _voice = null;

        try
        {
            if (Marshal.IsComObject(voiceObject))
                Marshal.FinalReleaseComObject(voiceObject);
        }
        catch (Exception ex)
        {
            Debug.WriteLine(
                $"Speech-engine release failed: {ex.Message}");
        }
    }

    // ------------------------------------------------------------
    // Native Windows declarations
    // ------------------------------------------------------------

    [StructLayout(LayoutKind.Sequential)]
    private struct INPUT
    {
        public uint Type;
        public InputUnion Data;
    }

    // The mouse member gives INPUT its required native size.
    [StructLayout(LayoutKind.Explicit)]
    private struct InputUnion
    {
        [FieldOffset(0)]
        public KEYBDINPUT Keyboard;

        [FieldOffset(0)]
        public MOUSEINPUT Mouse;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct KEYBDINPUT
    {
        public ushort VirtualKey;
        public ushort ScanCode;
        public uint Flags;
        public uint Time;
        public UIntPtr ExtraInfo;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct MOUSEINPUT
    {
        public int X;
        public int Y;
        public uint MouseData;
        public uint Flags;
        public uint Time;
        public UIntPtr ExtraInfo;
    }

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetForegroundWindow(IntPtr window);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool IsWindow(IntPtr window);

    [DllImport("user32.dll")]
    private static extern uint GetWindowThreadProcessId(
        IntPtr window,
        out uint processId);

    [DllImport("user32.dll")]
    private static extern uint GetClipboardSequenceNumber();

    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int virtualKey);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern uint SendInput(
        uint count,
        INPUT[] inputs,
        int inputSize);
}