using AccommodationTestManager.Models;
using System.IO;
using System.Security.Cryptography;
using System.Text.Json;
namespace AccommodationTestManager.Services;
public sealed record BrowserPolicyReceipt(string Sha256,DateTimeOffset CheckedUtc);
public static class BrowserPolicyEvidence
{
 public static Dictionary<string,object> Required(TestSession session)
 {
  var values=new Dictionary<string,object>{["URLBlocklist"]=new[]{"*"}.Concat(session.SettingsSnapshot.DisableBrowserAI?session.SettingsSnapshot.BlockedAIUrls:[]).ToArray(),["URLAllowlist"]=session.AllowedUrls.Concat(new[]{"edge://policy"}).ToArray(),["ExtensionInstallBlocklist"]=new[]{"*"},["BrowserSignin"]=0,["SyncDisabled"]=true,["StartupBoostEnabled"]=false,["BackgroundModeEnabled"]=false};
  if(session.SettingsSnapshot.DisableBrowserAI)foreach(string name in session.BrowserAiPolicies)values[name]=false;
  return values;
 }
 public static BrowserPolicyReceipt Validate(byte[] bytes,TestSession session,DateTimeOffset modifiedUtc)
 {
  if(bytes.Length==0||bytes.Length>2*1024*1024)throw new IOException("Edge policy export must be 1 byte–2 MB.");
  if(session.PreflightStartedUtc is null||modifiedUtc<session.PreflightStartedUtc.Value.AddSeconds(-5)||modifiedUtc>DateTimeOffset.UtcNow.AddMinutes(1)||DateTimeOffset.UtcNow-modifiedUtc>TimeSpan.FromMinutes(15))throw new IOException("Export fresh policies from the current exam Edge window after this preflight started.");
  if(bytes.Length>=3&&bytes[0]==239&&bytes[1]==187&&bytes[2]==191)bytes=bytes[3..];
  using var doc=JsonDocument.Parse(bytes);JsonElement root=doc.RootElement;
  if(root.TryGetProperty("policyValues",out var policyValues))root=policyValues;
  JsonElement policies=default;bool found=false;
  foreach(string group in new[]{"chrome","edge","chromePolicies","edgePolicies"})
  {
   if(root.TryGetProperty(group,out var candidate))
   {if(candidate.TryGetProperty("policies",out var wrapped))candidate=wrapped;policies=candidate;found=true;break;}
  }
  if(!found||policies.ValueKind!=JsonValueKind.Object)throw new IOException("Unrecognized Edge export format. Handoff stays blocked; use Export to JSON in edge://policy, not the app diagnostic report.");
  foreach(var expected in Required(session))
  {
   if(!policies.TryGetProperty(expected.Key,out var item))throw new IOException("Required effective policy missing: "+expected.Key);
   foreach(string flag in new[]{"error","warning","ignored","deprecated","future","conflicts","superseded","restartRequired"})
    if(item.TryGetProperty(flag,out var problem)&&problem.ValueKind!=JsonValueKind.Null&&problem.ToString()!=""&&problem.ToString()!="False"&&problem.ToString()!="false"&&problem.ToString()!="[]")throw new IOException("Policy not accepted cleanly: "+expected.Key+" ("+flag+").");
   if(!item.TryGetProperty("level",out var level)||level.GetString()!="mandatory"||!item.TryGetProperty("scope",out var scope)||scope.GetString() is not ("machine" or "device")||!item.TryGetProperty("source",out var source)||source.GetString() is not ("platform" or "sourcePlatform"))throw new IOException("Policy must be mandatory machine/platform: "+expected.Key);
   if(item.TryGetProperty("status",out var status)&&status.GetString() is not ("OK" or "ok"))throw new IOException("Policy status is not OK: "+expected.Key);
   if(!item.TryGetProperty("value",out var value))throw new IOException("Policy value missing: "+expected.Key);
   if(expected.Value is string[] strings)
   {
    if(value.ValueKind==JsonValueKind.String){using var parsed=JsonDocument.Parse(value.GetString()!);value=parsed.RootElement.Clone();}
    if(value.ValueKind!=JsonValueKind.Array||!value.EnumerateArray().Select(v=>v.GetString()).OrderBy(v=>v,StringComparer.Ordinal).SequenceEqual(strings.OrderBy(v=>v,StringComparer.Ordinal)))throw new IOException("Effective policy differs from session configuration: "+expected.Key);
   }
   else if(expected.Value is int integer){if(value.ValueKind!=JsonValueKind.Number||!value.TryGetInt32(out int actual)||actual!=integer)throw new IOException("Effective integer policy mismatch: "+expected.Key);}
   else if(value.ValueKind is not (JsonValueKind.True or JsonValueKind.False)||value.GetBoolean()!=(bool)expected.Value)throw new IOException("Effective policy value mismatch: "+expected.Key);
  }
  // Persist only a receipt, NEVER the exported browser metadata/accounts/machine info.
  return new(Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant(),DateTimeOffset.UtcNow);
 }
}
