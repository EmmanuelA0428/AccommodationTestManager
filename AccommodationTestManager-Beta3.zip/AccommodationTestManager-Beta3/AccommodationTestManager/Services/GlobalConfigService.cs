using AccommodationTestManager.Models;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text.Json;
using System.Text.Json.Serialization;
namespace AccommodationTestManager.Services;
public sealed class GlobalManifest
{
 public int SchemaVersion {get;set;}=1;
 public int Version {get;set;}=1;
 public string CanvasUrl {get;set;}="";
 public string PositUrl {get;set;}="";
 public int SaveIntervalSeconds {get;set;}=60;
 public int SnapshotIntervalSeconds {get;set;}=180;
 public int MaximumRecoveryCopies {get;set;}=5;
 public int? DefaultTimeLimitMinutes {get;set;}
 public List<GlobalListReference> Allowlists {get;set;}=[];
}
public sealed class GlobalListReference { public string Id {get;set;}="";public string Sha256 {get;set;}=""; }
public sealed class GlobalBundle
{
 public GlobalManifest Manifest {get;set;}=new();
 public List<AllowlistConfiguration> Lists {get;set;}=[];
 public DateTimeOffset VerifiedUtc {get;set;}
 public string ManifestSha256 {get;set;}="";
}
public sealed class GlobalConfigService:IDisposable
{
 public const string Source="https://raw.githubusercontent.com/EmmanuelA0428/AccommodationTestManager/main/global-config-beta3/";
 private static readonly JsonSerializerOptions Strict=new(){PropertyNameCaseInsensitive=false,UnmappedMemberHandling=JsonUnmappedMemberHandling.Disallow};
 private readonly string _cache;
 private readonly HttpClient _http;
 private GlobalBundle? _active;
 private GlobalBundle? _cached;
 private bool _refreshing;
 public Func<bool> CanActivate {get;set;}=()=>true;
 public Action? Changed {get;set;}
 public string Status {get;private set;}="Using local configuration; no global cache loaded.";
 public GlobalConfigService(LocalStorageService storage,HttpMessageHandler? handler=null)
 { _cache=Path.Combine(storage.Root,"Configuration","global-cache-beta3.json");_http=handler is null?new HttpClient():new HttpClient(handler);_http.Timeout=TimeSpan.FromSeconds(8);_http.DefaultRequestHeaders.UserAgent.ParseAdd("AccommodationTestManager/"+UpdatePolicy.InstalledVersion); }
 private static T Parse<T>(byte[] bytes)
 {if(bytes.Length>=3&&bytes[0]==239&&bytes[1]==187&&bytes[2]==191)bytes=bytes[3..];return JsonSerializer.Deserialize<T>(bytes,Strict)??throw new IOException("Empty global configuration.");}
 public static void Validate(GlobalBundle bundle)
 {
  var m=bundle.Manifest;
  if(m.SchemaVersion!=1||m.Version<1||m.SaveIntervalSeconds<10||m.SaveIntervalSeconds>3600||m.SnapshotIntervalSeconds<m.SaveIntervalSeconds||m.SnapshotIntervalSeconds>86400||m.MaximumRecoveryCopies is <1 or >100||m.DefaultTimeLimitMinutes is <=0 or >1440)throw new IOException("Invalid global schema/version or test defaults.");
  if(m.Allowlists is null||bundle.Lists is null||m.Allowlists.Count is <2 or >20||bundle.Lists.Count!=m.Allowlists.Count||m.Allowlists.Select(x=>x.Id).Distinct().Count()!=m.Allowlists.Count)throw new IOException("Invalid global allowlist references.");
  foreach(var reference in m.Allowlists)
  {
   AllowlistService.ValidateId(reference.Id);
   if(!System.Text.RegularExpressions.Regex.IsMatch(reference.Sha256,"^[a-f0-9]{64}$"))throw new IOException("Invalid allowlist checksum.");
   var list=bundle.Lists.Single(x=>x.Id==reference.Id);AllowlistService.Validate(list);if(list.UrlPatterns.Count==0)throw new IOException("Global lists must not be empty.");
  }
  foreach(var pair in new[]{("canvas",m.CanvasUrl),("posit",m.PositUrl)})
   if(!AllowlistService.AllowsStart(bundle.Lists.Single(x=>x.Id==pair.Item1),pair.Item2)||!Uri.TryCreate(pair.Item2,UriKind.Absolute,out var url)||url.UserInfo.Length>0)throw new IOException("Global starting URL must be HTTPS and covered by its list.");
 }
 public void LoadCache()
 {
  try
  {
   if(!File.Exists(_cache))return;if(new FileInfo(_cache).Length>2*1024*1024)throw new IOException("Cache exceeds size limit.");
   var bundle=Parse<GlobalBundle>(File.ReadAllBytes(_cache));Validate(bundle);_cached=bundle;_active=bundle;
   Status=$"Using cached global v{bundle.Manifest.Version}; last verified {bundle.VerifiedUtc:u}.";
  }
  catch(Exception ex){Status="Global cache invalid/unreadable; using local settings. "+ex.Message;}
 }
 private async Task<byte[]> Download(string path,CancellationToken token)
 {
  using var response=await _http.GetAsync(Source+path,HttpCompletionOption.ResponseHeadersRead,token);response.EnsureSuccessStatusCode();
  using var input=await response.Content.ReadAsStreamAsync(token);using var output=new MemoryStream();byte[] buffer=new byte[16384];int count;
  while((count=await input.ReadAsync(buffer,token))>0){if(output.Length+count>512*1024)throw new IOException("Global file exceeds 512 KB limit.");output.Write(buffer,0,count);}return output.ToArray();
 }
 public async Task RefreshAsync()
 {
  if(_refreshing)return;_refreshing=true;
  try
  {
   using var timeout=new CancellationTokenSource(TimeSpan.FromSeconds(8));
   byte[] bytes=await Download("manifest.json",timeout.Token);var m=Parse<GlobalManifest>(bytes);
   if(m.SchemaVersion!=1||m.Version<1||m.Allowlists is null||m.Allowlists.Count is <2 or >20)throw new IOException("Unsupported global manifest.");
   var bundle=new GlobalBundle{Manifest=m,VerifiedUtc=DateTimeOffset.UtcNow,ManifestSha256=Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant()};
   if(_cached is not null&&(m.Version<_cached.Manifest.Version||m.Version==_cached.Manifest.Version&&bundle.ManifestSha256!=_cached.ManifestSha256))throw new IOException("Global rollback or changed manifest without a version bump rejected.");
   foreach(var entry in m.Allowlists)
   {
    AllowlistService.ValidateId(entry.Id);byte[] listBytes=await Download("allowlists/"+entry.Id+".json",timeout.Token);
    if(Convert.ToHexString(SHA256.HashData(listBytes)).ToLowerInvariant()!=entry.Sha256)throw new IOException("Global allowlist checksum mismatch; previous configuration retained.");
    var list=Parse<AllowlistConfiguration>(listBytes);if(list.Id!=entry.Id)throw new IOException("Global allowlist ID mismatch.");bundle.Lists.Add(list);
   }
   Validate(bundle);
   // One atomic cache file: never publish half of a multi-file policy update.
   if(JsonSerializer.SerializeToUtf8Bytes(bundle,LocalStorageService.JsonOptions).Length>2*1024*1024)throw new IOException("Combined global cache exceeds 2 MB limit.");
   LocalStorageService.WriteJson(_cache,bundle);_cached=bundle;
   if(CanActivate()){_active=bundle;Status=$"Global v{m.Version} verified {bundle.VerifiedUtc:u}; active for new sessions.";}
   else Status=$"Global v{m.Version} cached; active session unchanged. Applies after the session or next launch.";
  }
  catch(Exception ex){Status=(_active is null?"Using local settings":$"Using cached global v{_active.Manifest.Version} (verified {_active.VerifiedUtc:u})")+"; refresh unavailable: "+ex.Message;}
  finally{_refreshing=false;Changed?.Invoke();}
 }
 public void ActivatePending()
 {if(_cached is not null&&CanActivate()&&_active!=_cached){_active=_cached;Status=$"Cached global v{_active.Manifest.Version} active for new sessions.";Changed?.Invoke();}}
 public AppSettings ApplyTo(AppSettings local)
 {
  var value=LocalStorageService.Clone(local);if(!local.GlobalConfigEnabled||_active is null)return value;
  var m=_active.Manifest;value.CanvasUrl=m.CanvasUrl;value.PositUrl=m.PositUrl;value.SaveIntervalSeconds=m.SaveIntervalSeconds;value.SnapshotIntervalSeconds=m.SnapshotIntervalSeconds;value.MaximumRecoveryCopies=m.MaximumRecoveryCopies;value.DefaultTimeLimitMinutes=m.DefaultTimeLimitMinutes;value.GlobalConfigVersion=m.Version;return value;
 }
 public List<AllowlistConfiguration>? Lists(bool enabled)=>!enabled||_active is null?null:_active.Lists.Select(LocalStorageService.Clone).ToList();
 public void Dispose()=>_http.Dispose();
}
