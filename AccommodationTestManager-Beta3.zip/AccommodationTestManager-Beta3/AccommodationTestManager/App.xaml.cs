using AccommodationTestManager.Services;
using AccommodationTestManager.Views;
using System.Threading;
using System.IO;
using System.Windows.Threading;
using AccommodationTestManager.Models;
using System.Windows;

namespace AccommodationTestManager;
public partial class App : Application
{
    private Mutex? _instance;
    public LocalStorageService Storage { get; private set; } = null!;
    public SettingsService Settings { get; private set; } = null!;
    public AllowlistService Allowlists { get; private set; } = null!;
    public RestrictionService Restrictions { get; private set; } = null!;
    public ThemeService Theme { get; private set; } = null!;
    public GlobalConfigService GlobalConfig {get;private set;}=null!;
    public SessionService Sessions { get; private set; } = null!;
    public CloudSyncService? CloudSync {get;private set;}
    private DispatcherTimer? _syncTimer;
    private DispatcherTimer? _syncSoon;
    public MetadataOutbox? MetadataQueue { get; private set; }
    public string MetadataSyncStatus { get; private set; } = "Cloud connection not configured; tests remain local.";
    private void QueueSessionMetadata(bool inventory = false)
    {
        try
        {
            MetadataQueue ??= new(Storage);
            foreach (var entry in (inventory || Sessions.Current is null) ? Storage.ListSessions() : Sessions.Current is not null && Sessions.Folder is not null ? new List<AccommodationTestManager.Models.SessionEntry> { new(Sessions.Folder, Sessions.Current) } : new List<AccommodationTestManager.Models.SessionEntry>())
            {
                if (entry.Session.DeviceId != Settings.Current.DeviceId || entry.Session.CreatedUtc == default) continue;
                MetadataQueue.Enqueue(MetadataOutbox.Project(Storage, entry, Settings.Current.DeviceId));
            }
            MetadataSyncStatus = CloudSync?.Status ?? $"Cloud starting · {MetadataQueue.Pending().Count} metadata records queued locally. No files uploaded.";
        }
        catch (Exception) { MetadataSyncStatus = "Metadata sync paused; queue retained for review. Local testing/restoration remains available."; }
    }
    public static App Host => (App)Current;
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        _instance = new Mutex(true, @"Local\AccommodationTestManager-Beta1", out bool first);
        if (!first) { MessageBox.Show("Accommodation Test Manager is already running in this Windows session."); Shutdown(); return; }
        try
        {
            Storage = new(); Settings = new(Storage); Settings.Load(); Allowlists=new(Storage);Allowlists.Initialize(); Restrictions=new(); Theme = new(Settings); Theme.Apply();
            if (!Settings.IsRegistered && !StaffDialogs.Register(Settings)) { Shutdown(); return; }
            GlobalConfig=new(Storage);GlobalConfig.LoadCache();Settings.GlobalOverlay=GlobalConfig.ApplyTo;Allowlists.GlobalLists=()=>GlobalConfig.Lists(Settings.Current.GlobalConfigEnabled);
            Sessions = new(Storage, Settings, Allowlists, Restrictions);
            Sessions.Changed += (_, _) => {QueueSessionMetadata();if(CloudSync is not null){_syncSoon?.Stop();_syncSoon?.Start();}};
            QueueSessionMetadata(inventory: true);
            GlobalConfig.CanActivate=()=>Sessions.Current is null&&!Sessions.IsBusy;
            try
            {
                var options=LocalStorageService.ReadJson<FirebaseClientOptions>(Path.Combine(AppContext.BaseDirectory,"Configuration","firebase-client.json"));
                var defaults=new CloudDefaultsCache(Storage);
                CloudSync=new(new FirebaseRestClient(options,new WindowsCloudIdentityStore(Storage.Root)),MetadataQueue!,defaults,Settings.Current.DeviceId,()=>Sessions.Current is null&&!Sessions.IsBusy);
                Settings.GlobalOverlay=local=>defaults.ApplyTo(GlobalConfig.ApplyTo(local));
                CloudSync.Changed+=()=>MetadataSyncStatus=CloudSync.Status;
                _syncSoon=new DispatcherTimer{Interval=TimeSpan.FromSeconds(5)};
                _syncSoon.Tick+=async(_,_)=>{_syncSoon.Stop();QueueSessionMetadata();await CloudSync.SyncAsync();};
                _syncTimer=new DispatcherTimer{Interval=TimeSpan.FromMinutes(5)};
                _syncTimer.Tick+=async(_,_)=>{QueueSessionMetadata();await CloudSync.SyncAsync();};_syncTimer.Start();
            }
            catch(Exception){MetadataSyncStatus="Cloud initialization paused; local testing and restoration remain available. Existing cloud data retained.";}
            var window = new Views.MainWindow(); MainWindow = window; window.Show(); ShutdownMode = ShutdownMode.OnLastWindowClose;
            if(CloudSync is not null) _ = CloudSync.SyncAsync();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Startup stopped to preserve existing data. No session was reset.\n\n" + ex.Message, "Staff review required", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
        }
    }
    protected override void OnExit(ExitEventArgs e)
    {
        _syncSoon?.Stop();_syncTimer?.Stop();CloudSync?.Dispose();
        Sessions?.Dispose(); GlobalConfig?.Dispose(); Theme?.Dispose(); _instance?.Dispose(); base.OnExit(e);
    }
}
