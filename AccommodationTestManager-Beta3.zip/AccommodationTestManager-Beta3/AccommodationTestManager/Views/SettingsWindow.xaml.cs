using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using Microsoft.Win32;
using System.IO;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace AccommodationTestManager.Views;
public partial class SettingsWindow:Window
{
    private AppSettings _draft;
    private List<AllowlistConfiguration> _lists;
    private AllowlistConfiguration? _editing;
    private readonly string _staff;
    private bool _busy;
    private AvailableUpdate? _available;
    private readonly UpdateService _updates;
    public SettingsWindow(string staff)
    {
        _staff=staff;_draft=LocalStorageService.Clone(App.Host.Settings.Current);_lists=App.Host.Allowlists.LoadAllLocal().Select(LocalStorageService.Clone).ToList();
        _updates=new UpdateService(App.Host.Storage,App.Host.Sessions,App.Host.Restrictions);
        InitializeComponent();GlobalStatusText.Text=App.Host.GlobalConfig?.Status??"Local configuration";UpdateVersionText.Text="Installed: "+UpdatePolicy.InstalledVersion;BindDraft();Loaded+=(_,_)=>{Height=Math.Min(640,SystemParameters.WorkArea.Height-48);Width=Math.Min(820,SystemParameters.WorkArea.Width-48);};
    }
    private void BindDraft()
    {
        DataContext=_draft;StaffGrid.ItemsSource=_draft.StaffMembers;ApplicationGrid.ItemsSource=_draft.ApprovedApplications;
        ThemePicker.ItemsSource=new[]{"System","Light","Dark"};DefaultMinutes.Text=_draft.DefaultTimeLimitMinutes?.ToString()??"";
        _editing=null;ListPicker.ItemsSource=_lists;ListPicker.SelectedIndex=_lists.Count>0?0:-1;
        AiEditor.Text=string.Join(Environment.NewLine,_draft.BlockedAIUrls);
        CapabilityText.Text=App.Host.Restrictions.CapabilitySummary();SaveButton.IsEnabled=App.Host.Sessions.Current is null;
    }
    private void CaptureUrls(){if(_editing is not null)_editing.UrlPatterns=UrlEditor.Text.Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries).ToList();}
    private void List_Changed(object sender,SelectionChangedEventArgs e)
    {CaptureUrls();_editing=ListPicker.SelectedItem as AllowlistConfiguration;UrlEditor.Text=_editing is null?"":string.Join(Environment.NewLine,_editing.UrlPatterns);}
    private void AddStaff_Click(object sender,RoutedEventArgs e)
    {string name=NewStaffName.Text.Trim();if(name.Length==0)return;_draft.StaffMembers.Add(new(){Name=name});StaffGrid.Items.Refresh();NewStaffName.Clear();}
    private void AddList_Click(object sender,RoutedEventArgs e)
    {
        try{string id=NewListId.Text.Trim().ToLowerInvariant();AllowlistService.ValidateId(id);if(_lists.Any(x=>x.Id==id))throw new InvalidOperationException("List already exists.");CaptureUrls();var list=new AllowlistConfiguration{Id=id};_lists.Add(list);ListPicker.Items.Refresh();ListPicker.SelectedItem=list;NewListId.Clear();}
        catch(Exception ex){ErrorText.Text=ex.Message;}
    }
    private void ImportUrls_Click(object sender,RoutedEventArgs e)
    {var d=new OpenFileDialog{Filter="Text files|*.txt;*.csv|All files|*.*"};if(d.ShowDialog(this)==true){try{UrlEditor.Text=File.ReadAllText(d.FileName);}catch(Exception ex){ErrorText.Text=ex.Message;}}}
    private void AddApplication_Click(object sender,RoutedEventArgs e)
    {
        var d=new OpenFileDialog{Filter="Windows applications|*.exe",Title="Choose approved installed application"};if(d.ShowDialog(this)!=true)return;
        _draft.ApprovedApplications.Add(new(){Name=Path.GetFileNameWithoutExtension(d.FileName),Executable=d.FileName});ApplicationGrid.Items.Refresh();
    }
    private void RemoveApplication_Click(object sender,RoutedEventArgs e)
    {if(ApplicationGrid.SelectedItem is ApprovedApplication app){_draft.ApprovedApplications.Remove(app);ApplicationGrid.Items.Refresh();}}
    private void Save_Click(object sender,RoutedEventArgs e)
    {
        if(App.Host.Sessions.Current is not null){ErrorText.Text="Operational settings can only be changed between sessions.";return;}
        try
        {
            if(!StaffGrid.CommitEdit(DataGridEditingUnit.Cell,true)||!StaffGrid.CommitEdit(DataGridEditingUnit.Row,true)||!ApplicationGrid.CommitEdit(DataGridEditingUnit.Cell,true)||!ApplicationGrid.CommitEdit(DataGridEditingUnit.Row,true)||HasValidationError(this))throw new InvalidOperationException("Correct invalid settings fields before saving.");CaptureUrls();
            if(!string.IsNullOrWhiteSpace(DefaultMinutes.Text)&&(!int.TryParse(DefaultMinutes.Text,out int minutes)||minutes<1||minutes>1440))throw new InvalidOperationException("Default minutes must be blank or 1–1440.");
            _draft.DefaultTimeLimitMinutes=string.IsNullOrWhiteSpace(DefaultMinutes.Text)?null:int.Parse(DefaultMinutes.Text);
            if(!_draft.StaffMembers.Any(x=>x.Active))throw new InvalidOperationException("Keep at least one active staff member.");
            foreach(var list in _lists)AllowlistService.Validate(list);
            _draft.BlockedAIUrls=AllowlistService.Normalize(AiEditor.Text.Split(['\r','\n'],StringSplitOptions.RemoveEmptyEntries)).ToArray();
            if(_draft.BlockedAIUrls.Length>999)throw new InvalidOperationException("AI block filters limited to 999.");
            foreach(var app in _draft.ApprovedApplications)if(!File.Exists(app.Executable)||Path.GetExtension(app.Executable).ToLowerInvariant()!=".exe"||string.IsNullOrWhiteSpace(app.Name))throw new InvalidOperationException("Approved applications must have a name and an existing .exe.");
            foreach(var pair in new[]{("canvas",_draft.CanvasUrl),("posit",_draft.PositUrl)})
                if(!string.IsNullOrWhiteSpace(pair.Item2)&&!AllowlistService.AllowsStart(_lists.Single(x=>x.Id==pair.Item1),pair.Item2))throw new InvalidOperationException(pair.Item1+" starting URL is not covered by its allowlist.");
            if(NewPin.Password.Length>0&&(NewPin.Password!=ConfirmPin.Password||NewPin.Password.Length<6||!NewPin.Password.All(char.IsDigit)))throw new InvalidOperationException("New PIN must match confirmation and contain at least six digits.");
            // Validate settings BEFORE touching list files; restore prior list bytes if any save fails.
            var previous=LocalStorageService.Clone(App.Host.Settings.Current);var listBackups=_lists.ToDictionary(x=>x.Id,x=>File.Exists(Path.Combine(App.Host.Allowlists.Folder,x.Id+".json"))?File.ReadAllBytes(Path.Combine(App.Host.Allowlists.Folder,x.Id+".json")):null);
            _draft.ConfigVersion++;
            try
            {
                App.Host.Settings.Update(_draft);
                foreach(var list in _lists){list.Version++;App.Host.Allowlists.Save(list);}
                if(NewPin.Password.Length>0)App.Host.Settings.ChangePin(NewPin.Password);
            }
            catch
            {
                App.Host.Settings.Update(previous);
                foreach(var entry in listBackups){string path=Path.Combine(App.Host.Allowlists.Folder,entry.Key+".json");if(entry.Value is null)File.Delete(path);else File.WriteAllBytes(path,entry.Value);}
                throw;
            }
            App.Host.Theme.Apply();DialogResult=true;
        }
        catch(Exception ex){ErrorText.Text=ex.Message;}
    }
    private static bool HasValidationError(DependencyObject value)
    {
        if(Validation.GetHasError(value))return true;
        for(int i=0;i<VisualTreeHelper.GetChildrenCount(value);i++)if(HasValidationError(VisualTreeHelper.GetChild(value,i)))return true;
        return false;
    }
    private void Cancel_Click(object sender,RoutedEventArgs e){if(!_busy)Close();}
    private async void RefreshGlobal_Click(object sender,RoutedEventArgs e)
    {
        if(_busy||App.Host.GlobalConfig is null)return;
        if(!App.Host.Settings.Current.GlobalConfigEnabled){GlobalStatusText.Text="Save the enabled checkbox and reopen Settings before refreshing.";return;}
        _busy=true;RefreshGlobalButton.IsEnabled=false;
        try{await App.Host.GlobalConfig.RefreshAsync();GlobalStatusText.Text=App.Host.GlobalConfig.Status;}finally{_busy=false;RefreshGlobalButton.IsEnabled=true;}
    }
    private async Task LegacyAction(string action)
    {
        if(_busy||App.Host.Sessions.IsBusy)return;
        string text=action=="Assess"?"Read-only assessment of legacy evidence and missing USB service fields. No repair or snapshot deletion.":action=="RestoreLegacyRecorded"?"Restore ONLY values recorded in old snapshots using the corrected writer. This cannot recover unrecorded values and will NOT clear the review gate. Save/close all test/browser work first.":"Confirm that a qualified administrator has independently reviewed/repaired all affected registry branches, including missing unrecorded service values and unrelated policies? The app cannot prove recovery of values it never captured. Do not approve merely because USB/Wi-Fi works.";
        if(MessageBox.Show(this,text,"Legacy machine review",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        _busy=true;try{await App.Host.Restrictions.LegacyActionAsync(action);new DiagnosticsWindow(){Owner=this}.ShowDialog();}catch(Exception ex){ErrorText.Text=ex.Message;}finally{_busy=false;}
    }
    private async void LegacyAssess_Click(object sender,RoutedEventArgs e)=>await LegacyAction("Assess");
    private async void LegacyRestore_Click(object sender,RoutedEventArgs e)=>await LegacyAction("RestoreLegacyRecorded");
    private async void LegacyReview_Click(object sender,RoutedEventArgs e)=>await LegacyAction("ApproveReview");
    private void Diagnostics_Click(object sender,RoutedEventArgs e)=>new DiagnosticsWindow(App.Host.Sessions.Current?.Id){Owner=this}.ShowDialog();
    private void Sessions_Click(object sender,RoutedEventArgs e){new RecordsWindow(_staff){Owner=this}.ShowDialog();}
    private void Reload_Click(object sender,RoutedEventArgs e)
    {
        if(App.Host.Sessions.Current is not null){ErrorText.Text="Finish/resolve the session before reloading settings.";return;}
        if(MessageBox.Show(this,"Discard unsaved settings changes and reload saved configuration?","Reload",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
        try{App.Host.Settings.Reload();_draft=LocalStorageService.Clone(App.Host.Settings.Current);_lists=App.Host.Allowlists.LoadAllLocal();BindDraft();App.Host.Theme.Apply();}catch(Exception ex){ErrorText.Text=ex.Message;}
    }
    private async void EmergencyRestore_Click(object sender,RoutedEventArgs e)
    {
        if(_busy||App.Host.Sessions.IsBusy)return;
        if(MessageBox.Show(this,"Restore all unresolved machine snapshots? This does NOT finish the exam or delete any files. Tests must remain with staff until restrictions are reapplied/verified.","Emergency restore",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        _busy=true;
        try{foreach(string id in App.Host.Restrictions.PendingIds())await App.Host.Restrictions.RestoreAsync(id);await App.Host.Sessions.MarkEmergencyRestoreAsync();ErrorText.Text="Recorded machine state restored. Session files preserved.";}
        catch(Exception ex){ErrorText.Text=ex.Message;}
        finally{_busy=false;CapabilityText.Text=App.Host.Restrictions.CapabilitySummary();}
    }
    private async void CheckUpdates_Click(object sender,RoutedEventArgs e)
    {
        if(_busy)return;_busy=true;CheckUpdatesButton.IsEnabled=false;InstallUpdateButton.IsEnabled=false;
        UpdateStatusText.Text="Checking public GitHub releases…";
        try{_available=await _updates.CheckAsync();UpdateStatusText.Text=_available is null?"You have the latest recognized Beta 3 release.":"Available: "+_available.Version+" · "+Math.Ceiling(_available.Size/1024d/1024d)+" MB";}
        catch(Exception ex){_available=null;UpdateStatusText.Text="Update check unavailable. Your current app/settings are unchanged.\n"+ex.Message;}
        finally{_busy=false;CheckUpdatesButton.IsEnabled=true;InstallUpdateButton.IsEnabled=_available is not null;}
    }
    private async void InstallUpdate_Click(object sender,RoutedEventArgs e)
    {
        if(_busy||_available is null)return;
        try{_updates.AssertCanInstall();}catch(Exception ex){UpdateStatusText.Text=ex.Message;return;}
        if(MessageBox.Show(this,"Download the update from this project's GitHub release? Unsaved Settings changes will not be saved. This is an unsigned beta; Windows may warn or block installation. Saved exam sessions/settings are preserved.","Download update",MessageBoxButton.YesNo,MessageBoxImage.Warning)!=MessageBoxResult.Yes)return;
        _busy=true;InstallUpdateButton.IsEnabled=false;CheckUpdatesButton.IsEnabled=false;
        try
        {
            UpdateStatusText.Text="Downloading and verifying installer…";
            string path=await _updates.DownloadAsync(_available);
            UpdateStatusText.Text="Checksum and download size verified. Ready to open setup.";
            if(MessageBox.Show(this,"Open setup now and close this app? Approve Windows administrator authorization, then follow the installer wizard. Reopen the desktop shortcut normally when setup finishes.","Install update",MessageBoxButton.YesNo)!=MessageBoxResult.Yes)return;
            using var installer=_updates.Launch(path,_available);_busy=false;Application.Current.Shutdown();
        }
        catch(Exception ex){UpdateStatusText.Text="Update not installed. Existing settings and session files are unchanged.\n"+ex.Message;}
        finally{_busy=false;CheckUpdatesButton.IsEnabled=true;InstallUpdateButton.IsEnabled=_available is not null;}
    }
    protected override void OnClosed(EventArgs e){_updates.Dispose();base.OnClosed(e);}
    protected override void OnClosing(CancelEventArgs e){if(_busy)e.Cancel=true;base.OnClosing(e);}
}
