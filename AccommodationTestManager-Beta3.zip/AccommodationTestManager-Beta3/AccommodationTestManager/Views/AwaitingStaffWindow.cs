using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
namespace AccommodationTestManager.Views;
public sealed class AwaitingStaffWindow:Window
{
 public string? AuthorizedStaff {get;private set;}
 public bool AllowShutdown {get;set;}
 public AwaitingStaffWindow()
 {
  Title="Test finished — awaiting staff";WindowStyle=WindowStyle.None;ResizeMode=ResizeMode.NoResize;ShowInTaskbar=false;Topmost=true;
  var area=SystemParameters.WorkArea;Left=area.Left;Top=area.Top;Width=area.Width;Height=area.Height;
  SetResourceReference(BackgroundProperty,"AppCanvasBrush");SetResourceReference(ForegroundProperty,"AppTextBrush");
  var panel=new StackPanel{MaxWidth=560,Margin=new Thickness(24),VerticalAlignment=VerticalAlignment.Center,HorizontalAlignment=HorizontalAlignment.Center};Content=panel;
  panel.Children.Add(new TextBlock{Text="Test finished",FontSize=30,FontWeight=FontWeights.Bold,Margin=new Thickness(0,0,0,20)});
  panel.Children.Add(new TextBlock{Text="Please wait for staff. Staff must enter the PIN to open the current session, verify submission/export, or resume.",FontSize=18,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,20)});
  var authorize=new Button{Name="AuthorizeHandoffButton",Content="Staff authorization",MinHeight=48};panel.Children.Add(authorize);
  panel.Children.Add(new TextBlock{Text="This is an app handoff screen, not a Windows security lock. Online work must be submitted and verified separately; the browser has not been forcibly closed.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,20,0,0)});
  authorize.Click+=(_,_)=>{string? staff=StaffDialogs.Authorize(this,App.Host.Settings,"Authorize finished-test handoff",App.Host.Sessions.Current?.StartedBy);if(staff is null)return;AuthorizedStaff=staff;DialogResult=true;};
 }
 protected override void OnClosing(CancelEventArgs e){if(AuthorizedStaff is null&&!AllowShutdown)e.Cancel=true;base.OnClosing(e);}
}
