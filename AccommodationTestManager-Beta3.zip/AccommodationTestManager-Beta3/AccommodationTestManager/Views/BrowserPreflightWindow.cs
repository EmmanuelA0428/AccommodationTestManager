using AccommodationTestManager.Services;
using Microsoft.Win32;
using System.IO;
using System.Windows;
using System.Windows.Controls;
namespace AccommodationTestManager.Views;
public sealed class BrowserPreflightWindow:Window
{
 public BrowserPolicyReceipt? Receipt {get;private set;}
 public BrowserPreflightWindow()
 {
  Title="Verify exam browser before student handoff";Width=740;Height=620;MinWidth=420;MinHeight=360;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  SetResourceReference(BackgroundProperty,"AppSurfaceBrush");SetResourceReference(ForegroundProperty,"AppTextBrush");
  var panel=new StackPanel{Margin=new Thickness(24)};Content=new ScrollViewer{Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
  panel.Children.Add(new TextBlock{Text="Browser enforcement verification",FontSize=24,FontWeight=FontWeights.Bold,TextWrapping=TextWrapping.Wrap});
  panel.Children.Add(new TextBlock{Text="In the exam Edge window, press F11 if needed to leave full-screen, open edge://policy, Reload policies, then Export to JSON. Import that file here. This is a staff verification—not remote debugging or Windows lockdown.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,16,0,12)});
  var import=new Button{Name="ImportBrowserPolicyButton",Content="Import fresh Edge policy JSON",MinHeight=44};panel.Children.Add(import);
  var status=new TextBlock{Text="No browser evidence imported; student handoff blocked.",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,12,0,12)};panel.Children.Add(status);
  var blocked=new CheckBox{Content=new TextBlock{Text="In the exam Edge window, https://example.org shows a blocked-page message (not a network error).",TextWrapping=TextWrapping.Wrap},MinHeight=44};panel.Children.Add(blocked);
  var login=new CheckBox{Content=new TextBlock{Text="The required login/exam/project is accessible; returned to the exam tab and full-screen (F11).",TextWrapping=TextWrapping.Wrap},MinHeight=44};panel.Children.Add(login);
  var ai=new CheckBox{Content=new TextBlock{Text="Edge sidebar/toolbar chat and supported writing assistance are unavailable. In-site AI is outside scope.",TextWrapping=TextWrapping.Wrap},MinHeight=44};panel.Children.Add(ai);
  var usb=new CheckBox{Content=new TextBlock{Text="Reinserted USB storage is inaccessible; no other app/OS lockdown is claimed.",TextWrapping=TextWrapping.Wrap},MinHeight=44};panel.Children.Add(usb);
  var finish=new Button{Name="ApproveBrowserHandoffButton",Content="Checks passed — ready for student",IsEnabled=false,MinHeight=48,Margin=new Thickness(0,16,0,0)};panel.Children.Add(finish);
  void Update()=>finish.IsEnabled=Receipt is not null&&blocked.IsChecked==true&&login.IsChecked==true&&usb.IsChecked==true&&(!App.Host.Sessions.Current!.SettingsSnapshot.DisableBrowserAI||ai.IsChecked==true);
  foreach(var check in new[]{blocked,login,ai,usb}){check.Checked+=(_,_)=>Update();check.Unchecked+=(_,_)=>Update();}
  import.Click+=(_,_)=>{
   var picker=new OpenFileDialog{Title="Select fresh policy export from exam Edge",Filter="JSON policy export|*.json"};if(picker.ShowDialog(this)!=true)return;
   try{if(new FileInfo(picker.FileName).Length>2*1024*1024)throw new IOException("Export exceeds 2 MB.");Receipt=BrowserPolicyEvidence.Validate(File.ReadAllBytes(picker.FileName),App.Host.Sessions.Current!,File.GetLastWriteTimeUtc(picker.FileName));status.Text="Required policies accepted with exact session values. Now perform all live checks below.";}catch(Exception ex){Receipt=null;status.Text=ex.Message;}Update();
  };
  finish.Click+=(_,_)=>DialogResult=true;
 }
}
