using System.Windows;
using System.Windows.Controls;
namespace AccommodationTestManager.Views;
public sealed class DiagnosticsWindow:Window
{
 public DiagnosticsWindow(string? id=null)
 {
  Title="Machine diagnostics (read-only)";Width=780;Height=560;MinWidth=420;MinHeight=320;WindowStartupLocation=WindowStartupLocation.CenterOwner;
  SetResourceReference(BackgroundProperty,"AppSurfaceBrush");SetResourceReference(ForegroundProperty,"AppTextBrush");
  var panel=new DockPanel{Margin=new Thickness(20)};Content=panel;
  var refresh=new Button{Content="Refresh diagnostics",MinHeight=44,Margin=new Thickness(0,0,0,12)};DockPanel.SetDock(refresh,Dock.Top);panel.Children.Add(refresh);
  var text=new TextBox{IsReadOnly=true,AcceptsReturn=true,TextWrapping=TextWrapping.Wrap,VerticalScrollBarVisibility=ScrollBarVisibility.Auto,FontFamily=new System.Windows.Media.FontFamily("Consolas")};panel.Children.Add(text);
  void Load()=>text.Text=App.Host.Restrictions.Diagnostics(id);
  refresh.Click+=(_,_)=>Load();Load();
 }
}
