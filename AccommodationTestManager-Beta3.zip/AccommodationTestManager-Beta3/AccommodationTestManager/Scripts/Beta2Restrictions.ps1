# Protected, installed helper. NEVER run this from a student-writable folder.
# Scope: network adapters, removable-storage policy, mandatory Edge policies.
# NOT AppLocker, a secure kiosk, protected exam storage, or all-AI enforcement.
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('Apply','ExportAccess','Restore','Assess','ApproveReview','RestoreLegacyRecorded')][string]$Action,
 [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{32}$')][string]$SessionId,
 [string]$RequestPath
)
$ErrorActionPreference='Stop'
$StateRoot='C:\ProgramData\AccommodationTestingBeta2\RestrictionState'
$Edge='HKLM:\SOFTWARE\Policies\Microsoft\Edge'
$Usb='HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices'
$ControlledEdge=@('BrowserSignin','SyncDisabled','StartupBoostEnabled','BackgroundModeEnabled')
function Assert-Admin {
 $id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($id)
 if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator authorization required.'}
}
function Write-Atomic([string]$Path,$Value) {
 $temp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp';$bytes=[Text.Encoding]::UTF8.GetBytes(($Value|ConvertTo-Json -Depth 30))
 $s=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}
 if(Test-Path -LiteralPath $Path){[IO.File]::Replace($temp,$Path,$Path+'.bak')}else{[IO.File]::Move($temp,$Path)}
}
function Snapshot-Value([string]$Path,[string]$Name) {
 $key=Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
 if($null-ne $key -and $key.GetValueNames()-contains $Name){return [ordered]@{Path=$Path;Name=$Name;Present=$true;Kind=$key.GetValueKind($Name).ToString();Value=$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)}}
 return [ordered]@{Path=$Path;Name=$Name;Present=$false;Kind='DWord';Value=$null}
}
function Snapshot-List([string]$Name) {
 $path="$Edge\$Name";$exists=Test-Path -LiteralPath $path;$values=@()
 if($exists){$key=Get-Item -LiteralPath $path;if(@(Get-ChildItem -LiteralPath $path).Count-gt 0){throw "Unexpected nested policy: $Name"};foreach($n in $key.GetValueNames()){$values+=Snapshot-Value $path $n}}
 return @{Path=$path;Present=$exists;Values=$values}
}
function Set-Value([string]$Path,[string]$Name,$Value,[string]$Kind='DWord') {
 # CreateSubKey is NON-DESTRUCTIVE for an existing registry key, unlike New-Item -Force.
 # HKCU is supported only to test this function in an isolated temporary registry branch.
 if($Path.StartsWith('HKLM:\')){$hive=[Microsoft.Win32.RegistryHive]::LocalMachine;$relative=$Path.Substring(6)}
 elseif($Path.StartsWith('HKCU:\')){$hive=[Microsoft.Win32.RegistryHive]::CurrentUser;$relative=$Path.Substring(6)}
 else{throw 'Unsupported registry hive.'}
 $base=[Microsoft.Win32.RegistryKey]::OpenBaseKey($hive,[Microsoft.Win32.RegistryView]::Registry64)
 try {
  $key=$base.CreateSubKey($relative,$true)
  try {
   $type=[Microsoft.Win32.RegistryValueKind][Enum]::Parse([Microsoft.Win32.RegistryValueKind],$Kind)
   if($type-eq [Microsoft.Win32.RegistryValueKind]::Binary){$Value=[byte[]]$Value}
   if($type-eq [Microsoft.Win32.RegistryValueKind]::MultiString){$Value=[string[]]$Value}
   $key.SetValue($Name,$Value,$type);$key.Flush()
   $actual=$key.GetValue($Name,$null,[Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
   if($key.GetValueKind($Name)-ne $type -or ($actual|ConvertTo-Json -Compress)-ne ($Value|ConvertTo-Json -Compress)){throw ('Registry readback failed: '+$Name)}
  } finally {$key.Dispose()}
 } finally {$base.Dispose()}
}
function Clear-ListValues([string]$Path) {
 if(Test-Path -LiteralPath $Path){
  if(@(Get-ChildItem -LiteralPath $Path).Count-gt 0){throw 'Nested list policy requires external review.'}
  $key=Get-Item -LiteralPath $Path
  foreach($name in $key.GetValueNames()){
   if($name-notmatch '^[1-9][0-9]{0,3}$'){throw ('Unexpected non-numbered policy value: '+$name)}
  }
  foreach($name in $key.GetValueNames()){Remove-ItemProperty -LiteralPath $Path -Name $name -ErrorAction Stop}
 }
}
function Verify-RecordedRegistry($state,[bool]$Original=$false) {
 foreach($v in @($state.Registry)){
  $wanted=$(if($Original){$v}else{$v.Expected})
  if($null-eq $wanted){throw 'Missing expected scalar policy.'}
  $now=Snapshot-Value $v.Path $v.Name
  if($now.Present-ne $wanted.Present -or $now.Present -and ($now.Kind-ne $wanted.Kind -or ($now.Value|ConvertTo-Json -Compress)-ne ($wanted.Value|ConvertTo-Json -Compress))){throw ('Final scalar policy verification failed: '+$v.Name)}
 }
 foreach($l in @($state.Lists)){
  $wanted=$(if($Original){$l}else{$l.Expected})
  if($null-eq $wanted){throw 'Missing expected list policy.'}
  $now=Snapshot-List ([IO.Path]::GetFileName($l.Path))
  $before=($wanted.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress)
  $after=($now.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress)
  if($before-ne $after){throw 'Final URL/extension policy verification failed.'}
 }
}
function Preservation-Inventory($state) {
 # Fingerprint every unrelated property/subkey in the branches touched by this helper.
 $out=@();$controlled=@($state.Registry);$lists=@($state.Lists|ForEach-Object{$_.Path})
 foreach($root in @($controlled|ForEach-Object{$_.Path}|Select-Object -Unique)){
  if(-not(Test-Path -LiteralPath $root)){continue}
  foreach($key in @((Get-Item -LiteralPath $root))+@(Get-ChildItem -LiteralPath $root -Recurse)){
   $path=$key.Name.Replace('HKEY_LOCAL_MACHINE','HKLM:').Replace('HKEY_CURRENT_USER','HKCU:')
   if(@($lists|Where-Object{$path-eq $_ -or $path.StartsWith($_+'\')}).Count){continue}
   if($path-ne $root){$out+=[ordered]@{Path=$path;Name='';KeyPresent=$true}}
   foreach($name in $key.GetValueNames()){
    if(@($controlled|Where-Object{$_.Path-eq $path -and $_.Name-eq $name}).Count){continue}
    $out+=Snapshot-Value $path $name
   }
  }
 }
 return @($out|Sort-Object Path,Name)
}
function Assert-Preservation($state) {
 if($null-eq $state.Preservation){throw 'No Beta 3 preservation inventory; external legacy review required.'}
 $now=Preservation-Inventory $state
 if(($now|ConvertTo-Json -Depth 30 -Compress)-ne ($state.Preservation|ConvertTo-Json -Depth 30 -Compress)){throw 'Unrelated registry properties changed. Preserved evidence; do not overwrite external changes.'}
}
function Restore-Value($v) {
 if($null-ne $v.Expected){$now=Snapshot-Value $v.Path $v.Name;$matchesApplied=($now.Present-eq $v.Expected.Present -and $now.Kind-eq $v.Expected.Kind -and ($now.Value|ConvertTo-Json -Compress)-eq ($v.Expected.Value|ConvertTo-Json -Compress));$matchesOriginal=($now.Present-eq $v.Present -and $now.Kind-eq $v.Kind -and ($now.Value|ConvertTo-Json -Compress)-eq ($v.Value|ConvertTo-Json -Compress));if(-not $matchesApplied -and -not $matchesOriginal){throw "Policy changed outside this app; staff/IT review required: $($v.Name)"}}
 if($v.Present){Set-Value $v.Path $v.Name $v.Value $v.Kind}
 elseif(Test-Path -LiteralPath $v.Path){Remove-ItemProperty -LiteralPath $v.Path -Name $v.Name -ErrorAction SilentlyContinue;if((Get-Item $v.Path).GetValueNames()-contains $v.Name){throw "Failed restoring absent value: $($v.Name)"}}
}
function Set-List([string]$Name,[string[]]$Values) {
 $path="$Edge\$Name";Clear-ListValues $path
 $i=1;foreach($value in $Values){Set-Value $path "$i" $value 'String';$i++}
}
function Restore-List($l) {
 if($null-ne $l.Expected){
  $current=Snapshot-List ([IO.Path]::GetFileName($l.Path))
  $a=($current.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress)
  $b=($l.Expected.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress)
  $c=($l.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress)
  $partialSafe=$true
  foreach($v in @($current.Values)){
   $wanted=@($l.Expected.Values|Where-Object{$_.Name-eq $v.Name})
   if($wanted.Count-ne 1 -or $wanted[0].Kind-ne $v.Kind -or ($wanted[0].Value|ConvertTo-Json -Compress)-ne ($v.Value|ConvertTo-Json -Compress)){$partialSafe=$false}
  }
  if($a-ne $b -and $a-ne $c -and -not $partialSafe){throw 'URL/extension policy changed outside this app; staff review required.'}
 }
 Clear-ListValues $l.Path
 foreach($v in @($l.Values)){Restore-Value $v}
 # Empty created keys are deliberately retained; unrelated keys/subkeys are never deleted.
}
# Windows creates/removes these infrastructure interfaces automatically. They are
# not independent Wi-Fi/Ethernet connections and must not be toggled directly.
function Is-WindowsInfrastructureAdapter($adapter) {
 $description=[string]$adapter.InterfaceDescription
 $name=[string]$adapter.Name
 if($description -match '^(Microsoft Wi-Fi Direct Virtual Adapter(?: #\d+)?|WAN Miniport \([^)]+\)|Microsoft Kernel Debug Network Adapter)$'){return $true}
 if($description -match 'Loopback'){return $true}
 if([string]::IsNullOrWhiteSpace($description) -and $name -in @('Teredo Tunneling Pseudo-Interface','6to4 Adapter','Microsoft IP-HTTPS Platform Interface')){return $true}
 return $false
}
function Find-Adapter([string]$Guid) {
 $target=$Guid.Trim([char[]]'{}')
 @(Get-NetAdapter -IncludeHidden | Where-Object {([string]$_.InterfaceGuid).Trim([char[]]'{}') -eq $target}) | Select-Object -First 1
}
function Active-Adapters {
 @(Get-NetAdapter -IncludeHidden | Where-Object {
  $_.Status -notin @('Disabled','Not Present','NotPresent') -and
  -not (Is-WindowsInfrastructureAdapter $_)
 })
}
function Record-NetworkNote($state,[string]$message) {
 $notes=@($state.NetworkRestoreNotes | Where-Object {$null -ne $_})+@($message)
 if($state -is [System.Collections.IDictionary]){$state['NetworkRestoreNotes']=$notes}
 else{$state | Add-Member -NotePropertyName NetworkRestoreNotes -NotePropertyValue $notes -Force}
}
function Restore-Network($state) {
 # Classify against the INITIAL inventory before re-enabling Wi-Fi. Child adapters
 # can vanish/reappear during that operation. Legacy snapshots have only Name/Guid.
 $inventory=@(Get-NetAdapter -IncludeHidden)
 $work=@(foreach($a in @($state.Adapters)){
  $initial=$inventory | Where-Object {([string]$_.InterfaceGuid).Trim([char[]]'{}') -eq ([string]$a.Guid).Trim([char[]]'{}')} | Select-Object -First 1
  $classification=$initial
  if($null -eq $classification -and -not [string]::IsNullOrWhiteSpace([string]$a.InterfaceDescription)){$classification=$a}
  $infrastructure=$null -ne $classification -and (Is-WindowsInfrastructureAdapter $classification)
  $physical=($null -ne $initial -and $initial.HardwareInterface -eq $true) -or $a.HardwareInterface -eq $true
  [pscustomobject]@{Record=$a;Infrastructure=$infrastructure;Priority=$(if($physical){0}elseif($infrastructure){2}else{1})}
 })
 $problems=@()
 foreach($item in @($work | Sort-Object Priority)) {
  $a=$item.Record
  try {
   # New snapshots record initial enabled state and intent before each change.
   # Never enable an adapter that was initially disabled or not yet changed by us.
   if($a.OriginalStatus -eq 'Disabled'){continue}
   if($null -ne $a.ChangedByHelper -and -not $a.ChangedByHelper){continue}
   $adapter=Find-Adapter $a.Guid
   if($null -eq $adapter -and -not $item.Infrastructure){
    for($attempt=0;$attempt -lt 5 -and $null -eq $adapter;$attempt++){Start-Sleep -Milliseconds 400;$adapter=Find-Adapter $a.Guid}
   }
   if($null -eq $adapter -or $adapter.Status -in @('Not Present','NotPresent')) {
    if($item.Infrastructure){Record-NetworkNote $state ('Windows-managed infrastructure interface unavailable after parent restore: '+$a.Name);continue}
    throw ('Original connection adapter missing/not present: '+$a.Name+' ['+$a.Guid+']. Reconnect the same device/dock and retry; do not delete the snapshot.')
   }
   # Old helper may have disabled a WAN/Wi-Fi Direct interface. If it still exists
   # AND is disabled, attempt its restoration too; failure remains unresolved.
   if($adapter.Status -eq 'Disabled'){Enable-NetAdapter -InputObject $adapter -Confirm:$false -ErrorAction Stop}
   $check=Find-Adapter $a.Guid
   for($attempt=0;$attempt -lt 5 -and ($null -eq $check -or $check.Status -eq 'Disabled');$attempt++){Start-Sleep -Milliseconds 400;$check=Find-Adapter $a.Guid}
   if($null -eq $check -and $item.Infrastructure){Record-NetworkNote $state ('Windows-managed infrastructure interface refreshed during restore: '+$a.Name);continue}
   if($null -eq $check -or $check.Status -in @('Disabled','Not Present','NotPresent')){throw ('Adapter restoration not confirmed: '+$a.Name)}
  } catch {$problems+=$_.Exception.Message}
 }
 # Attempt ALL recorded connections even if one failed; keep failure visible.
 if($problems.Count -gt 0){throw ($problems -join '; ')}
}
function Disable-RecordedAdapters($state,[string]$statePath) {
  foreach($a in @($state.Adapters)){
   $adapter=Find-Adapter $a.Guid
   if($null -eq $adapter -or $adapter.Status -in @('Not Present','NotPresent')){throw ('Connection adapter disappeared before disable: '+$a.Name+'. No null InputObject was passed.')}
   if($adapter.Status -eq 'Disabled'){throw ('Adapter changed outside this helper before disable: '+$a.Name)}
   # Persist intent BEFORE disabling so interrupted Apply can restore this adapter.
   $a.ChangedByHelper=$true;Write-Atomic $statePath $state
   Disable-NetAdapter -InputObject $adapter -Confirm:$false -ErrorAction Stop
  }
}
function Restore-All($state) {
 $problems=@()
 foreach($v in @($state.Registry)){try{Restore-Value $v}catch{$problems+=$_.Exception.Message}}
 foreach($l in @($state.Lists)){try{Restore-List $l}catch{$problems+=$_.Exception.Message}}
 if($state.SchemaVersion-ge 3){try{Verify-RecordedRegistry $state $true;Assert-Preservation $state}catch{$problems+=$_.Exception.Message}}
 try{Restore-Network $state}catch{$problems+=$_.Exception.Message}
 if($problems.Count-gt 0){throw ($problems-join '; ')}
}
function Legacy-Snapshots {
 @(Get-ChildItem $StateRoot -Filter '*.json'|Where-Object{$_.Name-notlike '*.report.json'}|ForEach-Object{Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json}|Where-Object{$_.SchemaVersion-lt 3})
}
function Legacy-Fingerprint {
 $names=@(Get-ChildItem $StateRoot -Filter '*.json'|Where-Object{$_.Name-notlike '*.report.json'}|Where-Object{(Get-Content $_.FullName -Raw|ConvertFrom-Json).SchemaVersion-lt 3}|Sort-Object Name)
 return (($names|ForEach-Object{$_.Name+':'+(Get-FileHash $_.FullName -Algorithm SHA256).Hash}) -join ';')
}
function Service-IntegrityIssues {
 $issues=@()
 foreach($name in @('USBSTOR','UASPStor')){
  $path='HKLM:\SYSTEM\CurrentControlSet\Services\'+$name
  if(-not(Test-Path $path)){if($name-eq 'USBSTOR'){$issues+='USBSTOR service key is missing'};continue}
  $key=Get-Item $path
  foreach($property in @('Start','Type','ImagePath','ErrorControl')){if($key.GetValueNames()-notcontains $property){$issues+=($name+': missing '+$property)}}
  foreach($property in @('Start','Type','ErrorControl')){
   if($key.GetValueNames()-contains $property -and $key.GetValueKind($property)-ne [Microsoft.Win32.RegistryValueKind]::DWord){$issues+=($name+': unexpected type for '+$property)}
  }
  if($key.GetValueNames()-contains 'Start' -and $key.GetValue('Start')-notin @(0,1,2,3,4)){$issues+=($name+': invalid Start value')}
  if($key.GetValueNames()-contains 'Type' -and $key.GetValue('Type')-ne 1){$issues+=($name+': unexpected kernel-driver Type')}
  if($key.GetValueNames()-contains 'ImagePath'){
   $image=[Environment]::ExpandEnvironmentVariables([string]$key.GetValue('ImagePath'))
   if($image.StartsWith('\SystemRoot\',[StringComparison]::OrdinalIgnoreCase)){$image=Join-Path $env:WINDIR $image.Substring(12)}
   elseif(-not [IO.Path]::IsPathRooted($image)){$image=Join-Path $env:WINDIR $image}
   if([string]::IsNullOrWhiteSpace($image) -or -not(Test-Path -LiteralPath $image)){$issues+=($name+': driver ImagePath target unavailable')}
  }
 }
 return $issues
}
function Assert-LegacyReviewed {
 if(@(Legacy-Snapshots).Count-eq 0){return}
 $receipt=Join-Path $StateRoot 'legacy-review.report.json'
 if(-not(Test-Path $receipt)){throw 'Legacy registry assessment required. Open Settings > Recovery > Assess legacy machine state. No new restrictions were applied.'}
 $review=Get-Content $receipt -Raw|ConvertFrom-Json
 if(-not $review.IndependentReviewConfirmed -or $review.Fingerprint-ne (Legacy-Fingerprint)){throw 'Legacy evidence changed or external review not confirmed. Machine tests blocked.'}
 if(@(Service-IntegrityIssues).Count-gt 0){throw 'USB service configuration remains incomplete; independent repair/review required.'}
}
$stage='Authorize and validate installation'
try {
Assert-Admin
$installed=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2\Scripts\Beta2Restrictions.ps1'
if([IO.Path]::GetFullPath($PSCommandPath)-ne [IO.Path]::GetFullPath($installed)){throw 'Install Beta 2 first. Helper must be in protected Program Files.'}
if(-not(Test-Path $StateRoot)){throw 'Protected state folder missing. Run Install-Beta2.ps1 as administrator.'}
if((Get-Item $StateRoot).Attributes-band [IO.FileAttributes]::ReparsePoint){throw 'Reparse-point state folder rejected.'}
$statePath=Join-Path $StateRoot ($SessionId+'.json')
$stage='Legacy assessment/review'
if($Action-in @('Assess','ApproveReview','RestoreLegacyRecorded')){
 $issues=@(Service-IntegrityIssues);$legacy=@(Legacy-Snapshots)
 if($Action-eq 'RestoreLegacyRecorded' -and @(Get-Process msedge -ErrorAction SilentlyContinue).Count-gt 0){throw 'Save and close Edge normally before recorded-value restoration.'}
 if($Action-eq 'Assess'){
  Write-Atomic (Join-Path $StateRoot 'legacy-assessment.report.json') @{Action='Assess';Stage='Read-only assessment';Success=$true;LegacySnapshotCount=$legacy.Count;ServiceIssues=$issues;Detail='No repair performed. Missing unrecorded values cannot be reconstructed from Beta 2 snapshots. Independent review of Edge/USB and other touched keys required.';UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
 } elseif($Action-eq 'RestoreLegacyRecorded'){
  foreach($old in $legacy){
   if($old.Status-eq 'Restored'){continue}
   # This restores ONLY known selected values with the safe writer; never claims full recovery.
   foreach($v in @($old.Registry)){Restore-Value $v}
   foreach($l in @($old.Lists)){Restore-List $l}
   Restore-Network $old
   $old.Status='LegacyPartialRestored';$old.Detail='Only recorded values restored with non-destructive writer. Unrecorded values require independent review.'
   Write-Atomic (Join-Path $StateRoot ($old.SessionId+'.json')) $old
  }
 } else {
  if(@($legacy|Where-Object{$_.Status-notin @('Restored','LegacyPartialRestored')}).Count){throw 'Restore recorded legacy values first; independent review must follow.'}
  if($issues.Count){throw ($issues -join '; ')}
  foreach($old in $legacy){$old.Status='Restored';$old.Detail='Recorded state restored; Windows administrator explicitly confirmed independent review/repair of missing unrecorded registry values. Not reconstructed by this app.';Write-Atomic (Join-Path $StateRoot ($old.SessionId+'.json')) $old}
  Write-Atomic (Join-Path $StateRoot 'legacy-review.report.json') @{Action='ApproveReview';IndependentReviewConfirmed=$true;Fingerprint=(Legacy-Fingerprint);Administrator=[Security.Principal.WindowsIdentity]::GetCurrent().Name;UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
 }
 return
}
$stage='Validate startup prerequisites'
if($Action-eq 'Apply') {
 Assert-LegacyReviewed
 if(@(Service-IntegrityIssues).Count-gt 0){throw ('USB service configuration incomplete: '+((Service-IntegrityIssues)-join '; ')+'. Independent review/repair required; no new restrictions applied.')}

 # Refuse overlapping machine restriction snapshots, including interrupted restores.
 $pending=@(Get-ChildItem $StateRoot -Filter '*.json'|Where-Object{$_.Name-notlike '*.report.json'}|ForEach-Object{Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json}|Where-Object{$_.Status-ne 'Restored'})
 if($pending.Count-gt 0){throw 'Another restriction snapshot is unresolved. Use Emergency Restore first.'}
 if(-not(Test-Path -LiteralPath $RequestPath)){throw 'Restriction request missing.'}
 $request=Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8|ConvertFrom-Json
 if($request.Mode-notin @('Word','Online','Desktop')){throw 'Invalid restriction mode.'}
 if($request.ApplicationLockdown){throw 'Application lockdown is not implemented by this helper. No protected startup is allowed with that requirement.'}
 if(@(Get-Disk|Where-Object{$_.BusType-eq 'USB' -and -not $_.IsOffline}).Count-gt 0){throw 'Remove ALL USB storage before restrictions are applied. Keyboard/headset devices are not storage.'}
 if($request.Mode-eq 'Online' -and @(Get-Process msedge -ErrorAction SilentlyContinue).Count-gt 0){throw 'Close Edge normally before applying policies. No process will be killed.'}
 $stage='Capture original machine state'
 $values=@(Snapshot-Value $Usb 'Deny_All')
 $values+=Snapshot-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR' 'Start'
 if(Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor'){$values+=Snapshot-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor' 'Start'}
 $lists=@()
 if($request.Mode-eq 'Online') {
  if(@($request.Allowlist).Count-lt 1 -or @($request.Allowlist).Count-gt 999){throw 'Online mode needs 1-999 approved URL filters.'}
  if($request.DisableBrowserAI -and (@($request.AiPolicies).Count-lt 1 -or @($request.AiPolicies|Where-Object{$_-notin @('HubsSidebarEnabled','Microsoft365CopilotChatIconEnabled','ComposeInlineEnabled','AllowBrowsingWithCopilot','CopilotNewTabPageEnabled')}).Count-gt 0)){throw 'Invalid/unsupported AI policy plan.'}
  foreach($url in @($request.Allowlist)){if($url-notmatch '^https://' -or $url -eq '*'){throw 'Only explicit HTTPS filters are supported.'}}
  foreach($name in $ControlledEdge){$values+=Snapshot-Value $Edge $name};if($request.DisableBrowserAI){foreach($name in @($request.AiPolicies)){$values+=Snapshot-Value $Edge $name}}
  foreach($name in @('URLBlocklist','URLAllowlist','ExtensionInstallBlocklist')){$lists+=Snapshot-List $name}
 }
 $adapters=@();if($request.IsolateNetwork){$adapters=@(Active-Adapters | Sort-Object HardwareInterface | ForEach-Object {@{Guid=[string]$_.InterfaceGuid;Name=$_.Name;InterfaceDescription=[string]$_.InterfaceDescription;HardwareInterface=($_.HardwareInterface -eq $true);OriginalStatus=[string]$_.Status;ChangedByHelper=$false}})}
 $state=@{SchemaVersion=3;HelperRevision='beta3-safe-registry-1';Preservation=@();NetworkRestoreNotes=@();SessionId=$SessionId;Status='Applying';Mode=$request.Mode;Registry=$values;Lists=$lists;Adapters=$adapters;Detail='';UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
  foreach($v in $state.Registry){
   $target=$(if($v.Path-eq $Usb){1}elseif($v.Path-eq $Edge -and $v.Name-eq 'SyncDisabled'){1}elseif($v.Path-eq $Edge){0}else{4})
   $v.Expected=@{Path=$v.Path;Name=$v.Name;Present=$true;Kind='DWord';Value=$target}
  }
  foreach($l in $state.Lists){
   $name=[IO.Path]::GetFileName($l.Path)
   $entries=$(if($name-eq 'URLBlocklist'){@('*')+@($request.BlockedAIUrls)}elseif($name-eq 'URLAllowlist'){@($request.Allowlist)+@('edge://policy')}else{@('*')})
   $i=1;$wanted=@();foreach($value in $entries){$wanted+=@{Path=$l.Path;Name=[string]$i;Present=$true;Kind='String';Value=$value};$i++}
   $l.Expected=@{Path=$l.Path;Present=$true;Values=$wanted}
  }
 $state.Preservation=@(Preservation-Inventory $state)
 Write-Atomic $statePath $state
 try {
  $stage='Apply USB storage restrictions'
  Set-Value $Usb 'Deny_All' 1
  Set-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR' 'Start' 4
  if(Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor'){Set-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor' 'Start' 4}
  Disable-RecordedAdapters $state $statePath
  if($request.IsolateNetwork -and @(Active-Adapters).Count-gt 0){throw 'An enabled manageable connection adapter remains; staff live network verification is still required.'}
  if($request.Mode-eq 'Online') {
   $stage='Apply Edge policies'
   Set-List 'URLBlocklist' (@('*')+@($request.BlockedAIUrls));Set-List 'URLAllowlist' (@($request.Allowlist)+@('edge://policy'));Set-List 'ExtensionInstallBlocklist' @('*')
   Set-Value $Edge 'BrowserSignin' 0;Set-Value $Edge 'SyncDisabled' 1;Set-Value $Edge 'StartupBoostEnabled' 0;Set-Value $Edge 'BackgroundModeEnabled' 0
   if($request.DisableBrowserAI){foreach($name in @($request.AiPolicies)){Set-Value $Edge $name 0}}
  }
  Verify-RecordedRegistry $state;Assert-Preservation $state
  $state.Status='Applied';$state.Detail='Registry readback and requested adapter-disable state checked. USB replug and Edge effective-policy checks require staff live validation. NOT application lockdown or all-AI/site-feature enforcement.';Write-Atomic $statePath $state
 } catch {
  $failure=$_.Exception.Message
  try{Restore-All $state;$state.Status='Restored';$state.Detail='Apply failed; previous state restored: '+$failure}
  catch{$state.Status='RestoreFailed';$state.Detail='Apply failed: '+$failure+'; restore failed: '+$_.Exception.Message}
  Write-Atomic $statePath $state;throw $state.Detail
 }
} else {
 if(-not(Test-Path -LiteralPath $statePath)){throw 'No protected snapshot exists for this session.'}
 $state=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8|ConvertFrom-Json
 if($state.SessionId-ne $SessionId){throw 'Snapshot ID mismatch.'}
 if($state.SchemaVersion-lt 3){throw 'Legacy Beta 2 snapshot is incomplete. Use the legacy assessment/review path; no blind restoration was attempted.'}
 if($Action-eq 'Restore' -and $state.Mode-eq 'Online' -and @(Get-Process msedge -ErrorAction SilentlyContinue).Count-gt 0){throw 'Close Edge normally before restoring its policies. Snapshot remains unresolved; no process was killed.'}
 if($Action-eq 'ExportAccess') {
  if($state.Status-notin @('Applied','ExportAccess')){throw 'This snapshot cannot enable export access.'}
  foreach($v in @($state.Registry)|Where-Object{$_.Path-ne $Edge}){Restore-Value $v}
  $state.Status='ExportAccess';$state.Detail='Original USB storage settings restored for authorized export; network/browser settings not yet restored.';Write-Atomic $statePath $state
 } else {
  try{Restore-All $state;$state.Status='Restored';$state.Detail='Recorded registry and connection-adapter enable states restored.';if(@($state.NetworkRestoreNotes).Count -gt 0){$state.Detail+=' Infrastructure notes: '+($state.NetworkRestoreNotes -join '; ')};Write-Atomic $statePath $state}
  catch{$state.Status='RestoreFailed';$state.Detail=$_.Exception.Message;Write-Atomic $statePath $state;throw}
 }
}

} catch {
 $failure=$_.Exception.Message
 # Fixed protected output only; never accept a caller-supplied report path.
 try {
  $expected=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2\Scripts\Beta2Restrictions.ps1'
  if([IO.Path]::GetFullPath($PSCommandPath)-eq [IO.Path]::GetFullPath($expected) -and (Test-Path $StateRoot) -and -not ((Get-Item $StateRoot).Attributes-band [IO.FileAttributes]::ReparsePoint)) {
   $report=@{SchemaVersion=1;SessionId=$SessionId;Action=$Action;Stage=$stage;Success=$false;Message=$failure;UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
   Write-Atomic (Join-Path $StateRoot ($SessionId+'.'+$Action+'.report.json')) $report
  }
 } catch { # Reporting failure must not conceal the original machine error.
 }
 Write-Error -Message $failure -ErrorAction Continue
 exit 1
}
# Successful actions are also reported; snapshots remain the authority for restoration.
try {
 Write-Atomic (Join-Path $StateRoot ($SessionId+'.'+$Action+'.report.json')) @{SchemaVersion=1;SessionId=$SessionId;Action=$Action;Stage='Complete';Success=$true;Message='Action completed; check snapshot and live controls.';UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
} catch { Write-Warning 'Action succeeded but diagnostic report could not be written.' }
