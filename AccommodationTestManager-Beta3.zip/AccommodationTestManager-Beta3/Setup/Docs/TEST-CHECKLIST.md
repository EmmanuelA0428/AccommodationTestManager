# Beta 3 dummy-data acceptance checklist

## Before device tests
- Preserve all older protected snapshots and reports. Do not execute the defective old helper again.
- On an affected device, have a qualified administrator assess and independently repair/review registry branches from a known-good baseline. Selected old snapshots are incomplete evidence, not a baseline.
- Validate Windows CI registry/provider, setup, UI and PIN checks before distributing setup.
- Use standard testing account; authorize helper operations separately. Do not run app elevated.

## Installation / recovery
- One setup installs runtime/app/helper; old settings/sessions remain.
- Known legacy snapshots are archived; new control tests stay gated until explicit independent review.
- Read-only assessment is available. Selected recorded restoration must not claim complete repair.
- Unresolved new schema 3 controls block ordinary upgrade/uninstall.
- Cancel UAC; fail setup copy; verify no session/evidence deletion and no machine controls applied by setup.

## Online test
- Edge background processes produce actionable diagnostics; close normally, never kill unrelated unsaved work.
- Canvas and Posit each get only their own reviewed list plus required sign-in dependencies.
- Export actual current Edge policies; import fresh JSON. Missing lists, mismatched lists, ignored/deprecated policies and stale exports must block handoff.
- Allowed login/exam/project works; external site shows actual policy denial, not a connection failure.
- Edge AI sidebar, toolbar and writing entry points unavailable for deployed browser/profile. In-site AI is out of scope.
- USB denial verified. Edge full-screen restored; compact toolbar usable.
- Student Finish shows Awaiting Staff and app PIN; closing PIN cannot restore student editing through the app. OS escape routes remain a known limitation, not a secure kiosk.
- Staff resume repeats browser verification. Staff finalizes according to actual site submission; app Finish does not submit Canvas/Posit.

## Word test
- Import preserves original. Type dummy answers while repeated saves/recovery run; no sharing violation.
- Finish checkpoint, staff PIN, finalize, choose any export destination, hash-verify exported copy, restore controls, then complete.
- Disconnect export drive or deny write permission: keep local work/session, never falsely complete or delete.
- Crash/reboot during preparing/active/saving/export/restoration: recovery blocks new test and preserves work.

## Settings / config / updates
- Staff/local list editor, dark/light inputs/dropdowns and small-display scaling remain legible.
- Online valid config caches; no network/bad JSON/bad hash/timeout uses prior cache/local fallback.
- Active session keeps its snapshotted settings. No prior broad Beta 2 cache is accepted as Beta 3 config.
- GitHub global files and Beta 3 release/update integration are tested only after authorized publication.
