!ifndef SOURCE_DIR
 !error "Supply SOURCE_DIR"
!endif
!ifndef PAYLOAD_DIR
 !error "Supply PAYLOAD_DIR"
!endif
!ifndef OUTPUT_FILE
 !error "Supply OUTPUT_FILE"
!endif
Unicode true
!include "MUI2.nsh"
!include "x64.nsh"
!include "LogicLib.nsh"
Name "Accommodation Test Manager Beta 3"
OutFile "${OUTPUT_FILE}"
InstallDir "$PROGRAMFILES64\AccommodationTestManagerBeta2"
RequestExecutionLevel admin
SetCompressor /SOLID lzma
CRCCheck on
ManifestDPIAware true
VIProductVersion "1.0.0.5"
VIAddVersionKey "ProductName" "Accommodation Test Manager Beta 3"
VIAddVersionKey "FileDescription" "Beta 3 Setup - synthetic testing only"
VIAddVersionKey "FileVersion" "1.0.0.5"
VIAddVersionKey "ProductVersion" "1.0.0-beta.3.1-setup.1"
VIAddVersionKey "LegalCopyright" "Accommodation Test Manager beta"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Install Accommodation Test Manager"
!define MUI_WELCOMEPAGE_TEXT "Beta 3 - dedicated synthetic testing only.$\r$\n$\r$\nInstalls the app, helper, bundled .NET runtime and desktop shortcut together. No separate PowerShell install is needed.$\r$\n$\r$\nAdministrator approval is required. This UNSIGNED beta is not a secure production exam kiosk. Install only with IT approval.$\r$\n$\r$\nClose the app. Legacy Beta 2 snapshots are archived and gate new machine tests; setup does not repair missing registry values. No test restrictions are applied by setup."
!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_INSTFILES
!define MUI_FINISHPAGE_TITLE "Setup finished"
!define MUI_FINISHPAGE_TEXT "Close setup, then sign in to the STANDARD testing account and open the Beta 3 desktop shortcut normally.$\r$\n$\r$\nDo not run the whole app as administrator. Only its helper receives separate authorization for test controls.$\r$\n$\r$\nUse synthetic tests and the installed Docs checklist first. Native Windows setup/device testing still needs confirmation."
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_UNPAGE_FINISH
!insertmacro MUI_LANGUAGE "English"
Var Result
Function .onInit
 ${IfNot} ${RunningX64}
  MessageBox MB_ICONSTOP|MB_OK "This beta requires Windows 11 x64." /SD IDOK
  Abort
 ${EndIf}
 SetRegView 64
 StrCpy $INSTDIR "$PROGRAMFILES64\AccommodationTestManagerBeta2"
 SetShellVarContext all
FunctionEnd
Section "Install"
 InitPluginsDir
 SetOutPath "$PLUGINSDIR\AppPayload"
 File /r "${PAYLOAD_DIR}/*"
 SetOutPath "$PLUGINSDIR\Docs"
 File /r "${SOURCE_DIR}/Docs/*"
 SetOutPath "$PLUGINSDIR"
 File "${SOURCE_DIR}/Install-OneClick.ps1"
 DetailPrint "Installing app, bundled runtime and protected helper..."
 nsExec::ExecToLog '"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$PLUGINSDIR\Install-OneClick.ps1" -PayloadFolder "$PLUGINSDIR\AppPayload" -DocsFolder "$PLUGINSDIR\Docs"'
 Pop $Result
 ${If} $Result != 0
  SetErrorLevel 1
  MessageBox MB_ICONSTOP|MB_OK "Setup did not complete. See the Details log. Close the app. Preserve unresolved controls and snapshots; legacy state requires review, not the old helper. Ask an administrator about script policy/permissions. Existing session files and snapshots were not deleted." /SD IDOK
  Abort
 ${EndIf}
 SetOutPath "$INSTDIR"
 WriteUninstaller "$INSTDIR\Uninstall.exe"
 Delete "$DESKTOP\Accommodation Test Manager Beta 2.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 2\Accommodation Test Manager.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 2\Installation guide.lnk"
 RMDir "$SMPROGRAMS\Accommodation Test Manager Beta 2"
 CreateShortcut "$DESKTOP\Accommodation Test Manager Beta 3.lnk" "$INSTDIR\AccommodationTestManager.exe" "" "$INSTDIR\AccommodationTestManager.exe" 0
 CreateDirectory "$SMPROGRAMS\Accommodation Test Manager Beta 3"
 CreateShortcut "$SMPROGRAMS\Accommodation Test Manager Beta 3\Accommodation Test Manager.lnk" "$INSTDIR\AccommodationTestManager.exe" "" "$INSTDIR\AccommodationTestManager.exe" 0
 CreateShortcut "$SMPROGRAMS\Accommodation Test Manager Beta 3\Installation guide.lnk" "$INSTDIR\Docs\START-HERE.txt"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "DisplayName" "Accommodation Test Manager Beta 3"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "DisplayVersion" "1.0.0-beta.3.1-setup.1"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "InstallLocation" "$INSTDIR"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "DisplayIcon" "$INSTDIR\AccommodationTestManager.exe"
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "UninstallString" '$\"$INSTDIR\Uninstall.exe$\"'
 WriteRegStr HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "URLInfoAbout" "https://github.com/EmmanuelA0428/AccommodationTestManager"
 WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "NoModify" 1
 WriteRegDWORD HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2" "NoRepair" 1
SectionEnd
Function un.onInit
 SetRegView 64
 SetShellVarContext all
FunctionEnd
Section "Uninstall"
 nsExec::ExecToLog '"$WINDIR\Sysnative\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -ExecutionPolicy Bypass -File "$INSTDIR\SetupSupport\Uninstall-OneClick.ps1" -InstallFolder "$INSTDIR"'
 Pop $Result
 ${If} $Result != 0
  SetErrorLevel 1
  MessageBox MB_ICONSTOP|MB_OK "Uninstall stopped. Close the app and restore pending machine controls first, or ask IT. Exam sessions/settings and recovery snapshots were not deleted." /SD IDOK
  Abort
 ${EndIf}
 Delete "$DESKTOP\Accommodation Test Manager Beta 3.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 3\Accommodation Test Manager.lnk"
 Delete "$SMPROGRAMS\Accommodation Test Manager Beta 3\Installation guide.lnk"
 RMDir "$SMPROGRAMS\Accommodation Test Manager Beta 3"
 DeleteRegKey HKLM "Software\Microsoft\Windows\CurrentVersion\Uninstall\AccommodationTestManagerBeta2"
 Delete "$INSTDIR\Uninstall.exe"
 RMDir "$INSTDIR"
SectionEnd
