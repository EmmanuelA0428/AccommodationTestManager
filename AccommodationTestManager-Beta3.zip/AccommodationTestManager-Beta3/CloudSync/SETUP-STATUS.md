# Beta 3.3 cloud integration candidate

## Live Firebase
- Project `accommodation-test-manager`, Standard Firestore `(default)`, `nam5` United States, Spark plan. No billing upgrade, Analytics, cloud file storage, or paid hosting enabled.
- Anonymous Authentication enabled. Clients automatically create their own identity and device record; no approval step or daily cloud login.
- Tested rules published. Unauthenticated HTTP requests receive 403. An anonymous Firebase identity is not proof of an approved physical laptop: this deliberately lightweight design does not prevent an outsider with the public client config from registering an identity. Session metadata is non-identifying; writes are owner-scoped; configuration publishing remains restricted.
- Initial `configuration/current` revision 1: save 60 seconds, recovery snapshot 180 seconds, five recovery copies, no default time limit.
- Administration is through trusted Firebase Console for now. No administrator membership or editing portal is provisioned; client configuration writes are denied without separately bootstrapped admin membership. Increment revision when changing defaults in the console.
- Live C# REST probe passed: two anonymous clients, automatic registration, owner session write, cross-client directory, central config read. Only synthetic data. Temporary Auth users deleted. Two synthetic device documents and one Cancelled synthetic session remain pending authorized cleanup; their IDs are not credentials.

## Desktop candidate
- Public Firebase client configuration bundled. No service-account keys or administrator credentials.
- Refresh credential protected with Windows-user DPAPI, never uploaded/logged. Corrupt/revoked identity is not silently replaced.
- Fixed anonymous metadata projection; durable atomic coalescing outbox, persistent revisions, exact acknowledgement, idempotent retry, server revision conflicts retained.
- Startup, debounced session-change uploads, and five-minute incremental sync are non-blocking. Local tests/restoration do not depend on Firebase. Per-user local storage remains unchanged.
- All tests: local files/recovery tab plus cached all-laptops metadata tab and Sync now. This-laptop rows bold. Other devices' recovery availability is last reported, not proof of current file availability. Physical machines can be matched by the Laptop-ID label shown in sync status; administrators can set device labels in the console.
- Session downloads use a server-updated-time watermark after initial inventory; device labels refresh every 30 minutes, avoiding full-history polling costs. Sync now is available for immediate refresh.
- Cache records last success; UI distinguishes syncing, successful revision, queued changes, and out-of-sync/review states.
- Cloud defaults are validated and layered over GitHub/local defaults without overwriting the local fallback. Updates during a test wait until idle. No machine-control, restore-receipt, PIN, student, path, URL, or document fields are accepted in cloud session records.
- Shared staff-list editing and shared PIN rotation are NOT implemented in this candidate. PIN/staff settings remain local. No remote file retrieval, cloud backup of exam files, or web editing portal.

## Other staged UI fixes
- Resume Test / Export Test primary actions; diagnostics under expander.
- Student toolbar closes after Finish/cancellation/terminal states.
- Reported exact Posit login host added to bundled and staged global allowlists; global manifest revision 2 checksums updated. Must publish GlobalConfiguration under repository `global-config-beta3/` too.
- Existing administrator helper authorization and online browser-policy/preflight checks remain. This candidate does not silently remove those requirements, implement a privileged broker, or provide OS lockdown.

## Validation
- 218 developer/integration checks with Firebase emulators (mock Word/timer/helper; real filesystem/settings/coordinator/outbox/REST).
- 34 Firestore rule checks: automatic registration, shared reads, owner-only updates, private-field rejection, revision protection, editor-only config, revocation.
- Windows-targeted app and native UI harness compile with zero warnings/errors on Linux. Actual Windows UI/installer run and real Word/Edge/device acceptance still required before a release.
- Run offline developer suite: `dotnet run --project DeveloperTests/BetaTests.csproj`.
- Run emulator suite from CloudSync after npm install: `firebase emulators:exec --only firestore,auth --project demo-atm-sync "node rules-tests.cjs && cd .. && ATM_CLOUD_EMULATOR_TESTS=1 dotnet run --project DeveloperTests/BetaTests.csproj"`.

## Laptop acceptance (synthetic data only)
1. Install normally on two laptops; keep the app under the standard testing account. Existing install admin approval remains.
2. Check sync status: matching settings revision, distinct Laptop-ID labels. Update device labels in console if needed.
3. Start/cancel a synthetic session on A; verify anonymous metadata appears on B after Sync now. Verify B cannot open A's files.
4. Disconnect A for hours, test locally, restart while offline, reconnect; verify one latest record per session and queue drains.
5. Change safe default plus increment central revision during a test; verify its current settings snapshot does not change, next test uses new defaults.
6. Confirm no student names, answers, document filenames/paths or PINs appear in Firestore.
