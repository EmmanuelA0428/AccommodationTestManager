# Administrator recovery OUTSIDE the WPF app. Does not delete or complete tests.
$ErrorActionPreference='Stop'
$helper=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2\Scripts\Beta2Restrictions.ps1'
$state='C:\ProgramData\AccommodationTestingBeta2\RestrictionState'
if(-not(Test-Path $helper)){throw 'Installed helper missing.'}
foreach($file in @(Get-ChildItem $state -Filter '*.json'|Where-Object{$_.Name-notlike '*.report.json'})){
 $record=Get-Content -LiteralPath $file.FullName -Raw|ConvertFrom-Json
 if($record.Status-ne 'Restored'){& $helper -Action Restore -SessionId $record.SessionId}
}
Write-Host 'Review snapshots: all unresolved state must be Restored before another test. No exam files were removed.'
