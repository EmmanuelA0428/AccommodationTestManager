using AccommodationTestManager;
using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using AccommodationTestManager.Views;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

sealed class ProbeApp:App { protected override void OnStartup(StartupEventArgs e) { /* Never run real app startup/registration in CI. */ } }
static class UiProbe
{
 static int _checks;
 static void Check(bool value,string message){if(!value)throw new Exception("UI FAIL: "+message);_checks++;Console.WriteLine("UI PASS: "+message);}
 static void Pump(){var frame=new DispatcherFrame();Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.ContextIdle,new Action(()=>frame.Continue=false));Dispatcher.PushFrame(frame);}
 static T Named<T>(FrameworkElement element,string name) where T:DependencyObject=>(T)element.FindName(name);
 static void Invoke(object target,string name)=>target.GetType().GetMethod(name,BindingFlags.Instance|BindingFlags.NonPublic)!.Invoke(target,null);
 static void SetHost(App app,string name,object value)=>typeof(App).GetProperty(name)!.SetValue(app,value);
 [STAThread] public static int Main()
 {
  string root=Path.Combine(Path.GetTempPath(),"ATM-UiProbe-"+Guid.NewGuid().ToString("N"));
  Directory.CreateDirectory(root);
  try
  {
   SynchronizationContext.SetSynchronizationContext(new DispatcherSynchronizationContext(Dispatcher.CurrentDispatcher));
   #pragma warning disable WPF0001 // Match the production App.xaml ThemeMode.
   var app=new ProbeApp { ShutdownMode=ShutdownMode.OnExplicitShutdown, ThemeMode=ThemeMode.Light };
   #pragma warning restore WPF0001
   // Load the real shared dictionaries without App.InitializeComponent, whose
   // generated resource loader requires the exact App type rather than ProbeApp.
   foreach(string resource in new[]{"Theme.xaml","Components.xaml"})
    app.Resources.MergedDictionaries.Add(new ResourceDictionary { Source=new Uri("/AccommodationTestManager;component/Resources/"+resource,UriKind.Relative) });
   var storage=new LocalStorageService(root);
   LocalStorageService.WriteJson(storage.SettingsPath,new AppSettings{DeviceId=Guid.NewGuid().ToString("N"),RequireMachineRestrictions=false});
   var settings=new SettingsService(storage);settings.Load();settings.Register("SYNTHETIC UI LAPTOP","FAKE",["Synthetic staff"],"654321");
   var lists=new AllowlistService(storage);lists.Initialize();var restrictions=new RestrictionService();var theme=new ThemeService(settings);var sessions=new SessionService(storage,settings,lists,restrictions);
   SetHost(app,"Storage",storage);SetHost(app,"Settings",settings);SetHost(app,"Allowlists",lists);SetHost(app,"Restrictions",restrictions);SetHost(app,"Theme",theme);SetHost(app,"Sessions",sessions);
   theme.Apply();var window=new MainWindow();window.Show();Pump();window.UpdateLayout();
   var host=Named<ContentControl>(window,"StepHost");var student=(FrameworkElement)host.Content;
   var staff=Named<ComboBox>(student,"StaffChoice");var studentName=Named<TextBox>(student,"StudentNameInput");var testName=Named<TextBox>(student,"TestNameInput");
   staff.SelectedIndex=0;studentName.Text="Synthetic student";testName.Text="Layout probe only";Pump();window.UpdateLayout();
   foreach(string mode in new[]{"Light","Dark"})
   {
    settings.Current.Theme=mode;theme.Apply();Pump();window.UpdateLayout();staff.ApplyTemplate();
    var toggle=(ToggleButton)staff.Template.FindName("DropToggle",staff);
    Check(staff.ActualHeight>=43.5,mode+" staff selector retains 44-DIP height");
    Check(Math.Abs(staff.ActualWidth-studentName.ActualWidth)<2,mode+" staff selector fills the form like text fields");
    Check(toggle.ActualHeight>=43.5&&Math.Abs(toggle.ActualWidth-staff.ActualWidth)<2,mode+" dropdown chrome fills its selector");
    var feature=Named<Button>(window,"FeatureTestingButton");var gear=Named<Button>(window,"SettingsButton");var appearance=Named<Button>(window,"ThemeButton");
    double y=feature.TranslatePoint(new Point(),window).Y;
    Check(Math.Abs(gear.TranslatePoint(new Point(),window).Y-y)<1&&Math.Abs(appearance.TranslatePoint(new Point(),window).Y-y)<1,mode+" toolbar icons align with text buttons");
    Check(Named<Button>(window,"NextButton").IsEnabled,mode+" completed student information allows Continue");
    var bitmap=new RenderTargetBitmap((int)window.ActualWidth,(int)window.ActualHeight,96,96,PixelFormats.Pbgra32);bitmap.Render(window);
    var png=new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(bitmap));using(var file=File.Create(Path.Combine(Environment.CurrentDirectory,"Update2-"+mode+"-synthetic-ui.png")))png.Save(file);
   }
   var next=Named<Button>(window,"NextButton");next.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));Pump();
   Check(Named<TextBlock>(window,"StepCounter").Text.Contains("Step 2"),"Continue advances from populated Student step");
   typeof(MainWindow).GetField("_step",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(window,0);Invoke(window,"Refresh");
   string id=Guid.NewGuid().ToString("N");string folder=storage.NewSessionFolder(id);
   var pending=new TestSession{Id=id,DeviceId=settings.Current.DeviceId,Status="Preparing",TestName="SYNTHETIC unfinished",CreatedUtc=DateTimeOffset.UtcNow};LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),pending);
   Invoke(window,"RecheckSetupReadiness");Invoke(window,"Refresh");Pump();
   Check(Named<Border>(window,"SetupBlockBanner").Visibility==Visibility.Visible,"unfinished session has visible actionable banner");
   Check(next.IsEnabled,"unfinished session permits draft Continue, not silent dead-end");
   typeof(MainWindow).GetField("_step",BindingFlags.Instance|BindingFlags.NonPublic)!.SetValue(window,3);Invoke(window,"Refresh");Check(!next.IsEnabled,"Start remains blocked for unresolved session");
   pending.Status="Cancelled";LocalStorageService.WriteJson(Path.Combine(folder,"session.json"),pending);Invoke(window,"RecheckSetupReadiness");Invoke(window,"Refresh");Check(next.IsEnabled,"resolved fixture clears cached navigation gate");
   var pane=new SettingsWindow("Synthetic staff"){Owner=window};pane.Show();Pump();
   var check=Named<Button>(pane,"CheckUpdatesButton");check.RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
   var deadline=DateTime.UtcNow.AddSeconds(40);while(!check.IsEnabled&&DateTime.UtcNow<deadline){Pump();Thread.Sleep(50);}
   Check(check.IsEnabled,"Check for updates completes without freezing UI");
   string status=Named<TextBlock>(pane,"UpdateStatusText").Text;
   Check(status.Contains("latest recognized")||status.StartsWith("Available:"),"Check for updates reads real public release metadata");
   pane.Close();
   var diag=new DiagnosticsWindow(){Owner=window};diag.Show();Pump();Check(diag.Title.Contains("read-only"),"in-app diagnostics opens without invoking a helper");diag.Close();
   var handoff=new AwaitingStaffWindow(){Owner=window};handoff.Show();Pump();handoff.Close();Check(handoff.IsVisible,"closing handoff without PIN is vetoed");
   // Exercise actual StaffDialogs PIN verification inside its modal dispatcher loop.
   Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,new Action(()=>
   {
       var pinWindow=Application.Current.Windows.Cast<Window>().First(x=>x.Title=="Authorize finished-test handoff");
       IEnumerable<FrameworkElement> Walk(DependencyObject d){for(int i=0;i<VisualTreeHelper.GetChildrenCount(d);i++){var c=VisualTreeHelper.GetChild(d,i);if(c is FrameworkElement f)yield return f;foreach(var nested in Walk(c))yield return nested;}}
       var controls=Walk(pinWindow).ToList();controls.OfType<ComboBox>().First(x=>x.Name=="StaffAuthorizationChoice").SelectedIndex=0;
       controls.OfType<PasswordBox>().First(x=>x.Name=="StaffAuthorizationPin").Password="654321";
       controls.OfType<Button>().First(x=>x.Name=="StaffAuthorizeButton").RaiseEvent(new RoutedEventArgs(Button.ClickEvent));
   }));
   // A modal handoff's DialogResult cannot be set from a modeless Show; test the PIN
   // dialog separately, and permit fixture shutdown explicitly afterward.
   string? authorized=StaffDialogs.Authorize(handoff,settings,"Authorize finished-test handoff","Synthetic staff");
   Check(authorized=="Synthetic staff","real staff PIN authorizes handoff");handoff.AllowShutdown=true;handoff.Close();
   window.Close();app.Shutdown();
   Console.WriteLine($"ALL {_checks} NATIVE WPF CHECKS PASSED — synthetic data; no Word, machine-control or PIN action.");return 0;
  }
  catch(Exception ex){Console.Error.WriteLine(ex);return 1;}
  finally{try{Directory.Delete(root,true);}catch{}}
 }
}
