namespace AccommodationTestManager.Models;

public sealed class AppSettings
{
    // Local configuration; large URL lists live in separate allowlist files.
    public string _ReadMe { get; set; } = "Beta 2: scoped Edge/network/USB controls; not application lockdown or comprehensive AI prevention.";
    public int SchemaVersion { get; set; } = 2;
    public bool GlobalConfigEnabled { get; set; } = true;
    public int GlobalConfigVersion { get; set; }
    public List<StaffMember> StaffMembers { get; set; } = [];
    public List<ApprovedApplication> ApprovedApplications { get; set; } = [];
    public bool RequireMachineRestrictions { get; set; } = true;
    // AppLocker is deliberately not silently enabled by this untested beta.
    public bool EnableApplicationLockdown { get; set; }
    public bool RequireBrowserSmokeTest { get; set; } = true;
    public string CanvasUrl { get; set; } = "";
    public string[] CanvasAllowlist { get; set; } = [];
    public string PositUrl { get; set; } = "";
    public string[] PositAllowlist { get; set; } = [];
    public string[] BlockedAIUrls { get; set; } = ["https://copilot.microsoft.com","https://chatgpt.com","https://chat.openai.com","https://claude.ai","https://gemini.google.com","https://www.microsoft.com/copilot"];
    public bool DisableBrowserAI { get; set; } = true;
    public string Theme { get; set; } = "System";
    public string LaptopName { get; set; } = "";
    public string AssetTag { get; set; } = "";
    public string DeviceId { get; set; } = "";
    public string[] StaffNames { get; set; } = [];
    public int SaveIntervalSeconds { get; set; } = 60;
    public int SnapshotIntervalSeconds { get; set; } = 180;
    public int MaximumRecoveryCopies { get; set; } = 5;
    public int? DefaultTimeLimitMinutes { get; set; }
    public int? RetentionDays { get; set; }
    public string DefaultExportDirectory { get; set; } = "";
    public int ConfigVersion { get; set; } = 1;
    public string StaffPinSalt { get; set; } = "";
    public string StaffPinHash { get; set; } = "";
    public DateTimeOffset? LastAdminPinResetUtc { get; set; }
    public string LastAdminPinResetBy { get; set; } = "";
}
public sealed class TestSession
{
    public string Id { get; set; } = "";
    public string DeviceId { get; set; } = "";
    public string LaptopName { get; set; } = "";
    public string StudentName { get; set; } = "";
    public string TestName { get; set; } = "";
    public string Mode { get; set; } = "Word";
    public string Status { get; set; } = "Preparing";
    public string StartedById { get; set; } = "";
    public string CustomKind { get; set; } = "Website";
    public string ApplicationId { get; set; } = "";
    public string ApplicationPath { get; set; } = "";
    public string AllowlistId { get; set; } = "";
    public string[] AllowedUrls { get; set; } = [];
    public string BrowserProfileRelativePath { get; set; } = "BrowserProfile";
    public bool RestrictionsApplied { get; set; }
    public bool RestrictionsRestored { get; set; }
    public string StartedBy { get; set; } = "";
    public string FinalizedBy { get; set; } = "";
    public string OriginalFileName { get; set; } = "";
    public string SourcePath { get; set; } = "";
    public string SourceSha256 { get; set; } = "";
    public string WorkingRelativePath { get; set; } = "";
    public string FinishRelativePath { get; set; } = "";
    public string FinishSha256 { get; set; } = "";
    public string FinalRelativePath { get; set; } = "";
    public string FinalSha256 { get; set; } = "";
    public string ExportPath { get; set; } = "";
    public string ExportSha256 { get; set; } = "";
    public string WebUrl { get; set; } = "";
    public bool SubmissionVerifiedByStaff { get; set; }
    public bool TextToSpeech { get; set; }
    public bool SpeechToText { get; set; }
    public DateTimeOffset CreatedUtc { get; set; }
    public DateTimeOffset? StartedUtc { get; set; }
    public DateTimeOffset? FinishedUtc { get; set; }
    public DateTimeOffset? CompletedUtc { get; set; }
    public DateTimeOffset? DeadlineUtc { get; set; }
    public int? DurationMinutes { get; set; }
    public double? RemainingSeconds { get; set; }
    public DateTimeOffset? LastSaveUtc { get; set; }
    public DateTimeOffset? LastSnapshotUtc { get; set; }
    public string LastSaveHealth { get; set; } = "Not checked";
    public string SecurityStatus { get; set; } = "UNENFORCED LOCAL BETA";
    public AppSettings SettingsSnapshot { get; set; } = new();
    public List<SnapshotReceipt> RecoveryReceipts { get; set; } = [];
    public List<SessionEvent> Events { get; set; } = [];
}
public sealed record SnapshotReceipt(string RelativePath, string Sha256, DateTimeOffset CreatedUtc);
public sealed record SessionEvent(string Id, DateTimeOffset AtUtc, string Action, string Staff, string Detail, string StaffId = "");
public sealed record SessionEntry(string Folder, TestSession Session);

public sealed class StaffMember
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public bool Active { get; set; } = true;
}
public sealed class ApprovedApplication
{
    public string Id { get; set; } = Guid.NewGuid().ToString("N");
    public string Name { get; set; } = "";
    public string Executable { get; set; } = "";
    public bool NetworkRequired { get; set; }
    public override string ToString() => Name;
}
public sealed class AllowlistConfiguration
{
    public string Id { get; set; } = "";
    public int Version { get; set; } = 1;
    public string Description { get; set; } = "";
    public List<string> UrlPatterns { get; set; } = [];
    public override string ToString() => Id;
}
