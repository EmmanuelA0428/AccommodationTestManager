# Protected, installed helper. NEVER run this from a student-writable folder.
# Scope: network adapters, removable-storage policy, mandatory Edge policies.
# NOT AppLocker, a secure kiosk, protected exam storage, or all-AI enforcement.
[CmdletBinding()]
param(
 [Parameter(Mandatory=$true)][ValidateSet('Apply','ExportAccess','Restore')][string]$Action,
 [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{32}$')][string]$SessionId,
 [string]$RequestPath
)
$ErrorActionPreference='Stop'
$StateRoot='C:\ProgramData\AccommodationTestingBeta2\RestrictionState'
$Edge='HKLM:\SOFTWARE\Policies\Microsoft\Edge'
$Usb='HKLM:\SOFTWARE\Policies\Microsoft\Windows\RemovableStorageDevices'
$ControlledEdge=@('BrowserSignin','SyncDisabled','StartupBoostEnabled','BackgroundModeEnabled')
function Assert-Admin {
 $id=[Security.Principal.WindowsIdentity]::GetCurrent();$p=New-Object Security.Principal.WindowsPrincipal($id)
 if(-not $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)){throw 'Administrator authorization required.'}
}
function Write-Atomic([string]$Path,$Value) {
 $temp=$Path+'.'+[guid]::NewGuid().ToString('N')+'.tmp';$bytes=[Text.Encoding]::UTF8.GetBytes(($Value|ConvertTo-Json -Depth 30))
 $s=[IO.File]::Open($temp,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
 try{$s.Write($bytes,0,$bytes.Length);$s.Flush($true)}finally{$s.Dispose()}
 if(Test-Path -LiteralPath $Path){[IO.File]::Replace($temp,$Path,$Path+'.bak')}else{[IO.File]::Move($temp,$Path)}
}
function Snapshot-Value([string]$Path,[string]$Name) {
 $key=Get-Item -LiteralPath $Path -ErrorAction SilentlyContinue
 if($null-ne $key -and $key.GetValueNames()-contains $Name){return @{Path=$Path;Name=$Name;Present=$true;Kind=$key.GetValueKind($Name).ToString();Value=$key.GetValue($Name)}}
 return @{Path=$Path;Name=$Name;Present=$false;Kind='DWord';Value=$null}
}
function Snapshot-List([string]$Name) {
 $path="$Edge\$Name";$exists=Test-Path -LiteralPath $path;$values=@()
 if($exists){$key=Get-Item -LiteralPath $path;if(@(Get-ChildItem -LiteralPath $path).Count-gt 0){throw "Unexpected nested policy: $Name"};foreach($n in $key.GetValueNames()){$values+=Snapshot-Value $path $n}}
 return @{Path=$path;Present=$exists;Values=$values}
}
function Set-Value([string]$Path,[string]$Name,$Value,[string]$Kind='DWord') {
 New-Item -Path $Path -Force|Out-Null;New-ItemProperty -Path $Path -Name $Name -Value $Value -PropertyType $Kind -Force|Out-Null
 if((Get-Item $Path).GetValue($Name)-ne $Value){throw "Registry readback failed: $Name"}
}
function Restore-Value($v) {
 if($null-ne $v.Expected){$now=Snapshot-Value $v.Path $v.Name;$matchesApplied=($now.Present-eq $v.Expected.Present -and ($now.Value|ConvertTo-Json -Compress)-eq ($v.Expected.Value|ConvertTo-Json -Compress));$matchesOriginal=($now.Present-eq $v.Present -and ($now.Value|ConvertTo-Json -Compress)-eq ($v.Value|ConvertTo-Json -Compress));if(-not $matchesApplied -and -not $matchesOriginal){throw "Policy changed outside this app; staff/IT review required: $($v.Name)"}}
 if($v.Present){Set-Value $v.Path $v.Name $v.Value $v.Kind}
 elseif(Test-Path -LiteralPath $v.Path){Remove-ItemProperty -LiteralPath $v.Path -Name $v.Name -ErrorAction SilentlyContinue;if((Get-Item $v.Path).GetValueNames()-contains $v.Name){throw "Failed restoring absent value: $($v.Name)"}}
}
function Set-List([string]$Name,[string[]]$Values) {
 $path="$Edge\$Name";if(Test-Path -LiteralPath $path){Remove-Item -LiteralPath $path -Recurse -Force};New-Item -Path $path -Force|Out-Null
 $i=1;foreach($value in $Values){Set-Value $path "$i" $value 'String';$i++}
}
function Restore-List($l) {
 if($null-ne $l.Expected){$current=Snapshot-List ([IO.Path]::GetFileName($l.Path));$a=($current.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress);$b=($l.Expected.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress);$c=($l.Values|Sort-Object Name|Select-Object Name,Kind,Value|ConvertTo-Json -Depth 10 -Compress);if($a-ne $b -and $a-ne $c){throw 'URL/extension policy changed outside this app; staff/IT review required.'}}
 if(Test-Path -LiteralPath $l.Path){Remove-Item -LiteralPath $l.Path -Recurse -Force}
 if($l.Present){New-Item -Path $l.Path -Force|Out-Null;foreach($v in @($l.Values)){Restore-Value $v}}
}
# Windows creates/removes these infrastructure interfaces automatically. They are
# not independent Wi-Fi/Ethernet connections and must not be toggled directly.
function Is-WindowsInfrastructureAdapter($adapter) {
 $description=[string]$adapter.InterfaceDescription
 $name=[string]$adapter.Name
 if($description -match '^(Microsoft Wi-Fi Direct Virtual Adapter(?: #\d+)?|WAN Miniport \([^)]+\)|Microsoft Kernel Debug Network Adapter)$'){return $true}
 if($description -match 'Loopback'){return $true}
 if([string]::IsNullOrWhiteSpace($description) -and $name -in @('Teredo Tunneling Pseudo-Interface','6to4 Adapter','Microsoft IP-HTTPS Platform Interface')){return $true}
 return $false
}
function Find-Adapter([string]$Guid) {
 $target=$Guid.Trim([char[]]'{}')
 @(Get-NetAdapter -IncludeHidden | Where-Object {([string]$_.InterfaceGuid).Trim([char[]]'{}') -eq $target}) | Select-Object -First 1
}
function Active-Adapters {
 @(Get-NetAdapter -IncludeHidden | Where-Object {
  $_.Status -notin @('Disabled','Not Present','NotPresent') -and
  -not (Is-WindowsInfrastructureAdapter $_)
 })
}
function Record-NetworkNote($state,[string]$message) {
 $notes=@($state.NetworkRestoreNotes | Where-Object {$null -ne $_})+@($message)
 if($state -is [System.Collections.IDictionary]){$state['NetworkRestoreNotes']=$notes}
 else{$state | Add-Member -NotePropertyName NetworkRestoreNotes -NotePropertyValue $notes -Force}
}
function Restore-Network($state) {
 # Classify against the INITIAL inventory before re-enabling Wi-Fi. Child adapters
 # can vanish/reappear during that operation. Legacy snapshots have only Name/Guid.
 $inventory=@(Get-NetAdapter -IncludeHidden)
 $work=@(foreach($a in @($state.Adapters)){
  $initial=$inventory | Where-Object {([string]$_.InterfaceGuid).Trim([char[]]'{}') -eq ([string]$a.Guid).Trim([char[]]'{}')} | Select-Object -First 1
  $classification=$initial
  if($null -eq $classification -and -not [string]::IsNullOrWhiteSpace([string]$a.InterfaceDescription)){$classification=$a}
  $infrastructure=$null -ne $classification -and (Is-WindowsInfrastructureAdapter $classification)
  $physical=($null -ne $initial -and $initial.HardwareInterface -eq $true) -or $a.HardwareInterface -eq $true
  [pscustomobject]@{Record=$a;Infrastructure=$infrastructure;Priority=$(if($physical){0}elseif($infrastructure){2}else{1})}
 })
 $problems=@()
 foreach($item in @($work | Sort-Object Priority)) {
  $a=$item.Record
  try {
   # New snapshots record initial enabled state and intent before each change.
   # Never enable an adapter that was initially disabled or not yet changed by us.
   if($a.OriginalStatus -eq 'Disabled'){continue}
   if($null -ne $a.ChangedByHelper -and -not $a.ChangedByHelper){continue}
   $adapter=Find-Adapter $a.Guid
   if($null -eq $adapter -and -not $item.Infrastructure){
    for($attempt=0;$attempt -lt 5 -and $null -eq $adapter;$attempt++){Start-Sleep -Milliseconds 400;$adapter=Find-Adapter $a.Guid}
   }
   if($null -eq $adapter -or $adapter.Status -in @('Not Present','NotPresent')) {
    if($item.Infrastructure){Record-NetworkNote $state ('Windows-managed infrastructure interface unavailable after parent restore: '+$a.Name);continue}
    throw ('Original connection adapter missing/not present: '+$a.Name+' ['+$a.Guid+']. Reconnect the same device/dock and retry; do not delete the snapshot.')
   }
   # Old helper may have disabled a WAN/Wi-Fi Direct interface. If it still exists
   # AND is disabled, attempt its restoration too; failure remains unresolved.
   if($adapter.Status -eq 'Disabled'){Enable-NetAdapter -InputObject $adapter -Confirm:$false -ErrorAction Stop}
   $check=Find-Adapter $a.Guid
   for($attempt=0;$attempt -lt 5 -and ($null -eq $check -or $check.Status -eq 'Disabled');$attempt++){Start-Sleep -Milliseconds 400;$check=Find-Adapter $a.Guid}
   if($null -eq $check -and $item.Infrastructure){Record-NetworkNote $state ('Windows-managed infrastructure interface refreshed during restore: '+$a.Name);continue}
   if($null -eq $check -or $check.Status -in @('Disabled','Not Present','NotPresent')){throw ('Adapter restoration not confirmed: '+$a.Name)}
  } catch {$problems+=$_.Exception.Message}
 }
 # Attempt ALL recorded connections even if one failed; keep failure visible.
 if($problems.Count -gt 0){throw ($problems -join '; ')}
}
function Disable-RecordedAdapters($state,[string]$statePath) {
  foreach($a in @($state.Adapters)){
   $adapter=Find-Adapter $a.Guid
   if($null -eq $adapter -or $adapter.Status -in @('Not Present','NotPresent')){throw ('Connection adapter disappeared before disable: '+$a.Name+'. No null InputObject was passed.')}
   if($adapter.Status -eq 'Disabled'){throw ('Adapter changed outside this helper before disable: '+$a.Name)}
   # Persist intent BEFORE disabling so interrupted Apply can restore this adapter.
   $a.ChangedByHelper=$true;Write-Atomic $statePath $state
   Disable-NetAdapter -InputObject $adapter -Confirm:$false -ErrorAction Stop
  }
}
function Restore-All($state) {
 $problems=@()
 foreach($v in @($state.Registry)){try{Restore-Value $v}catch{$problems+=$_.Exception.Message}}
 foreach($l in @($state.Lists)){try{Restore-List $l}catch{$problems+=$_.Exception.Message}}
 try{Restore-Network $state}catch{$problems+=$_.Exception.Message}
 if($problems.Count-gt 0){throw ($problems-join '; ')}
}
$stage='Authorize and validate installation'
try {
Assert-Admin
$installed=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2\Scripts\Beta2Restrictions.ps1'
if([IO.Path]::GetFullPath($PSCommandPath)-ne [IO.Path]::GetFullPath($installed)){throw 'Install Beta 2 first. Helper must be in protected Program Files.'}
if(-not(Test-Path $StateRoot)){throw 'Protected state folder missing. Run Install-Beta2.ps1 as administrator.'}
if((Get-Item $StateRoot).Attributes-band [IO.FileAttributes]::ReparsePoint){throw 'Reparse-point state folder rejected.'}
$statePath=Join-Path $StateRoot ($SessionId+'.json')
$stage='Validate startup prerequisites'
if($Action-eq 'Apply') {
 # Refuse overlapping machine restriction snapshots, including interrupted restores.
 $pending=@(Get-ChildItem $StateRoot -Filter '*.json'|Where-Object{$_.Name-notlike '*.report.json'}|ForEach-Object{Get-Content -LiteralPath $_.FullName -Raw|ConvertFrom-Json}|Where-Object{$_.Status-ne 'Restored'})
 if($pending.Count-gt 0){throw 'Another restriction snapshot is unresolved. Use Emergency Restore first.'}
 if(-not(Test-Path -LiteralPath $RequestPath)){throw 'Restriction request missing.'}
 $request=Get-Content -LiteralPath $RequestPath -Raw -Encoding UTF8|ConvertFrom-Json
 if($request.Mode-notin @('Word','Online','Desktop')){throw 'Invalid restriction mode.'}
 if($request.ApplicationLockdown){throw 'Application lockdown is not implemented by this helper. No protected startup is allowed with that requirement.'}
 if(@(Get-Disk|Where-Object{$_.BusType-eq 'USB' -and -not $_.IsOffline}).Count-gt 0){throw 'Remove ALL USB storage before restrictions are applied. Keyboard/headset devices are not storage.'}
 if($request.Mode-eq 'Online' -and @(Get-Process msedge -ErrorAction SilentlyContinue).Count-gt 0){throw 'Close Edge normally before applying policies. No process will be killed.'}
 $stage='Capture original machine state'
 $values=@(Snapshot-Value $Usb 'Deny_All')
 $values+=Snapshot-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR' 'Start'
 if(Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor'){$values+=Snapshot-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor' 'Start'}
 $lists=@()
 if($request.Mode-eq 'Online') {
  if(@($request.Allowlist).Count-lt 1 -or @($request.Allowlist).Count-gt 999){throw 'Online mode needs 1-999 approved URL filters.'}
  foreach($url in @($request.Allowlist)){if($url-notmatch '^https://' -or $url -eq '*'){throw 'Only explicit HTTPS filters are supported.'}}
  foreach($name in $ControlledEdge){$values+=Snapshot-Value $Edge $name};if($request.DisableBrowserAI){foreach($name in @('HubsSidebarEnabled','Microsoft365CopilotChatIconEnabled','ComposeInlineEnabled')){$values+=Snapshot-Value $Edge $name}}
  foreach($name in @('URLBlocklist','URLAllowlist','ExtensionInstallBlocklist')){$lists+=Snapshot-List $name}
 }
 $adapters=@();if($request.IsolateNetwork){$adapters=@(Active-Adapters | Sort-Object HardwareInterface | ForEach-Object {@{Guid=[string]$_.InterfaceGuid;Name=$_.Name;InterfaceDescription=[string]$_.InterfaceDescription;HardwareInterface=($_.HardwareInterface -eq $true);OriginalStatus=[string]$_.Status;ChangedByHelper=$false}})}
 $state=@{SchemaVersion=2;NetworkRestoreNotes=@();SessionId=$SessionId;Status='Applying';Mode=$request.Mode;Registry=$values;Lists=$lists;Adapters=$adapters;Detail='';UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
 Write-Atomic $statePath $state
 try {
  $stage='Apply USB storage restrictions'
  Set-Value $Usb 'Deny_All' 1
  Set-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\USBSTOR' 'Start' 4
  if(Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor'){Set-Value 'HKLM:\SYSTEM\CurrentControlSet\Services\UASPStor' 'Start' 4}
  Disable-RecordedAdapters $state $statePath
  if($request.IsolateNetwork -and @(Active-Adapters).Count-gt 0){throw 'An enabled manageable connection adapter remains; staff live network verification is still required.'}
  if($request.Mode-eq 'Online') {
   $stage='Apply Edge policies'
   Set-List 'URLBlocklist' (@('*')+@($request.BlockedAIUrls));Set-List 'URLAllowlist' (@($request.Allowlist)+@('edge://policy'));Set-List 'ExtensionInstallBlocklist' @('*')
   Set-Value $Edge 'BrowserSignin' 0;Set-Value $Edge 'SyncDisabled' 1;Set-Value $Edge 'StartupBoostEnabled' 0;Set-Value $Edge 'BackgroundModeEnabled' 0
   if($request.DisableBrowserAI){Set-Value $Edge 'HubsSidebarEnabled' 0;Set-Value $Edge 'Microsoft365CopilotChatIconEnabled' 0;Set-Value $Edge 'ComposeInlineEnabled' 0}
  }
  foreach($v in $state.Registry){$v.Expected=Snapshot-Value $v.Path $v.Name};foreach($l in $state.Lists){$l.Expected=Snapshot-List ([IO.Path]::GetFileName($l.Path))}
  $state.Status='Applied';$state.Detail='Registry readback and requested adapter-disable state checked. USB replug and Edge effective-policy checks require staff live validation. NOT application lockdown or all-AI/site-feature enforcement.';Write-Atomic $statePath $state
 } catch {
  $failure=$_.Exception.Message
  try{Restore-All $state;$state.Status='Restored';$state.Detail='Apply failed; previous state restored: '+$failure}
  catch{$state.Status='RestoreFailed';$state.Detail='Apply failed: '+$failure+'; restore failed: '+$_.Exception.Message}
  Write-Atomic $statePath $state;throw $state.Detail
 }
} else {
 if(-not(Test-Path -LiteralPath $statePath)){throw 'No protected snapshot exists for this session.'}
 $state=Get-Content -LiteralPath $statePath -Raw -Encoding UTF8|ConvertFrom-Json
 if($state.SessionId-ne $SessionId){throw 'Snapshot ID mismatch.'}
 if($Action-eq 'Restore' -and $state.Mode-eq 'Online' -and @(Get-Process msedge -ErrorAction SilentlyContinue).Count-gt 0){throw 'Close Edge normally before restoring its policies. Snapshot remains unresolved; no process was killed.'}
 if($Action-eq 'ExportAccess') {
  if($state.Status-notin @('Applied','ExportAccess')){throw 'This snapshot cannot enable export access.'}
  foreach($v in @($state.Registry)|Where-Object{$_.Path-ne $Edge}){Restore-Value $v}
  $state.Status='ExportAccess';$state.Detail='Original USB storage settings restored for authorized export; network/browser settings not yet restored.';Write-Atomic $statePath $state
 } else {
  try{Restore-All $state;$state.Status='Restored';$state.Detail='Recorded registry and connection-adapter enable states restored.';if(@($state.NetworkRestoreNotes).Count -gt 0){$state.Detail+=' Infrastructure notes: '+($state.NetworkRestoreNotes -join '; ')};Write-Atomic $statePath $state}
  catch{$state.Status='RestoreFailed';$state.Detail=$_.Exception.Message;Write-Atomic $statePath $state;throw}
 }
}

} catch {
 $failure=$_.Exception.Message
 # Fixed protected output only; never accept a caller-supplied report path.
 try {
  $expected=Join-Path $env:ProgramFiles 'AccommodationTestManagerBeta2\Scripts\Beta2Restrictions.ps1'
  if([IO.Path]::GetFullPath($PSCommandPath)-eq [IO.Path]::GetFullPath($expected) -and (Test-Path $StateRoot) -and -not ((Get-Item $StateRoot).Attributes-band [IO.FileAttributes]::ReparsePoint)) {
   $report=@{SchemaVersion=1;SessionId=$SessionId;Action=$Action;Stage=$stage;Success=$false;Message=$failure;UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
   Write-Atomic (Join-Path $StateRoot ($SessionId+'.'+$Action+'.report.json')) $report
  }
 } catch { # Reporting failure must not conceal the original machine error.
 }
 Write-Error -Message $failure -ErrorAction Continue
 exit 1
}
# Successful actions are also reported; snapshots remain the authority for restoration.
try {
 Write-Atomic (Join-Path $StateRoot ($SessionId+'.'+$Action+'.report.json')) @{SchemaVersion=1;SessionId=$SessionId;Action=$Action;Stage='Complete';Success=$true;Message='Action completed; check snapshot and live controls.';UpdatedUtc=[DateTime]::UtcNow.ToString('o')}
} catch { Write-Warning 'Action succeeded but diagnostic report could not be written.' }
