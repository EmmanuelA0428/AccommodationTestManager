using AccommodationTestManager.Services;
using System.Windows;
using System.Windows.Controls;

namespace AccommodationTestManager.Views;

// Small code-created dialogs; operational logic remains in services.
public static class StaffDialogs
{
    private static Window Dialog(Window? owner, string title, int width = 440) => new()
    {
        Owner = owner, Title = title, Width = width, SizeToContent = SizeToContent.Height,
        MaxHeight = Math.Max(360, SystemParameters.WorkArea.Height - 48), ResizeMode = ResizeMode.NoResize,
        WindowStartupLocation = owner is null ? WindowStartupLocation.CenterScreen : WindowStartupLocation.CenterOwner,
        Background = (System.Windows.Media.Brush)Application.Current.Resources["AppSurfaceBrush"],
        Foreground = (System.Windows.Media.Brush)Application.Current.Resources["AppTextBrush"], FontSize = 14
    };
    private static void Label(StackPanel panel, string text) => panel.Children.Add(new TextBlock { Text = text, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,12,0,6) });
    public static bool Register(SettingsService settings)
    {
        var dialog = Dialog(null, "Register this testing laptop"); var panel = new StackPanel { Margin = new Thickness(24) };
        dialog.Content = new ScrollViewer { Content = panel, VerticalScrollBarVisibility = ScrollBarVisibility.Auto };
        Label(panel, "Local Beta 2 — synthetic tests only. PIN/name attribution is not secure identity under the shared Windows account.");
        Label(panel, "Laptop name"); var name = new TextBox { Text = Environment.MachineName, MinHeight = 44 }; panel.Children.Add(name);
        Label(panel, "Asset tag (optional)"); var asset = new TextBox { Text = Environment.MachineName.EndsWith("W",StringComparison.OrdinalIgnoreCase)?Environment.MachineName[..^1]:Environment.MachineName, MinHeight = 44 }; panel.Children.Add(asset);
        Label(panel, "Staff names, one per line — add/remove names here; no defaults in this beta"); var staff = new TextBox { MinHeight = 80, AcceptsReturn = true, TextWrapping = TextWrapping.Wrap }; panel.Children.Add(staff);
        Label(panel, "Staff PIN — at least six digits"); var pin = new PasswordBox { MinHeight = 44 }; panel.Children.Add(pin);
        Label(panel, "Confirm PIN"); var confirm = new PasswordBox { MinHeight = 44 }; panel.Children.Add(confirm);
        var error = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,12,0,0) }; panel.Children.Add(error);
        var save = new Button { Content = "Register laptop", MinHeight = 44, Margin = new Thickness(0,16,0,0), IsDefault = true }; panel.Children.Add(save);
        save.Click += (_, _) =>
        {
            try
            {
                if (pin.Password != confirm.Password) throw new InvalidOperationException("PINs do not match.");
                settings.Register(name.Text, asset.Text, staff.Text.Split(['\r','\n'], StringSplitOptions.RemoveEmptyEntries).Select(s=>s.Trim()).Where(s=>s.Length>0).Distinct(StringComparer.OrdinalIgnoreCase).ToArray(), pin.Password);
                dialog.DialogResult = true;
            }
            catch (Exception ex) { error.Text = ex.Message; }
        };
        return dialog.ShowDialog() == true;
    }
    private static bool ResetPin(Window owner, SettingsService settings, string administrator)
    {
        var dialog=Dialog(owner,"Set a new staff PIN");var panel=new StackPanel{Margin=new Thickness(24)};dialog.Content=panel;
        Label(panel,"Windows administrator authorization verified. This resets the local shared PIN, not staff identity.");
        Label(panel,"New PIN — at least six digits");var pin=new PasswordBox{MinHeight=44};panel.Children.Add(pin);
        Label(panel,"Confirm new PIN");var confirm=new PasswordBox{MinHeight=44};panel.Children.Add(confirm);
        var error=new TextBlock{TextWrapping=TextWrapping.Wrap};panel.Children.Add(error);
        var save=new Button{Content="Reset PIN",MinHeight=44,Margin=new Thickness(0,16,0,0)};panel.Children.Add(save);
        save.Click+=(_,_)=>{try{if(pin.Password!=confirm.Password)throw new InvalidOperationException("PINs do not match.");settings.ResetPinAfterAdministratorApproval(pin.Password,administrator);dialog.DialogResult=true;}catch(Exception ex){error.Text=ex.Message;}};
        return dialog.ShowDialog()==true;
    }
    public static string? Authorize(Window owner, SettingsService settings, string action, string? suggested = null)
    {
        var dialog = Dialog(owner, action); var panel = new StackPanel { Margin = new Thickness(24) }; dialog.Content = panel;
        Label(panel, "Record staff member and authorize this local beta action.");
        var staff = new ComboBox { Name="StaffAuthorizationChoice", ItemsSource = settings.Current.StaffNames, SelectedItem = suggested, MinHeight = 44 }; panel.Children.Add(staff);
        Label(panel, "Staff PIN"); var pin = new PasswordBox { Name="StaffAuthorizationPin", MinHeight = 44 }; panel.Children.Add(pin);
        var error = new TextBlock { TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0,12,0,0) }; panel.Children.Add(error);
        var button = new Button { Name="StaffAuthorizeButton", Content = "Authorize", MinHeight = 44, Margin = new Thickness(0,16,0,0), IsDefault = true }; panel.Children.Add(button);
        var reset = new Button { Content = "Forgot PIN? Administrator reset", MinHeight=44, Margin=new Thickness(0,12,0,0) };
        panel.Children.Add(reset);
        reset.Click += async (_,_) =>
        {
            reset.IsEnabled=false;button.IsEnabled=false;
            try
            {
                string administrator=await AdminPinResetService.AuthorizeAsync();
                if (ResetPin(dialog,settings,administrator)) error.Text="PIN reset. Select staff and authorize with the new PIN.";
                pin.Clear();
            }
            catch(Exception ex){error.Text=ex.Message;}
            finally{reset.IsEnabled=true;button.IsEnabled=true;}
        };
        string? result = null;
        button.Click += (_, _) =>
        {
            try
            {
                if (staff.SelectedItem is not string selected) throw new InvalidOperationException("Select staff member.");
                if (!settings.VerifyPin(pin.Password)) { error.Text = "Incorrect PIN."; pin.Clear(); return; }
                result = selected; dialog.DialogResult = true;
            }
            catch (Exception ex) { error.Text = ex.Message; }
        };
        return dialog.ShowDialog() == true ? result : null;
    }
}
