# Dummy-exam Update 3 checks
1. Reproduce Canvas startup failure; View diagnostics shows the actual stage/message. No force-closing apps or deleting snapshots.
2. Test helper authorization cancellation vs actual restriction errors. Confirm snapshots stay unresolved when restoration fails.
3. Word dummy exam: type, Finish, verify checkpoint/Word close, awaiting-staff screen, cancel PIN (still awaiting), correct PIN, Export and verify. Resume then Finish requires PIN again.
4. Canvas/Posit: save/submit on site before Finish, PIN handoff, staff verify submission, close browser normally, complete. The handoff is not Windows lockdown; Alt+Tab and second monitors are not securely blocked.
5. Settings > Global config shows v1 and last verification; reopen offline and verify cached URLs/defaults still used. Active test snapshots do not change when refreshing config.
6. Disable global config between sessions and verify local settings/allowlists are restored; re-enable and check global overlay.
7. Simulate invalid global version/partial commit in an isolated test repository/harness only; prior cache retained. Never intentionally weaken production allowlists.
8. Check for app updates only between tests; settings, identity and sessions preserved.
