using AccommodationTestManager.Models;
using AccommodationTestManager.Services;
using System.Text.Json;

var root=Path.Combine(Path.GetTempPath(),"ATM-Beta-Tests-"+Guid.NewGuid().ToString("N"));Directory.CreateDirectory(root);
int checks=0;
void Check(bool condition,string name){if(!condition)throw new Exception("FAILED: "+name);checks++;Console.WriteLine("PASS: "+name);}
async Task Throws(Func<Task> op,string name){bool failed=false;try{await op();}catch{failed=true;}Check(failed,name);}
try
{
 var storage=new LocalStorageService(Path.Combine(root,"Data"));
 var config=new AppSettings{RequireMachineRestrictions=false,DeviceId=Guid.NewGuid().ToString("N")};LocalStorageService.WriteJson(storage.SettingsPath,config);
 var settings=new SettingsService(storage);settings.Load();settings.Register("Synthetic laptop","FAKE",["Staff A","Staff B"],"654321");
 string device=settings.Current.DeviceId;settings.Reload();Check(settings.Current.DeviceId==device,"device ID survives reload");Check(settings.VerifyPin("654321"),"PIN hash verifies");Check(!settings.VerifyPin("111111"),"wrong PIN rejected");
 var malformed=LocalStorageService.Clone(settings.Current);malformed.SaveIntervalSeconds=1;LocalStorageService.WriteJson(storage.SettingsPath,malformed);
 await Throws(()=>{settings.Reload();return Task.CompletedTask;},"invalid configuration rejected");Check(settings.Current.SaveIntervalSeconds==60,"failed reload preserves previous valid settings");settings.Save();
 string original=Path.Combine(root,"Original.doc");await File.WriteAllTextAsync(original,"Synthetic original; NOT a real Word document.");string originalHash=LocalStorageService.HashFile(original);
 var draft=new TestSetupDraft{StaffName="Staff A",StudentName="Synthetic student",TestName="Synthetic test",DocumentPath=original,Preset="Word",UseTimeLimit=false};
 using(var service=new SessionService(storage,settings))
 {
  await service.StartAsync(draft);Check(service.Current?.Status=="Active","start creates active session");Check(service.Current!.DeadlineUtc is null,"unlimited session has no deadline");Check(Path.GetFileName(Path.GetDirectoryName(service.Folder!))=="Active","move to Active before Word opens");
  string working=storage.FileInSession(service.Folder!,service.Current.WorkingRelativePath);Check(File.Exists(working)&&working!=original,"local working copy exists separately");Check(LocalStorageService.HashFile(original)==originalHash,"original exam unchanged");
  await Throws(()=>{storage.FileInSession(service.Folder!,"../escape.doc");return Task.CompletedTask;},"session traversal rejected");
  await Throws(()=>service.StartAsync(draft),"second active session blocked");
  await File.WriteAllTextAsync(working,"Synthetic answers saved in mock Word.");await Task.WhenAll(service.SaveNowAsync(),service.SaveNowAsync());Check(service.Current!.LastSaveUtc is not null,"serialized save updates metadata");
  var mock=new WordAutomationService();await mock.OpenAsync(working);var snapshots=new RecoverySnapshotService(mock);
  for(int i=0;i<6;i++)await snapshots.CreateAsync(storage.FileInSession(service.Folder!,"Recovery"),5);
  Check(Directory.GetFiles(storage.FileInSession(service.Folder!,"Recovery"),"Recovery-*.doc").Length==5,"rolling recovery keeps latest five");
  WordAutomationService.FailClose=true;await Throws(()=>service.FinishAsync(),"unsaved new edit prevents Finish");Check(service.Current.Status=="Active","failed Finish leaves session active");WordAutomationService.FailClose=false;
  WordAutomationService.SaveNewEditDuringClose=true;await Throws(()=>service.FinishAsync(),"new saved edit during Finish blocks stale checkpoint");Check(service.Current.Status=="Active","Finish race leaves latest working data available");await service.ResumeAsync("Staff B");
  await service.FinishAsync();Check(service.Current.Status=="AwaitingStaff","Finish creates staff checkpoint state");Check(LocalStorageService.HashFile(storage.FileInSession(service.Folder!,service.Current.FinishRelativePath))==service.Current.FinishSha256,"student checkpoint verified");
  string previousWorking=service.Current.WorkingRelativePath;
  await service.RecoverLatestWorkingCopyAsync("Staff B");Check(service.Current.WorkingRelativePath!=previousWorking,"recovery creates a new working file rather than overwriting");Check(File.Exists(storage.FileInSession(service.Folder!,previousWorking)),"recovery preserves prior working file");
  await service.ResumeAsync("Staff B");Check(service.Current.Status=="Active","staff can resume checkpointed test");await service.FinishAsync();await service.PrepareFinalAsync("Staff B");Check(service.Current.Status=="ExportPending","finalization leaves export pending");
  await Throws(()=>service.ExportAsync(original,"Staff B"),"original overwrite refused");await Throws(()=>service.CompleteAsync("Staff B"),"completion without export refused");
  await Throws(()=>service.ExportAsync(Path.Combine(original,"invalid.doc"),"Staff B"),"invalid external destination fails without completing");Check(service.Current.Status=="ExportPending","failed destination retains final and session");
  string export=Path.Combine(root,"External","Completed.doc");await service.ExportAsync(export,"Staff B");Check(service.Current.ExportSha256==LocalStorageService.HashFile(export),"export readback hash verified");
  string exportContent=await File.ReadAllTextAsync(export);await File.WriteAllTextAsync(export,"Tampered output");await Throws(()=>service.CompleteAsync("Staff B"),"tampered export blocks completion");Check(service.Current.Status=="ExportPending","failed export validation preserves session");await File.WriteAllTextAsync(export,exportContent);
  await service.CompleteAsync("Staff B");Check(service.Current is null,"completion releases active session");
 }
 var completed=storage.ListSessions().Single();Check(completed.Session.Status=="Completed"&&completed.Session.FinalizedBy=="Staff B","completed metadata and finalizing staff persisted");Check(File.Exists(storage.FileInSession(completed.Folder,completed.Session.FinalRelativePath)),"final retained after export");Check(File.Exists(Path.Combine(completed.Folder,"session.json.bak")),"atomic metadata backup retained");
 using(var first=new SessionService(storage,settings)){draft.UseTimeLimit=true;draft.DurationText="90";await first.StartAsync(draft);Check(first.Current!.DeadlineUtc is not null,"timed session persists deadline");}
 var interrupted=storage.ListSessions(true).Single();
 using(var second=new SessionService(storage,settings)){await second.AdoptAsync(interrupted,"Staff B");await second.ResumeAsync("Staff B");Check(second.Current?.Status=="Active","restart recovery adopts and reconnects same session");}
 // Damaged metadata is visible and fail-closed rather than silently dropped/reset.
 string damaged=Path.Combine(interrupted.Folder,"session.json");await File.WriteAllTextAsync(damaged,"{ broken JSON");var needsReview=storage.ListSessions(true).Single();Check(needsReview.Session.Status=="NeedsReview","corrupt metadata appears for staff review");storage.RestoreMetadataBackup(needsReview,"Staff B");Check(storage.ListSessions(true).Single().Session.Status=="Active","explicit metadata backup restoration works");
 // Online completion uses staff assertion, not fabricated website verification.
 var onlineRoot=new LocalStorageService(Path.Combine(root,"Online"));var onlineSettings=new SettingsService(onlineRoot);LocalStorageService.WriteJson(onlineRoot.SettingsPath,settings.Current);onlineSettings.Load();
 string id=Guid.NewGuid().ToString("N");string onlineFolder=onlineRoot.NewSessionFolder(id);var online=new TestSession{Id=id,Mode="Canvas",Status="AwaitingStaff",CreatedUtc=DateTimeOffset.UtcNow};LocalStorageService.WriteJson(Path.Combine(onlineFolder,"session.json"),online);onlineFolder=onlineRoot.MoveArea(onlineFolder,"Active");
 using(var service=new SessionService(onlineRoot,onlineSettings)){await service.AdoptAsync(new(onlineFolder,online),"Staff A");await Throws(()=>service.CompleteAsync("Staff A"),"online completion requires staff verification");await service.CompleteAsync("Staff A",true);}
 Check(onlineRoot.ListSessions().Single().Session.SubmissionVerifiedByStaff,"online verification attribution persisted");

 // Beta 2 allowlist rules and editable stable staff identities.
 var lists=new AllowlistService(storage);Directory.CreateDirectory(lists.Folder);
 var normalized=AllowlistService.Normalize(["canvas.hws.edu","https://canvas.hws.edu/*","https://*.hws.edu","https://hws.edu"]);
 Check(normalized.Count==2,"allowlist duplicate/wildcard-host normalization");
 lists.Save(new AllowlistConfiguration{Id="canvas",UrlPatterns=normalized});
 Check(AllowlistService.AllowsStart(lists.Load("canvas"),"https://sso.hws.edu/SecureAuth21/"),"allowed subdomain start accepted");
 Check(!AllowlistService.AllowsStart(lists.Load("canvas"),"https://hws.edu.evil.example/"),"lookalike start domain rejected");
 Check(!AllowlistService.AllowsStart(lists.Load("canvas"),"http://canvas.hws.edu/"),"HTTP start rejected");
 foreach(string value in new[]{"*","https://foo.example/*/bar","https://user:secret@example.org","https://example.org/?key=secret","[example](https://example.org)"})
  await Throws(()=>{AllowlistService.Normalize([value]);return Task.CompletedTask;},"unsafe allowlist filter rejected: "+value);
 await Throws(()=>{lists.Load("../escape");return Task.CompletedTask;},"allowlist filename traversal rejected");
 await Throws(()=>{lists.Save(new AllowlistConfiguration{Id="large",UrlPatterns=Enumerable.Range(0,1000).Select(i=>$"https://h{i}.example").ToList()});return Task.CompletedTask;},"over Edge filter limit rejected");
 string staffId=settings.Current.StaffMembers[0].Id;
 var edit=LocalStorageService.Clone(settings.Current);edit.StaffMembers[0].Name="Renamed staff";settings.Update(edit);settings.Reload();
 Check(settings.Current.StaffMembers[0].Id==staffId,"staff rename preserves stable ID");
 Check(completed.Session.StartedBy=="Staff A"&&completed.Session.StartedById==staffId,"historical staff name and ID remain unchanged");
 edit=LocalStorageService.Clone(settings.Current);edit.StaffMembers[0].Active=false;settings.Update(edit);
 Check(!settings.Current.StaffNames.Contains("Renamed staff")&&settings.Current.StaffMembers.Any(x=>x.Id==staffId),"deactivation excludes choice but retains identity");
 // Required controls and restore failure use a helper DOUBLE: not a Windows restriction test.
 var restrictedStorage=new LocalStorageService(Path.Combine(root,"Restricted"));
 var restrictedConfig=LocalStorageService.Clone(settings.Current);restrictedConfig.RequireMachineRestrictions=true;
 LocalStorageService.WriteJson(restrictedStorage.SettingsPath,restrictedConfig);var restrictedSettings=new SettingsService(restrictedStorage);restrictedSettings.Load();
 var helper=new RestrictionService();var restrictedDraft=new TestSetupDraft{StaffName="Staff B",StudentName="Synthetic",TestName="Scoped controls",Preset="Word",DocumentPath=original};
 using(var service=new SessionService(restrictedStorage,restrictedSettings,null,helper))
 {
  service.ConfirmRemoveStorage=()=>Task.FromResult(true);await service.StartAsync(restrictedDraft);
  Check(service.Current!.Status=="Preflight"&&service.Current.StartedUtc is null,"required-control start waits for staff preflight");
  await Throws(()=>service.FinishAsync(),"Finish before handoff rejected");
  await service.ConfirmPreflightAsync("Staff B");Check(service.Current.Status=="Active","staff preflight activates session");
  await service.FinishAsync();await service.OpenExportAccessAsync("Staff B");
  await Throws(()=>service.ResumeAsync("Staff B"),"USB export access blocks resume");
  await service.PrepareFinalAsync("Staff B");await service.ExportAsync(Path.Combine(root,"Scoped-export.doc"),"Staff B");
  helper.FailRestore=true;await Throws(()=>service.CompleteAsync("Staff B"),"machine restore failure blocks completion");
  Check(service.Current!.Status=="Completing"&&Path.GetFileName(Path.GetDirectoryName(service.Folder!))=="Active","failed restore preserves unfinished session and files");
  helper.FailRestore=false;await service.CompleteAsync("Staff B");Check(service.Current is null,"retry completes after machine restore");
 }
 // Unsupported custom desktop saves use explicit staff import, never fabricated autosave.
 var customStorage=new LocalStorageService(Path.Combine(root,"Custom"));LocalStorageService.WriteJson(customStorage.SettingsPath,settings.Current);
 var customSettings=new SettingsService(customStorage);customSettings.Load();string customId=Guid.NewGuid().ToString("N");
 string customFolder=customStorage.NewSessionFolder(customId);var customSession=new TestSession{Id=customId,Mode="Custom",CustomKind="Desktop",Status="AwaitingStaff",SettingsSnapshot=LocalStorageService.Clone(settings.Current)};
 LocalStorageService.WriteJson(Path.Combine(customFolder,"session.json"),customSession);customFolder=customStorage.MoveArea(customFolder,"Active");
 using(var service=new SessionService(customStorage,customSettings))
 {
  await service.AdoptAsync(new(customFolder,customSession),"Staff B");await service.PrepareCustomFinalAsync(original,"Staff B");
  Check(service.Current!.Status=="ExportPending"&&service.Current.FinalSha256==originalHash,"custom staff-selected final copied and verified");
  await service.ExportAsync(Path.Combine(root,"Custom-export.doc"),"Staff B");await service.CompleteAsync("Staff B");
 }
 Check(customStorage.ListSessions().Single().Session.Status=="Completed","custom manual-save flow completes after export");
 // Update 1 real filesystem regressions, still using mock Word for COM state.
 string wordFile=Path.Combine(root,"LockTest.doc");await File.WriteAllTextAsync(wordFile,"Mock saved document bytes");
 using(var held=new FileStream(wordFile,FileMode.Open,FileAccess.ReadWrite,FileShare.ReadWrite))
 {
  if(OperatingSystem.IsWindows())await Throws(()=>{LocalStorageService.HashFile(wordFile);return Task.CompletedTask;},"legacy exclusive-read conflicts with retained Word write handle");
  else Console.WriteLine("SKIP: Windows-specific sharing conflict demonstration (covered on Windows CI)");
  var w=new WordAutomationService();await w.OpenAsync(wordFile);var recovery=new RecoverySnapshotService(w);
  var receipt=await recovery.CreateAsync(Path.Combine(root,"LockRecovery"));
  Check(File.ReadAllText(receipt.FilePath)=="Mock saved document bytes","snapshot succeeds while a compatible write handle remains open");
  Check(File.Exists(wordFile),"open working document is preserved");
 }
 using(var held=new FileStream(wordFile,FileMode.Open,FileAccess.ReadWrite,FileShare.None))
 {
  var w=new WordAutomationService();await w.OpenAsync(wordFile);var recovery=new RecoverySnapshotService(w);
  await Throws(()=>recovery.CreateAsync(Path.Combine(root,"ExclusiveRecovery")),"exclusive incompatible lock fails without claiming success");
  Check(!Directory.GetFiles(Path.Combine(root,"ExclusiveRecovery")).Any(),"failed captures leave no partial or false recovery copies");
 }
 Check(UpdatePolicy.ReleaseVersion("v1.0.0-beta.2.5")>UpdatePolicy.ReleaseVersion(UpdatePolicy.InstalledVersion),"numeric future version is recognized");
 Check(UpdatePolicy.ReleaseVersion("v1.0.0-beta.2.10")>UpdatePolicy.ReleaseVersion("v1.0.0-beta.2.9"),"update comparison is numeric not lexical");
 await Throws(()=>{UpdatePolicy.ReleaseVersion("v1.0.0-beta.3.1");return Task.CompletedTask;},"other beta channels rejected");
 foreach(string uri in new[]{"http://github.com/EmmanuelA0428/AccommodationTestManager/releases/download/v1/setup.exe","https://evil.example/setup.exe","https://github.com/other/repo/releases/download/v1/setup.exe","https://github.com@evil.example/setup.exe"})
  await Throws(()=>{UpdatePolicy.ValidateAssetUri(new Uri(uri));return Task.CompletedTask;},"untrusted update URL rejected");
 string checksum=new string('a',64);
 Check(UpdatePolicy.ParseChecksum(checksum+"  setup.exe","setup.exe")==checksum,"exact checksum file parses");
 await Throws(()=>{UpdatePolicy.ParseChecksum(checksum+"  other.exe","setup.exe");return Task.CompletedTask;},"checksum filename mismatch rejected");
 await Throws(()=>{UpdatePolicy.ParseChecksum(checksum+"  setup.exe\n"+checksum+"  setup.exe","setup.exe");return Task.CompletedTask;},"multiple checksum lines rejected");
 string badDocx=Path.Combine(root,"Damaged.docx");await File.WriteAllTextAsync(badDocx,"not a Word package");
 await Throws(()=>{RecoverySnapshotService.CopyAndVerify(badDocx,Path.Combine(root,"BadPackage"));return Task.CompletedTask;},"invalid DOCX package never accepted as recovery");
 Check(Directory.GetFiles(Path.Combine(root,"BadPackage")).Length==0,"invalid DOCX leaves no published copy");
 string validDocx=Path.Combine(root,"Valid.docx");
 using(var zip=System.IO.Compression.ZipFile.Open(validDocx,System.IO.Compression.ZipArchiveMode.Create))
 {
  using(var w=new StreamWriter(zip.CreateEntry("[Content_Types].xml").Open()))w.Write("<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'/>");
  using(var w=new StreamWriter(zip.CreateEntry("word/document.xml").Open()))w.Write("<w:document xmlns:w='http://schemas.openxmlformats.org/wordprocessingml/2006/main'><w:body/></w:document>");
 }
 var good=RecoverySnapshotService.CopyAndVerify(validDocx,Path.Combine(root,"GoodPackage"));Check(File.Exists(good.FilePath),"valid DOCX package can be verified");
 await Throws(()=>{RecoverySnapshotService.CopyAndVerify(wordFile,Path.Combine(root,"ChangedCapture"),()=>File.AppendAllText(wordFile,"new edit"));return Task.CompletedTask;},"source mutation during capture rejects snapshot");
 Check(Directory.GetFiles(Path.Combine(root,"ChangedCapture")).Length==0,"changed source leaves no false receipt or partial");
 var pinBefore=settings.Current.StaffPinHash;settings.ResetPinAfterAdministratorApproval("123456","SYNTHETIC\\Admin");
 Check(settings.VerifyPin("123456")&&!settings.VerifyPin("654321"),"PIN reset replaces old PIN");
 Check(settings.Current.LastAdminPinResetBy=="SYNTHETIC\\Admin"&&settings.Current.LastAdminPinResetUtc is not null,"PIN reset attribution/timestamp recorded without PIN text");
 Check(settings.Current.DeviceId==device,"PIN reset preserves permanent laptop identity");
 using(var unresolved=new SessionService(storage,settings))
 using(var updater=new UpdateService(storage,unresolved,new RestrictionService()))
 {await Throws(()=>{updater.AssertCanInstall();return Task.CompletedTask;},"unfinished sessions block update installation");}
 var updateStorage=new LocalStorageService(Path.Combine(root,"UpdateEmpty"));LocalStorageService.WriteJson(updateStorage.SettingsPath,settings.Current);var updateSettings=new SettingsService(updateStorage);updateSettings.Load();
 var pendingHelper=new RestrictionService();pendingHelper.States[Guid.NewGuid().ToString("N")]="RestoreFailed";
 using(var none=new SessionService(updateStorage,updateSettings))
 using(var updater=new UpdateService(updateStorage,none,pendingHelper))
 {await Throws(()=>{updater.AssertCanInstall();return Task.CompletedTask;},"unresolved machine restore blocks update installation");pendingHelper.States.Clear();updater.AssertCanInstall();Check(true,"idle restored laptop passes update gate");}
 var ready=SetupReadiness.Evaluate(0,false);
 Check(ready.CanContinue(0,false,false)&&ready.CanContinue(3,false,false),"idle draft can continue and start");
 var blocked=SetupReadiness.Evaluate(1,false);
 Check(blocked.CanContinue(0,false,false)&&blocked.CanContinue(2,false,false),"recovery does not silently disable draft navigation");
 Check(!blocked.CanContinue(3,false,false)&&blocked.Reason.Contains("recovery"),"unfinished test blocks Start with actionable reason");
 Check(!SetupReadiness.Evaluate(0,true).CanContinue(3,false,false),"pending machine restore blocks Start");
 Check(!SetupReadiness.Evaluate(0,false,"unreadable").CanContinue(3,false,false),"unreadable storage fails closed at Start");
 Check(!ready.CanContinue(0,true,false)&&!ready.CanContinue(0,false,true),"busy/current sessions disable setup navigation");
 Check(SetupReadiness.Evaluate(0,false).CanContinue(3,false,false),"fresh evaluation clears resolved recovery gate");
 await GlobalConfigTests.Run(root,Check);
 Console.WriteLine($"ALL {checks} CHECKS PASSED — mock Word/manual timer/restriction helper; real filesystem, settings, allowlists and coordinator.");
}
finally { Directory.Delete(root,true); }
