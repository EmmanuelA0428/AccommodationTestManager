# Run a relocated TEST COPY with administrator/OS queries replaced. Production helper untouched.
$ErrorActionPreference='Stop'
$source=Get-Content (Join-Path (Split-Path -Parent $PSScriptRoot) 'AccommodationTestManager/Scripts/Beta2Restrictions.ps1') -Raw
$root=Join-Path ([IO.Path]::GetTempPath()) ('ATM-HelperProbe-'+[guid]::NewGuid().ToString('N'))
$oldProgram=$env:ProgramFiles
try {
 $env:ProgramFiles=$root
 $scripts=Join-Path $root 'AccommodationTestManagerBeta2/Scripts'
 $state=Join-Path $root 'State';New-Item -ItemType Directory $scripts,$state -Force|Out-Null
 $helper=Join-Path $scripts 'Beta2Restrictions.ps1'
 foreach($case in @('USB','Edge','BadMode')) {
  $id=[guid]::NewGuid().ToString('N');$request=Join-Path $root ($id+'.json')
  @{Mode=$(if($case-eq 'BadMode'){'BAD'}else{'Online'});ApplicationLockdown=$false}|ConvertTo-Json|Set-Content $request
  $copy=$source.Replace("'C:\ProgramData\AccommodationTestingBeta2\RestrictionState'",("'"+$state.Replace("'","''")+"'"))
  # Windows rebuilds ProgramFiles for a new PowerShell process; set fixture explicitly INSIDE the relocated test copy.
  $copy=$copy.Replace("`$ErrorActionPreference='Stop'",("`$env:ProgramFiles='"+$root.Replace("'","''")+"'`n`$ErrorActionPreference='Stop'"))
  $mock="function Assert-Admin { }`nfunction Get-Disk { " + $(if($case-eq 'USB'){"[pscustomobject]@{BusType='USB';IsOffline=`$false}"}else{''}) + " }`nfunction Get-Process { param(`$Name,`$ErrorAction) " + $(if($case-eq 'Edge'){"[pscustomobject]@{Name='msedge'}"}else{''}) + " }`n"
  $copy=$copy.Replace("`$stage='Authorize and validate installation'",$mock+"`$stage='Authorize and validate installation'")
  Set-Content $helper $copy -Encoding UTF8
  # Separate process: helper exit 1 cannot terminate this test runner.
  $ErrorActionPreference="Continue"
  $childOutput=@(& (Get-Process -Id $PID).Path -NoProfile -ExecutionPolicy Bypass -File $helper -Action Apply -SessionId $id -RequestPath $request 2>&1)
  $ErrorActionPreference="Stop"
  if($LASTEXITCODE-ne 1){throw "$case did not fail safely"}
  if(-not(Test-Path (Join-Path $state ($id+".Apply.report.json")))){throw ("Missing diagnostic report: "+($childOutput -join "`n"))}
  $report=Get-Content (Join-Path $state ($id+'.Apply.report.json')) -Raw|ConvertFrom-Json
  if($report.Success -or $report.Stage-ne 'Validate startup prerequisites'){throw "$case report missing failure stage"}
  $expected=switch($case){USB{'Remove ALL USB'};Edge{'Close Edge normally'};BadMode{'Invalid restriction mode'}}
  if($report.Message-notlike "*$expected*"){throw "$case useful detail lost"}
  if(Test-Path (Join-Path $state ($id+'.json'))){throw "$case unexpectedly reached snapshot/machine mutation"}
  Write-Output "PASS: $case early failure has in-app report; no snapshot or machine mutation"
 }
 'ALL 3 EARLY-FAILURE DIAGNOSTIC CHECKS PASSED — isolated test copy and mocked OS/admin queries.'
} finally { $env:ProgramFiles=$oldProgram;if(Test-Path $root){Remove-Item $root -Recurse -Force} }
