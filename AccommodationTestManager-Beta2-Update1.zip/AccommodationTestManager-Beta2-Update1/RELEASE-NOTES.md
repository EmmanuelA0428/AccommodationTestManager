## Beta 2 Update 1

[Download the one-click installer](https://github.com/EmmanuelA0428/AccommodationTestManager/releases/download/v1.0.0-beta.2.2/AccommodationTestManager-Setup-Beta2-Update1.exe)

Public download, no GitHub sign-in. App + protected helpers + private .NET runtime installed together. Windows 11 x64, Edge and desktop Word for Word mode. Installer remains **unsigned**; security warnings/policies still apply. No separate PowerShell install or ZIP extraction for staff.

### Fixes and changes
- Word retained write handles no longer conflict with recovery's file sharing. Save/capture is serialized on the Word STA, with background-save completion checks, stable before/copy/after hashes, metadata, DOCX package validation and post-capture Word saved-state checks. Finish still refuses stale or unverifiable checkpoints and preserves working files on failure.
- One-row icon student controls, optional timer, content-sized height.
- Light/dark toggle by Settings and explicit dark-compatible control templates.
- Security summary merged into Review; four setup steps. Live preflight stays for required controls.
- Asset tag prefilled from laptop name without trailing W; editable. Staff names manually entered/edited during registration; no defaults yet.
- Forgotten PIN reset requires fresh Windows administrator authorization, token/challenge verification, then a new PIN. Attribution recorded locally. Shared-account settings/PIN attribution are not secure individual identity.
- Settings > Updates checks newer compatible Beta 2 GitHub releases manually. Exact download size/checksum and available GitHub digest checked; Internet-origin marking retained; bytes reverified/locked at launch. Active/unfinished sessions, busy actions or pending machine restrictions prevent in-app update installation. No cloud configuration sync, online portal or silent auto-updates.
- Hidden PowerShell request for machine controls; native Windows UAC remains visible/required.

### Upgrade from a failed old Finish
Use a dummy exam. Keep the laptop with staff; save in Word and preserve a separate backup if possible. Restore recorded controls using old Settings > Recovery > Emergency restore. Close Word normally after saving and close the app preserving the unfinished session. Run Update 1 setup, then staff recovery/reconnect and verify the working document before repeating preflight. Do not delete a test to install an update. First Update 1 installation is manual; the new Settings updater is for later compatible releases.

### Validation and limits
GitHub Windows runner builds the app, runs filesystem/coordinator/update-policy regressions with **mock Word**, mocked network checks, installer guards, native PIN protocol checks (no PIN change), and silent install/uninstall checks before publishing. This does not prove actual Word COM, WPF rendering, real UAC, or school-device policies. Follow the source package's TEST-CHECKLIST.md on the testing laptop.

**Not production exam-ready:** no OS app lockdown, protected student-data broker, secure individual staff identity or comprehensive in-site AI prevention. Synthetic tests only.

Developer source: AccommodationTestManager-Beta2-Update1.zip (contains the complete solution and installer sources). GitHub automatic Source code ZIP is not the full project. The EXE's .sha256 asset supplies its checksum; hashes are not a publisher signature.
